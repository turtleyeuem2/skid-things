const SETTINGS_FONT_CHOICES = [
  { value: "Inter", label: "Inter" },
  { value: "Segoe UI", label: "Segoe UI" },
  { value: "Arial", label: "Arial" },
  { value: "Helvetica", label: "Helvetica" },
  { value: "Verdana", label: "Verdana" },
  { value: "Tahoma", label: "Tahoma" },
];

const SETTINGS_CODE_FONT_CHOICES = [
  { value: "JetBrains Mono", label: "JetBrains Mono", preview: true },
  { value: "Cascadia Mono", label: "Cascadia Mono", preview: true },
  { value: "Consolas", label: "Consolas", preview: true },
  { value: "Menlo", label: "Menlo", preview: true },
  { value: "Courier New", label: "Courier New", preview: true },
];

const SETTINGS_WEIGHT_CHOICES = [
  { value: "300", label: "Light", hint: "300" },
  { value: "400", label: "Regular", hint: "400" },
  { value: "500", label: "Medium", hint: "500" },
  { value: "600", label: "Semibold", hint: "600" },
  { value: "700", label: "Bold", hint: "700" },
];

const SETTINGS_SHORTCUTS_PAGE = {
  category: "Shortcuts",
  rows: [],
};

const SETTINGS_SCHEMA = [
  {
    category: "Library",
    rows: [
      {
        key: "RakNet",
        label: "RakNet",
        description: "Use the RakNet library",
        is_option: true,
        option_default: true,
      },
      {
        key: "Oth",
        label: "Oth",
        description: "Use the Oth library",
        is_option: true,
        option_default: true,
      },
    ],
  },
  {
    category: "Decompiler",
    rows: [
      {
        key: "AiRenaming",
        label: "Ai Renaming",
        description: "Rename decompiler output using an ai",
        is_option: true,
        option_default: false,
      },
    ],
  },
  {
    category: "Appearance",
    rows: [
      {
        key: "accent_color",
        label: "Accent colour",
        description: "Tints the run button, focus rings and every highlight",
        control: "color",
        on_change: HandleAccentColorChanged,
      },
      {
        key: "ui_theme",
        label: "Theme",
        description: "Dark is the house look, Retro is old Windows chrome, the rest are community palettes",
        control: "select",
        options: UI_THEMES.map((theme) => ({ value: theme.id, label: theme.label })),
        on_change: HandleThemeChanged,
      },
      {
        key: "ui_density",
        label: "Density",
        description: "Compact squeezes the rows, panels and tab bar tighter",
        control: "select",
        options: [
          { value: "cosy", label: "Cosy" },
          { value: "compact", label: "Compact" },
        ],
        on_change: HandleDensityChanged,
      },
      {
        key: "ui_motion",
        label: "Motion",
        description: "Turn off every transition and animation if you prefer a still interface",
        control: "select",
        options: [
          { value: "on", label: "On" },
          { value: "off", label: "Off" },
        ],
        on_change: HandleMotionChanged,
      },
      {
        key: "ui_font_family",
        label: "Interface font",
        description: "Typeface Hexion draws its own interface with",
        control: "select",
        options: SETTINGS_FONT_CHOICES,
        on_change: HandleUiFontChanged,
      },
      {
        key: "ui_font_weight",
        label: "Interface weight",
        description: "How heavy the interface text is drawn",
        control: "select",
        options: SETTINGS_WEIGHT_CHOICES,
        preview_font_weight: true,
        on_change: HandleUiFontChanged,
      },
      {
        key: "editor_font_family",
        label: "Editor font",
        description: "Typeface the code is drawn in",
        control: "select",
        options: SETTINGS_CODE_FONT_CHOICES,
        on_change: HandleUiFontChanged,
      },
      {
        key: "editor_font_weight",
        label: "Editor weight",
        description: "How heavy the code is drawn",
        control: "select",
        options: SETTINGS_WEIGHT_CHOICES,
        preview_font_weight: true,
        on_change: HandleUiFontChanged,
      },
      {
        key: "console_font_family",
        label: "Console font",
        description: "Typeface the output is drawn in",
        control: "select",
        options: SETTINGS_CODE_FONT_CHOICES,
        on_change: HandleUiFontChanged,
      },
      {
        key: "console_font_weight",
        label: "Console weight",
        description: "How heavy the output is drawn",
        control: "select",
        options: SETTINGS_WEIGHT_CHOICES,
        preview_font_weight: true,
        on_change: HandleUiFontChanged,
      },
      {
        key: "show_explorer_file_sizes",
        label: "File sizes",
        description: "Show file sizes next to items in the explorer",
        on_change: HandleExplorerFileSizesChanged,
      },
    ],
  },
  {
    category: "Editor",
    rows: [
      {
        key: "editor_font_size_px",
        label: "Text size",
        description: "Size of the code, in pixels",
        on_change: HandleEditorFontSizeChanged,
      },
      {
        key: "editor_line_height",
        label: "Line height",
        description: "Vertical space given to each line, 1.2 is tight and 2.2 is airy",
        on_change: HandleEditorLineHeightChanged,
      },
      {
        key: "editor_tab_size",
        label: "Indent width",
        description: "How many spaces one indent level is worth",
        on_change: HandleEditorIndentChanged,
      },
      {
        key: "editor_caret_style",
        label: "Caret",
        description: "The blinking cursor, drawn as a bar, a block or an underline",
        control: "select",
        options: [
          { value: "bar", label: "Bar" },
          { value: "block", label: "Block" },
          { value: "underline", label: "Underline" },
        ],
        on_change: HandleEditorCaretStyleChanged,
      },
      {
        key: "editor_caret_blink",
        label: "Blinking caret",
        description: "Let the cursor fade in and out, or leave it solid",
        on_change: HandleEditorCaretBlinkChanged,
      },
      {
        key: "editor_selection_style",
        label: "Selection",
        description: "How a selected stretch of text is painted",
        control: "select",
        options: [
          { value: "block", label: "Block" },
          { value: "rounded", label: "Rounded" },
        ],
        on_change: HandleEditorSelectionStyleChanged,
      },
      {
        key: "show_gutter",
        label: "Line numbers",
        description: "Show the numbered gutter beside the code",
        on_change: HandleGutterChanged,
      },
      {
        key: "show_indent_guides",
        label: "Indent guides",
        description: "Draw a faint line at every indent level",
        on_change: HandleIndentGuidesChanged,
      },
      {
        key: "show_active_line",
        label: "Active line",
        description: "Highlight the line the caret is sitting on",
        on_change: HandleActiveLineChanged,
      },
      {
        key: "show_problems",
        label: "Problems",
        description: "Report unclosed blocks and brackets under the editor",
        on_change: HandleProblemsChanged,
      },
    ],
  },
  {
    category: "Console",
    rows: [
      {
        key: "console_font_size_px",
        label: "Text size",
        description: "Size of the output, in pixels",
        on_change: HandleConsoleFontSizeChanged,
      },
      {
        key: "console_line_height",
        label: "Line height",
        description: "Vertical space given to each line of output",
        on_change: HandleConsoleLineHeightChanged,
      },
      {
        key: "console_wrap",
        label: "Wrap long lines",
        description: "Fold a line that runs off the edge instead of cutting it",
        on_change: HandleConsoleWrapChanged,
      },
      {
        key: "console_max_lines",
        label: "Keep lines",
        description: "How many lines the console holds before the oldest are dropped",
        on_change: HandleConsoleMaxLinesChanged,
      },
      {
        key: "console_timestamps",
        label: "Timestamps",
        description: "Show the time stamp next to every console line",
        on_change: HandleConsoleTimestampsChanged,
      },
      {
        key: "console_autoscroll",
        label: "Auto scroll",
        description: "Follow the newest line as output arrives",
        on_change: HandleConsoleAutoscrollChanged,
      },
      {
        key: "console_min_level",
        label: "Show levels",
        description: "Hide everything quieter than the level you pick",
        control: "select",
        options: [
          { value: "all", label: "Everything" },
          { value: "info", label: "Info and up" },
          { value: "warn", label: "Warnings and errors" },
          { value: "error", label: "Errors only" },
        ],
        on_change: HandleConsoleMinLevelChanged,
      },
      {
        key: "console_clear_on_run",
        label: "Clear on run",
        description: "Empty the console every time you run the active tab",
      },
      {
        key: "console_click_to_copy",
        label: "Click to copy",
        description: "Click a line of output to put it on the clipboard",
      },
      {
        key: "show_debug_output",
        label: "Show debug output",
        description: "Print startup and internal messages to the console",
        on_change: HandleShowDebugOutputChanged,
      },
      {
        key: "console_show_script_run_prints",
        label: "Show script run prints",
        description: "Print debug messages about script execution",
        on_change: HandleConsoleScriptRunPrintsChanged,
        option_default: false,
      },
      {
        key: "ConsoleRedirection",
        label: "Console redirection",
        description: "Redirect the client's console output into Hexion's console",
        is_option: true,
        option_default: true,
        on_change: HandleConsoleRedirectionChanged,
      },
    ],
  },
  {
    category: "Layout",
    rows: [
      {
        key: "explorer_visible",
        label: "Explorer",
        description: "Show the file explorer",
        get_value: GetExplorerVisible,
        on_change: HandleExplorerVisibleChanged,
      },
      {
        key: "explorer_side",
        label: "Explorer position",
        description: "Dock the explorer to the other side of the window",
        control: "select",
        options: [
          { value: "left", label: "Left" },
          { value: "right", label: "Right" },
        ],
        on_change: HandleExplorerSideChanged,
      },
      {
        key: "explorer_width",
        label: "Explorer width",
        description: "Width of the file explorer, in pixels",
        on_change: HandleExplorerWidthChanged,
      },
      {
        key: "console_visible",
        label: "Console",
        description: "Show the console",
        get_value: GetConsoleVisible,
        on_change: HandleConsoleVisibleChanged,
      },
      {
        key: "console_height",
        label: "Console height",
        description: "Height of the console, in pixels",
        on_change: HandleConsoleHeightChanged,
      },
      {
        key: "show_explorer_reveal_strip",
        label: "Explorer reveal strip",
        description: "Show the thin strip that brings a hidden explorer back",
        on_change: ApplyRevealStripsChanged,
      },
      {
        key: "show_console_reveal_strip",
        label: "Console reveal strip",
        description: "Show the thin strip that brings a hidden console back",
        on_change: ApplyRevealStripsChanged,
      },
      {
        key: "tooltip_delay_ms",
        label: "Tooltip delay",
        description: "How long to wait before a tooltip appears, in milliseconds",
      },
      {
        key: "confirm_before_delete",
        label: "Confirm before delete",
        description: "Ask before removing a file or folder from disk",
      },
      {
        key: "confirm_on_close_unsaved",
        label: "Confirm closing unsaved tabs",
        description: "Ask before closing a tab that still has unsaved changes",
      },
      {
        key: "default_file_extension",
        label: "Default file extension",
        description: "Extension given to a new file when you do not type one",
        control: "select",
        options: [
          { value: "lua", label: ".lua" },
          { value: "luau", label: ".luau" },
          { value: "txt", label: ".txt" },
        ],
      },
      {
        key: "reveal_in_os",
        label: "Reveal in file manager",
        description: "Open the Scripts folder in Windows Explorer",
        control: "action",
        action_label: "Reveal",
        on_click: HandleRevealInOs,
      },
      {
        key: "start_maximized",
        label: "Start maximized",
        description: "Open Hexion filling the screen on launch",
      },
      {
        key: "restore_tabs_on_start",
        label: "Restore tabs on start",
        description: "Reopen whatever was open the last time Hexion closed",
      },
    ],
  },
  {
    category: "Notifications",
    rows: [
      {
        key: "notifications_enabled",
        label: "Enable notifications",
        description: "Show toast notifications for script runs, attach status, and errors",
        on_change: HandleNotificationsChanged,
        option_default: false,
      },
      {
        key: "notify_duration_info",
        label: "Info duration",
        description: "How long info notifications stay visible (milliseconds)",
        control: "number",
      },
      {
        key: "notify_duration_success",
        label: "Success duration",
        description: "How long success notifications stay visible (milliseconds)",
        control: "number",
      },
      {
        key: "notify_duration_warn",
        label: "Warning duration",
        description: "How long warning notifications stay visible (milliseconds)",
        control: "number",
      },
      {
        key: "notify_duration_error",
        label: "Error duration",
        description: "How long error notifications stay visible (milliseconds)",
        control: "number",
      },
      {
        key: "notify_show_script_run",
        label: "Script run notifications",
        description: "Show notification when a script finishes running",
        on_change: HandleNotificationsChanged,
      },
      {
        key: "notify_show_attach",
        label: "Attach notifications",
        description: "Show notification when attaching to a client",
        on_change: HandleNotificationsChanged,
      },
      {
        key: "notify_show_errors",
        label: "Error notifications",
        description: "Show notification when an error occurs",
        on_change: HandleNotificationsChanged,
      },
    ],
  },
  {
    category: "Discord",
    rows: [
      {
        key: "discord_rpc_enabled",
        label: "Share presence",
        description: "Show a discord rich presence status of Hexion",
        on_change: HandleDiscordRpcEnabledChanged,
      },
      {
        control: "action",
        label: "Reconnect to Discord",
        description: "Force a fresh connection in case presence stopped updating",
        action_label: "Reconnect",
        on_click: HandleDiscordRpcReconnect,
      },
      {
        control: "action",
        label: "Join the Hexion server",
        description: "Join the Hexion Discord server",
        action_label: "Join",
        on_click: HandleJoinDiscordServer,
      },
    ],
  },
  {
    category: "Script Hub",
    rows: [
      {
        key: "rscripts_api_key",
        label: "RScripts API key",
        description: "Required to load scripts from rscripts.net — create one at rscripts.net/dashboard/api",
        control: "text",
        placeholder: "rs_...",
      },
    ],
  },
  {
    category: "Advanced",
    rows: [
      {
        key: "always_on_top",
        label: "Always on top",
        description: "Keep Hexion on top of other windows",
        on_change: HandleAlwaysOnTopChanged,
      },
      {
        key: "RenderUI",
        label: "Internal UI",
        description: "Render an Internal script editor",
        is_option: true,
        option_default: true,
      },
      {
        control: "action",
        label: "Open config folder",
        description: "Open the folder Hexion keeps its settings in",
        action_label: "Open",
        on_click: HandleOpenConfigFolder,
      },
      {
        control: "action",
        label: "Export settings",
        description: "Write every option and interface setting to a json file",
        action_label: "Export",
        on_click: HandleExportSettings,
      },
      {
        control: "action",
        label: "Import settings",
        description: "Load a previously exported json file and restart Hexion",
        action_label: "Import",
        on_click: HandleImportSettings,
      },
      {
        control: "action",
        label: "Reset settings",
        description: "Put every option and interface setting back to its default",
        action_label: "Reset",
        danger: true,
        on_click: HandleResetSettings,
      },
    ],
  },
];

const SETTINGS_PAGES = [...SETTINGS_SCHEMA, SETTINGS_SHORTCUTS_PAGE];

const SETTINGS_SHORTCUT_ACTIONS = [
  { group: "Files", entries: [
    { keys: "Ctrl+T", label: "New tab" },
    { keys: "Ctrl+W", label: "Close the active tab" },
    { keys: "Ctrl+Shift+T", label: "Reopen the last closed tab" },
    { keys: "Ctrl+O", label: "Open a file" },
    { keys: "Ctrl+S", label: "Save the active tab" },
  ] },
  { group: "Editing", entries: [
    { keys: "Ctrl+D", label: "Duplicate the current line" },
    { keys: "Ctrl+/", label: "Toggle line comment" },
    { keys: "Ctrl+X", label: "Cut selection" },
    { keys: "Ctrl+C", label: "Copy selection" },
    { keys: "Ctrl+V", label: "Paste" },
    { keys: "Ctrl+A", label: "Select all" },
    { keys: "Shift+Alt+F", label: "Format the document" },
  ] },
  { group: "Navigation", entries: [
    { keys: "Ctrl+Shift+P", label: "Open the command palette" },
    { keys: "Escape", label: "Close menus, popups and dialogs" },
  ] },
  { group: "Zoom", entries: [
    { keys: "Ctrl+Scroll", label: "Zoom the pane under the cursor" },
    { keys: "Ctrl+=", label: "Zoom in the pane under the cursor" },
    { keys: "Ctrl+-", label: "Zoom out the pane under the cursor" },
    { keys: "Ctrl+0", label: "Reset zoom on the pane under the cursor" },
  ] },
];

let settings_active_page = 0;
let settings_query = "";

function GetExplorerVisible() {
  return !UI_STATE.explorer_hidden;
}

function GetConsoleVisible() {
  return !UI_STATE.console_hidden;
}

function HandleExplorerVisibleChanged(is_on) {
  const explorer_el = document.querySelector(".explorer");
  const reveal_strip = document.getElementById("explorer-reveal-strip");

  if (!explorer_el || !reveal_strip) {
    return;
  }

  SetExplorerHidden(explorer_el, reveal_strip, !is_on);
}

function HandleConsoleVisibleChanged(is_on) {
  SetConsoleHidden(!is_on);
}

function HandleExplorerSideChanged(side) {
  ApplyExplorerSide(side);
}

function HandleExplorerWidthChanged(width_px) {
  SetExplorerWidth(width_px);
}

function HandleConsoleHeightChanged(height_px) {
  SetConsoleHeight(height_px);
}

function HandleAccentColorChanged(hex_color) {
  ApplyAccentColor(hex_color);
  SaveUiState();
}

function HandleDensityChanged(density) {
  ApplyUiDensity();
  RefreshEditorMetrics();
}

function HandleThemeChanged() {
  ApplyUiTheme();
  ApplyAccentColor(UI_STATE.accent_color);
  RefreshEditorMetrics();
}

function HandleExplorerFileSizesChanged() {
  RenderExplorerSections({ quiet: true });
}

function HandleMotionChanged() {
  ApplyUiMotion();
}

function HandleUiFontChanged() {
  ApplyUiFonts();
}

function HandleEditorFontSizeChanged(size_px) {
  ApplyEditorFontSize(size_px);
  RefreshEditorMetrics();
}

function HandleEditorIndentChanged() {
  ApplyEditorIndent();
  RefreshEditorMetrics();
}

function HandleEditorLineHeightChanged() {
  ApplyEditorFontSize(UI_STATE.editor_font_size_px);
  RefreshEditorMetrics();
}

function HandleEditorCaretStyleChanged() {
  ApplyEditorCaretStyle();
}

function HandleEditorCaretBlinkChanged() {
  ApplyEditorCaretStyle();
}

function HandleEditorSelectionStyleChanged() {
  ApplyEditorSelectionStyle();
}

function HandleConsoleFontSizeChanged() {
  ApplyConsoleFontSize(UI_STATE.console_font_size_px);
}

function HandleConsoleLineHeightChanged() {
  ApplyConsoleFontSize(UI_STATE.console_font_size_px);
}

function HandleConsoleWrapChanged() {
  ApplyConsoleWrap();
}

function HandleConsoleMaxLinesChanged() {
  TrimConsoleOutput();
}

function HandleShowDebugOutputChanged(is_on) {
  if (is_on) {
    ReloadConsoleHistory();
    return;
  }

  ClearConsole();
}

function HandleGutterChanged(is_on) {
  SetEditorGutterVisible(is_on);
}

function HandleIndentGuidesChanged(is_on) {
  SetEditorIndentGuidesVisible(is_on);
}

function HandleActiveLineChanged(is_on) {
  SetEditorActiveLineVisible(is_on);
}

function HandleProblemsChanged(is_on) {
  SetEditorProblemsVisible(is_on);
}

function HandleConsoleTimestampsChanged() {
  ReloadConsoleHistory();
}

function HandleConsoleAutoscrollChanged() {
  if (UI_STATE.console_autoscroll !== false) {
    ScrollConsoleToBottom();
  }
}

function HandleConsoleMinLevelChanged() {
  ReloadConsoleHistory();
}

function ApplyRevealStripsChanged() {
  ApplyRevealStrips();
}

async function HandleOpenConfigFolder() {
  try {
    const opened = await window.__TAURI__.core.invoke("open_config_folder");
    LogPrint(`opened ${opened}`);
  } catch (err) {
    LogWarn(`could not open the config folder: ${err && err.message ? err.message : err}`);
  }
}

async function RevealPathInFileManager(path) {
  if (!window.__TAURI__) {
    return;
  }

  try {
    await window.__TAURI__.core.invoke("reveal_path", { path });
  } catch (err) {
    LogWarn(`could not reveal ${path}: ${err && err.message ? err.message : err}`);
  }
}

async function HandleRevealInOs() {
  const base_dir = await GetBaseDir();
  await RevealPathInFileManager(await JoinPath(base_dir, "scripts"));
}

async function HandleAlwaysOnTopChanged(is_on) {
  if (!window.__TAURI__ || !window.__TAURI__.window) {
    return;
  }

  try {
    const app_window = GetAppWindow();
    const maximized = await app_window.isMaximized();

    if (is_on && maximized) {
      await app_window.setAlwaysOnTop(false);
    } else {
      await app_window.setAlwaysOnTop(is_on);
    }
  } catch (err) {
    LogWarn("could not keep Hexion on top:", err);
  }
}

function HandleNotificationsChanged(is_on) {
}

function HandleNotifyDurationChanged() {
}

function HandleConsoleScriptRunPrintsChanged(is_on) {
}

async function HandleResetSettings() {
  const confirmed = await ShowConfirmModal(
    "Reset settings?",
    "Every option and interface setting goes back to its default. Your scripts and tabs are left alone.",
    { confirm_label: "Reset", danger: true }
  );

  if (!confirmed) {
    return;
  }

  ResetUiStateValues();
  ResetOptionValues();
  await Promise.all([WriteUiStateNow(), SaveOptionsNow()]);
  window.location.reload();
}

async function HandleExportSettings() {
  if (!window.__TAURI__ || !window.__TAURI__.dialog) {
    Notify("Export needs the desktop app", "error");
    return;
  }

  const target_path = await window.__TAURI__.dialog.save({
    defaultPath: "hexion-settings.json",
    filters: [{ name: "Json", extensions: ["json"] }],
  });

  if (!target_path) {
    return;
  }

  try {
    await WriteSettingsBundle(target_path);
    LogPrint(`exported settings to ${target_path}`);
    Notify("Settings exported", "success");
  } catch (err) {
    LogError(`export failed: ${err && err.message ? err.message : err}`);
    Notify("Could not export settings", "error");
  }
}

async function HandleImportSettings() {
  if (!window.__TAURI__ || !window.__TAURI__.dialog) {
    Notify("Import needs the desktop app", "error");
    return;
  }

  const picked = await window.__TAURI__.dialog.open({
    multiple: false,
    filters: [{ name: "Json", extensions: ["json"] }],
  });

  const source_path = Array.isArray(picked) ? picked[0] : picked;

  if (!source_path) {
    return;
  }

  let bundle;

  try {
    bundle = ParseSettingsBundle(await FsReadTextFile(source_path));
  } catch (err) {
    LogError(`import failed: ${err && err.message ? err.message : err}`);
    Notify(err && err.message ? err.message : "Could not read that file", "error");
    return;
  }

  const confirmed = await ShowConfirmModal(
    "Import settings?",
    "Everything in the export replaces your current options and interface settings, then Hexion restarts.",
    { confirm_label: "Import", danger: true }
  );

  if (!confirmed) {
    return;
  }

  try {
    await ApplySettingsBundle(bundle);
    LogPrint(`imported settings from ${source_path}`);
    window.location.reload();
  } catch (err) {
    LogError(`import failed: ${err && err.message ? err.message : err}`);
    Notify("Could not import settings", "error");
  }
}

function GetSettingValue(row) {
  if (row.get_value) {
    return row.get_value();
  }

  if (row.is_option) {
    return GetOption(row.key);
  }

  return UI_STATE[row.key];
}

function SetSettingValue(row, value) {
  if (row.set_value) {
    row.set_value(value);
    return;
  }

  if (row.is_option) {
    SetOption(row.key, value);
    return;
  }

  UI_STATE[row.key] = value;
  SaveUiState();
}

async function NotifySettingChanged(row, value) {
  if (!row.on_change) {
    return;
  }

  try {
    await row.on_change(value);
  } catch (err) {
    LogError(`${row.label} failed: ${err && err.message ? err.message : err}`);
    Notify(`${row.label} failed`, "error");
  }
}

function GetSettingsEls() {
  return {
    overlay: document.getElementById("settings-overlay"),
    body: document.getElementById("settings-panel-body"),
    close_btn: document.getElementById("settings-panel-close"),
    search_input: document.getElementById("settings-search-input"),
    search_clear: document.getElementById("settings-search-clear"),
  };
}

function GetSettingBounds(row) {
  const range = UI_STATE_RANGES[row.key];

  if (range) {
    return { min: range[0], max: range[1], step: range[2] || 1 };
  }

  return { min: row.min, max: row.max, step: 1 };
}

function GetSettingRowControl(row) {
  if (row.control === "select") {
    return BuildSettingsSelect(row);
  }

  if (row.control === "color") {
    return BuildSettingsColor(row);
  }

  if (row.control === "action") {
    return BuildSettingsAction(row);
  }

  if (row.control === "number" || UI_STATE_RANGES[row.key]) {
    return BuildSettingsNumber(row);
  }

  if (row.control === "text") {
    return BuildSettingsText(row);
  }

  return BuildSettingsSwitch(row);
}

// Text input control for string settings (e.g. the RScripts API key)
function BuildSettingsText(row) {
  const input_el = document.createElement("input");
  input_el.type = "text";
  input_el.className = "settings-text-input";
  input_el.placeholder = row.placeholder || "";
  input_el.autocapitalize = "off";
  input_el.autocomplete = "off";
  input_el.spellcheck = false;
  input_el.value = GetSettingValue(row) || "";

  input_el.addEventListener("change", () => {
    SetSettingValue(row, input_el.value);
    NotifySettingChanged(row, input_el.value);
  });

  return input_el;
}

function BuildSettingsSwitch(row) {
  const switch_btn = document.createElement("button");
  switch_btn.className = "settings-switch";
  switch_btn.setAttribute("role", "switch");

  const knob_el = document.createElement("span");
  knob_el.className = "settings-switch-knob";
  switch_btn.appendChild(knob_el);

  const SyncSwitch = () => {
    const is_on = Boolean(GetSettingValue(row));
    switch_btn.classList.toggle("settings-switch-on", is_on);
    switch_btn.setAttribute("aria-checked", String(is_on));
  };

  switch_btn.addEventListener("click", () => {
    const next_value = !GetSettingValue(row);
    SetSettingValue(row, next_value);
    NotifySettingChanged(row, next_value);
    SyncSwitch();
  });

  SyncSwitch();

  return switch_btn;
}

function FindSelectedOption(row) {
  return row.options.find((option) => String(option.value) === String(GetSettingValue(row)));
}

function ApplyOptionStyle(option_el, row, option) {
  if (!option) {
    return;
  }

  if (row.preview_font_weight) {
    option_el.style.fontWeight = option.value;
    return;
  }

  if (option.preview) {
    option_el.style.fontFamily = FontStack(option.value, CODE_FONT_FALLBACKS);
  }
}

function CloseOpenSelectMenus() {
  document.querySelectorAll(".settings-select-menu").forEach((menu) => {
    menu.hidden = true;
    menu.classList.remove("settings-select-menu-up");
  });

  document.querySelectorAll(".settings-select-btn").forEach((btn) => {
    btn.setAttribute("aria-expanded", "false");
    btn.classList.remove("settings-select-btn-open");
  });
}

function FlipSelectMenuIfClipped(wrap_el, menu_el) {
  const scroll_el = wrap_el.closest(".settings-page-scroll");

  if (!scroll_el) {
    return;
  }

  const menu_rect = menu_el.getBoundingClientRect();
  const scroll_rect = scroll_el.getBoundingClientRect();

  if (menu_rect.bottom > scroll_rect.bottom) {
    menu_el.classList.add("settings-select-menu-up");
    return;
  }

  menu_el.classList.remove("settings-select-menu-up");
}

function BuildSettingsSelect(row) {
  const wrap_el = document.createElement("div");
  wrap_el.className = "settings-select";

  const btn_el = document.createElement("button");
  btn_el.className = "settings-select-btn";
  btn_el.setAttribute("aria-haspopup", "listbox");
  btn_el.setAttribute("aria-expanded", "false");

  const value_el = document.createElement("span");
  value_el.className = "settings-select-value";

  const selected_option = FindSelectedOption(row);
  value_el.textContent = selected_option ? selected_option.label : String(GetSettingValue(row));
  ApplyOptionStyle(value_el, row, selected_option);

  const chevron_el = document.createElement("span");
  chevron_el.className = "settings-select-chevron";
  chevron_el.innerHTML = IconTag("chevrondown");

  btn_el.appendChild(value_el);
  btn_el.appendChild(chevron_el);

  const menu_el = document.createElement("div");
  menu_el.className = "settings-select-menu";
  menu_el.setAttribute("role", "listbox");
  menu_el.hidden = true;

  const SyncSelection = () => {
    const next_option = FindSelectedOption(row);

    if (next_option) {
      value_el.textContent = next_option.label;
      ApplyOptionStyle(value_el, row, next_option);
    }

    for (const option_el of menu_el.children) {
      const is_active = String(option_el.dataset.value) === String(GetSettingValue(row));
      option_el.classList.toggle("settings-select-option-active", is_active);
      option_el.setAttribute("aria-selected", String(is_active));
    }
  };

  for (const option of row.options) {
    const option_el = document.createElement("button");
    option_el.className = "settings-select-option";
    option_el.dataset.value = option.value;
    option_el.setAttribute("role", "option");

    const label_el = document.createElement("span");
    label_el.className = "settings-select-option-label";
    label_el.textContent = option.label;
    option_el.appendChild(label_el);

    if (option.hint) {
      const hint_el = document.createElement("span");
      hint_el.className = "settings-select-option-hint";
      hint_el.textContent = option.hint;
      option_el.appendChild(hint_el);
    }

    ApplyOptionStyle(label_el, row, option);

    option_el.addEventListener("click", () => {
      SetSettingValue(row, option.value);
      NotifySettingChanged(row, option.value);
      SyncSelection();
      CloseOpenSelectMenus();
    });

    menu_el.appendChild(option_el);
  }

  btn_el.addEventListener("click", (event) => {
    event.stopPropagation();

    const should_open = menu_el.hidden;
    CloseOpenSelectMenus();

    if (should_open) {
      menu_el.hidden = false;
      btn_el.setAttribute("aria-expanded", "true");
      btn_el.classList.add("settings-select-btn-open");
      FlipSelectMenuIfClipped(wrap_el, menu_el);
    }
  });

  menu_el.addEventListener("click", (event) => {
    event.stopPropagation();
  });

  wrap_el.appendChild(btn_el);
  wrap_el.appendChild(menu_el);

  SyncSelection();

  return wrap_el;
}

function BuildSettingsColor(row) {
  const wrap_el = document.createElement("div");
  wrap_el.className = "settings-color";

  const swatch_el = document.createElement("span");
  swatch_el.className = "settings-color-swatch";

  const fill_el = document.createElement("span");
  fill_el.className = "settings-color-fill";

  const input_el = document.createElement("input");
  input_el.type = "color";
  input_el.spellcheck = false;

  const SyncFill = () => {
    const current = NormalizeHexColor(GetSettingValue(row)) || UI_STATE_DEFAULTS.accent_color;
    fill_el.style.backgroundColor = current;
    input_el.value = current;
  };

  input_el.addEventListener("input", () => {
    const next_value = NormalizeHexColor(input_el.value);

    if (!next_value) {
      return;
    }

    fill_el.style.backgroundColor = next_value;
    SetSettingValue(row, next_value);
    NotifySettingChanged(row, next_value);
  });

  input_el.addEventListener("change", () => {
    SyncFill();
  });

  wrap_el.appendChild(swatch_el);
  wrap_el.appendChild(fill_el);
  wrap_el.appendChild(input_el);

  SyncFill();

  return wrap_el;
}

function BuildSettingsNumber(row) {
  const { min, max, step } = GetSettingBounds(row);

  const wrap_el = document.createElement("div");
  wrap_el.className = "settings-number";

  const down_btn = document.createElement("button");
  down_btn.className = "settings-number-btn";
  down_btn.type = "button";
  down_btn.dataset.tooltip = `Decrease ${row.label.toLowerCase()}`;
  down_btn.innerHTML = IconTag("minus");

  const up_btn = document.createElement("button");
  up_btn.className = "settings-number-btn";
  up_btn.type = "button";
  up_btn.dataset.tooltip = `Increase ${row.label.toLowerCase()}`;
  up_btn.innerHTML = IconTag("plus");

  const input_el = document.createElement("input");
  input_el.className = "settings-number-input";
  input_el.type = "text";
  input_el.inputMode = "decimal";
  input_el.spellcheck = false;
  input_el.dataset.tooltip = `Type a value from ${min} to ${max}`;

  const ReadValue = () => Number(GetSettingValue(row));

  const ClampValue = (raw_value) => {
    const parsed = Number.parseFloat(String(raw_value).trim());

    if (!Number.isFinite(parsed)) {
      return Math.min(Math.max(ReadValue(), min), max);
    }

    return Math.min(Math.max(parsed, min), max);
  };

  const FormatValue = (value) => String(Math.round(value * 1000) / 1000);

  const SyncNumber = (is_editing) => {
    if (!is_editing) {
      input_el.value = FormatValue(ClampValue(ReadValue()));
    }

    down_btn.disabled = ReadValue() <= min;
    up_btn.disabled = ReadValue() >= max;
  };

  const Commit = (raw_value) => {
    const next_value = ClampValue(raw_value);

    if (next_value !== ReadValue()) {
      SetSettingValue(row, next_value);
      NotifySettingChanged(row, next_value);
    }

    SyncNumber(false);
  };

  const Step = (direction) => {
    const next_value = ClampValue(ReadValue() + step * direction);

    if (next_value === ReadValue()) {
      SyncNumber(false);
      return;
    }

    SetSettingValue(row, next_value);
    NotifySettingChanged(row, next_value);
    SyncNumber(false);
  };

  down_btn.addEventListener("click", () => Step(-1));
  up_btn.addEventListener("click", () => Step(1));

  input_el.addEventListener("focus", () => input_el.select());
  input_el.addEventListener("input", () => SyncNumber(true));
  input_el.addEventListener("blur", () => Commit(input_el.value));

  input_el.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      Commit(input_el.value);
      input_el.blur();
      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      Step(1);
      return;
    }

    if (event.key === "ArrowDown") {
      event.preventDefault();
      Step(-1);
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      input_el.value = FormatValue(ReadValue());
      input_el.blur();
    }
  });

  wrap_el.appendChild(down_btn);
  wrap_el.appendChild(input_el);
  wrap_el.appendChild(up_btn);

  SyncNumber(false);

  return wrap_el;
}

function BuildSettingsAction(row) {
  const action_btn = document.createElement("button");
  action_btn.className = row.danger ? "settings-action settings-action-danger" : "settings-action";
  action_btn.textContent = row.action_label;

  action_btn.addEventListener("click", async () => {
    if (!row.on_click) {
      return;
    }

    action_btn.disabled = true;

    try {
      await row.on_click();
    } catch (err) {
      LogError(`${row.label} failed: ${err && err.message ? err.message : err}`);
      Notify(`${row.label} failed`, "error");
    } finally {
      action_btn.disabled = false;
    }
  });

  return action_btn;
}

function BuildSettingsRow(row) {
  const row_el = document.createElement("div");
  row_el.className = "settings-row";

  const text_el = document.createElement("div");
  text_el.className = "settings-row-text";

  const label_el = document.createElement("span");
  label_el.className = "settings-row-label";
  label_el.textContent = row.label;
  text_el.appendChild(label_el);

  if (row.description) {
    const desc_el = document.createElement("span");
    desc_el.className = "settings-row-desc";
    desc_el.textContent = row.description;
    text_el.appendChild(desc_el);
  }

  const controls_el = document.createElement("div");
  controls_el.className = "settings-row-controls";
  controls_el.appendChild(GetSettingRowControl(row));

  row_el.appendChild(text_el);
  row_el.appendChild(controls_el);

  return row_el;
}

function BuildSettingsGroupLabel(text) {
  const group_el = document.createElement("div");
  group_el.className = "settings-group-label";
  group_el.textContent = text;
  return group_el;
}

function BuildSettingsShortcutRow(entry) {
  const row_el = document.createElement("div");
  row_el.className = "settings-shortcut-row";

  const label_el = document.createElement("span");
  label_el.className = "settings-shortcut-label";
  label_el.textContent = entry.label;
  row_el.appendChild(label_el);

  const keys_el = document.createElement("span");
  keys_el.className = "settings-shortcut-keys";
  keys_el.textContent = entry.keys.replace(/\+/g, " + ");
  row_el.appendChild(keys_el);

  return row_el;
}

function FlattenSettingsShortcuts() {
  const entries = [];

  for (const action_group of SETTINGS_SHORTCUT_ACTIONS) {
    for (const entry of action_group.entries) {
      entries.push({ ...entry, group: action_group.group });
    }
  }

  return entries;
}

function NormalizeSearchQuery(raw_text) {
  return String(raw_text || "").trim().toLowerCase();
}

function RowMatchesQuery(row, query) {
  return `${row.label} ${row.description || ""}`.toLowerCase().includes(query);
}

function ShortcutMatchesQuery(entry, query) {
  return `${entry.label} ${entry.keys} ${entry.group}`.toLowerCase().includes(query);
}

function BuildSettingsNavItem(page, page_index, query) {
  const item_el = document.createElement("button");
  item_el.className = "settings-nav-item";

  if (page === SETTINGS_SHORTCUTS_PAGE) {
    item_el.classList.add("settings-nav-item-pinned");
  }

  if (query.length === 0 && page_index === settings_active_page) {
    item_el.classList.add("settings-nav-item-active");
  }

  item_el.textContent = page.category;

  item_el.addEventListener("click", () => {
    const { search_input } = GetSettingsEls();

    if (query.length > 0 && search_input) {
      search_input.value = "";
      settings_query = "";
    }

    if (settings_active_page === page_index) {
      return;
    }

    CloseOpenSelectMenus();
    settings_active_page = page_index;
    RenderSettingsPanel();
  });

  return item_el;
}

function BuildSettingsNav(query) {
  const nav_el = document.createElement("div");
  nav_el.className = "settings-nav";

  SETTINGS_PAGES.forEach((page, page_index) => {
    nav_el.appendChild(BuildSettingsNavItem(page, page_index, query));
  });

  return nav_el;
}

function BuildSettingsRowsPage(page) {
  const page_el = document.createElement("div");
  page_el.className = "settings-page";

  const scroll_el = document.createElement("div");
  scroll_el.className = "settings-page-scroll";

  for (const row of page.rows) {
    scroll_el.appendChild(BuildSettingsRow(row));
  }

  if (page.rows.length === 0) {
    const empty_el = document.createElement("div");
    empty_el.className = "settings-empty";
    empty_el.textContent = "Nothing to change here";
    scroll_el.appendChild(empty_el);
  }

  page_el.appendChild(scroll_el);

  return page_el;
}

function BuildSettingsShortcutsPage() {
  const page_el = document.createElement("div");
  page_el.className = "settings-page";

  const scroll_el = document.createElement("div");
  scroll_el.className = "settings-page-scroll";

  for (const action_group of SETTINGS_SHORTCUT_ACTIONS) {
    scroll_el.appendChild(BuildSettingsGroupLabel(action_group.group));

    const section_el = document.createElement("div");
    section_el.className = "settings-shortcuts-section";

    for (const entry of action_group.entries) {
      section_el.appendChild(BuildSettingsShortcutRow(entry));
    }

    scroll_el.appendChild(section_el);
  }

  page_el.appendChild(scroll_el);

  return page_el;
}

function BuildSettingsSearchPage(query) {
  const page_el = document.createElement("div");
  page_el.className = "settings-page";

  let match_count = 0;

  for (const page of SETTINGS_SCHEMA) {
    match_count += page.rows.filter((row) => RowMatchesQuery(row, query)).length;
  }

  const matched_shortcuts = FlattenSettingsShortcuts().filter((entry) => ShortcutMatchesQuery(entry, query));
  match_count += matched_shortcuts.length;

  const scroll_el = document.createElement("div");
  scroll_el.className = "settings-page-scroll";

  const result_head = document.createElement("div");
  result_head.className = "settings-result-head";
  result_head.textContent =
    match_count === 0 ? "No matches" : `${match_count} match${match_count === 1 ? "" : "es"}`;
  scroll_el.appendChild(result_head);

  for (const page of SETTINGS_SCHEMA) {
    const matched_rows = page.rows.filter((row) => RowMatchesQuery(row, query));

    if (matched_rows.length === 0) {
      continue;
    }

    scroll_el.appendChild(BuildSettingsGroupLabel(page.category));

    for (const row of matched_rows) {
      scroll_el.appendChild(BuildSettingsRow(row));
    }
  }

  if (matched_shortcuts.length > 0) {
    scroll_el.appendChild(BuildSettingsGroupLabel(SETTINGS_SHORTCUTS_PAGE.category));

    const section_el = document.createElement("div");
    section_el.className = "settings-shortcuts-section";

    for (const entry of matched_shortcuts) {
      section_el.appendChild(BuildSettingsShortcutRow(entry));
    }

    scroll_el.appendChild(section_el);
  }

  if (match_count === 0) {
    const empty_el = document.createElement("div");
    empty_el.className = "settings-empty";
    empty_el.textContent = `Nothing matches "${query}"`;

    const hint_el = document.createElement("span");
    hint_el.className = "settings-empty-hint";
    hint_el.textContent = "Try a shorter word, like font, console, caret or tab";
    empty_el.appendChild(hint_el);

    scroll_el.appendChild(empty_el);
  }

  page_el.appendChild(scroll_el);

  return page_el;
}

function RenderSettingsPanel() {
  const { body } = GetSettingsEls();

  if (!body) {
    return;
  }

  if (settings_active_page >= SETTINGS_PAGES.length) {
    settings_active_page = 0;
  }

  CloseOpenSelectMenus();
  body.innerHTML = "";
  body.appendChild(BuildSettingsNav(settings_query));

  if (settings_query.length > 0) {
    body.appendChild(BuildSettingsSearchPage(settings_query));
    return;
  }

  body.appendChild(
    settings_active_page === SETTINGS_SCHEMA.length
      ? BuildSettingsShortcutsPage()
      : BuildSettingsRowsPage(SETTINGS_SCHEMA[settings_active_page])
  );
}

function SetSettingsQuery(raw_text) {
  const { search_clear, search_input } = GetSettingsEls();
  const next_query = NormalizeSearchQuery(raw_text);

  if (search_clear) {
    search_clear.hidden = raw_text.length === 0;
  }

  if (search_input && search_input.value !== next_query) {
    search_input.value = next_query;
  }

  if (next_query === settings_query) {
    return;
  }

  settings_query = next_query;
  RenderSettingsPanel();
}

function FocusSettingsSearch() {
  const { search_input } = GetSettingsEls();

  if (search_input) {
    search_input.focus();
    search_input.select();
  }
}

function OpenSettingsPanel() {
  const { overlay } = GetSettingsEls();

  if (!overlay) {
    return;
  }

  RenderSettingsPanel();
  overlay.classList.add("settings-overlay-visible");
}

function OpenSettingsPage(page_index) {
  const { search_input, search_clear } = GetSettingsEls();

  if (search_input) {
    search_input.value = "";
  }

  if (search_clear) {
    search_clear.hidden = true;
  }

  settings_query = "";
  settings_active_page = Math.min(Math.max(Number(page_index) || 0, 0), SETTINGS_PAGES.length - 1);
  OpenSettingsPanel();
}

function OpenSettingsCategory(category_name) {
  const page_index = SETTINGS_PAGES.findIndex((page) => page.category === category_name);

  OpenSettingsPage(page_index < 0 ? 0 : page_index);
}

function CloseSettingsPanel() {
  const { overlay } = GetSettingsEls();

  if (!overlay) {
    return;
  }

  CloseOpenSelectMenus();
  overlay.classList.remove("settings-overlay-visible");
}

function SetupSettingsSearch() {
  const { search_input, search_clear } = GetSettingsEls();

  if (!search_input) {
    return;
  }

  search_input.addEventListener("input", () => {
    SetSettingsQuery(search_input.value);
  });

  search_input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      event.preventDefault();
      search_input.value = "";
      SetSettingsQuery("");
    }
  });

  if (search_clear) {
    search_clear.addEventListener("click", () => {
      search_input.value = "";
      SetSettingsQuery("");
      search_input.focus();
    });
  }
}

function SetupSettingsPanel() {
  const { overlay, close_btn } = GetSettingsEls();
  const options_btn = document.getElementById("console-options-btn");

  if (!overlay || !close_btn || !options_btn) {
    LogError("settings elements missing, settings panel not initialised");
    return;
  }

  options_btn.addEventListener("click", OpenSettingsPanel);
  close_btn.addEventListener("click", CloseSettingsPanel);
  SetupSettingsSearch();

  document.addEventListener("click", CloseOpenSelectMenus);

  overlay.addEventListener("mousedown", (event) => {
    if (event.target === overlay) {
      CloseSettingsPanel();
    }
  });

  window.addEventListener("keydown", (event) => {
    if (!overlay.classList.contains("settings-overlay-visible")) {
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      CloseSettingsPanel();
      return;
    }

    const has_mod = event.ctrlKey || event.metaKey;

    if (has_mod && !event.shiftKey && !event.altKey && event.key.toLowerCase() === "f") {
      event.preventDefault();
      FocusSettingsSearch();
    }
  });
}

async function ApplyUiStateSettings() {
  for (const page of SETTINGS_SCHEMA) {
    for (const row of page.rows) {
      if (row.control === "action" || !row.on_change) {
        continue;
      }

      await RunSafe(`ApplyUiStateSettings:${row.key || row.label}`, async () => {
        NotifySettingChanged(row, GetSettingValue(row));
      });
    }
  }
}
