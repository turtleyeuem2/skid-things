const ICON_VIEW_BOX = "0 0 24 24";

const ICON_STROKE_BODIES = {
  align: '<path d="M4 6.5h16"/><path d="M4 12h10.5"/><path d="M4 17.5h13.5"/>',
  arrowleft: '<path d="M15 5.5 8.5 12 15 18.5"/>',
  arrowright: '<path d="M9 5.5 15.5 12 9 18.5"/>',
  arrowup: '<path d="M5.5 15 12 8.5 18.5 15"/>',
  ban: '<circle cx="12" cy="12" r="8.5"/><path d="M6 6 18 18"/>',
  braces: '<path d="M9.5 4H8.4A2.4 2.4 0 0 0 6 6.4v2.9a2.2 2.2 0 0 1-1.3 2.1 2.2 2.2 0 0 1 1.3 2.1v4.1A2.4 2.4 0 0 0 8.4 20h1.1"/><path d="M14.5 4h1.1A2.4 2.4 0 0 1 18 6.4v2.9a2.2 2.2 0 0 0 1.3 2.1 2.2 2.2 0 0 0-1.3 2.1v4.1a2.4 2.4 0 0 1-2.4 2.4h-1.1"/>',
  check: '<path d="M20 6.5 9.5 17 4 11.5"/>',
  chevrondown: '<path d="M5.5 9.5 12 16l6.5-6.5"/>',
  chevronright: '<path d="M9.5 5.5 16 12l-6.5 6.5"/>',
  client: '<rect x="3" y="4.5" width="18" height="13" rx="2.5"/><path d="M8.5 20.5h7"/><path d="M12 17.5v3"/>',
  cleareditor: '<path d="M14.2 4.6 19.4 9.8a1.4 1.4 0 0 1 0 2L13 18.2a1.4 1.4 0 0 1-2 0l-5.2-5.2a1.4 1.4 0 0 1 0-2l6.2-6.2a1.4 1.4 0 0 1 2 0Z"/><path d="M9 9.8 14.2 15"/><path d="M9.5 19.5H20"/>',
  close: '<path d="M18 6 6 18"/><path d="M6 6 12 12"/><path d="M12 12 18 18"/>',
  codefile: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5"/><path d="M10.4 12 9 14.5l1.4 2.5"/><path d="M13.6 12 15 14.5l-1.4 2.5"/>',
  comment: '<path d="M21 11.5a8.4 8.4 0 0 1-8.4 8.4H8.2L3.5 22l1.1-4.9A8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4Z"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M15 5.6V5.4A2.4 2.4 0 0 0 12.6 3H6A2.4 2.4 0 0 0 3.6 5.4v6.6A2.4 2.4 0 0 0 6 14.4h.4"/>',
  cut: '<circle cx="6.5" cy="7" r="2.5"/><circle cx="6.5" cy="17" r="2.5"/><path d="M8.6 8.6 20 20"/><path d="M20 4 8.6 15.4"/>',
  duplicate: '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M15 5.6V5.4A2.4 2.4 0 0 0 12.6 3H6A2.4 2.4 0 0 0 3.6 5.4v6.6A2.4 2.4 0 0 0 6 14.4h.4"/><path d="M15 12.4v5.2"/><path d="M12.4 15h5.2"/>',
  error: '<circle cx="12" cy="12" r="8.5"/><path d="M15 9 9 15"/><path d="M9 9 15 15"/>',
  eyeoff: '<path d="M9.9 5.3A9.7 9.7 0 0 1 12 5c6 0 9.5 7 9.5 7a17.6 17.6 0 0 1-2.7 3.7"/><path d="M6.4 7.4A17.4 17.4 0 0 0 2.5 12S6 19 12 19a9.3 9.3 0 0 0 4.1-.9"/><path d="M10 10a2.9 2.9 0 0 0 4 4"/><path d="M3.5 3.5 20.5 20.5"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5"/>',
  folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h3.6a2 2 0 0 1 1.52.7l1.1 1.3h6.78a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2Z"/>',
  folderopen: '<path d="M3.5 10.5V7.5a2 2 0 0 1 2-2h3.6a2 2 0 0 1 1.52.7l1.1 1.3h6.78a2 2 0 0 1 2 2v.5"/><path d="M3.5 10.5h16.1a1 1 0 0 1 .95 1.32l-1.83 6.3A2 2 0 0 1 16.75 19.5H5.5a2 2 0 0 1-2-2Z"/>',
  history: '<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3.5 4.6V10H9"/><path d="M12 7.5V12l3.2 2"/>',
  indentin: '<path d="M4 6h16"/><path d="M4 18h16"/><path d="M10.5 12h9.5"/><path d="M4.5 9.5 8 12l-3.5 2.5"/>',
  indentout: '<path d="M4 6h16"/><path d="M4 18h16"/><path d="M10.5 12h9.5"/><path d="M8.5 9.5 5 12l3.5 2.5"/>',
  keyboard: '<rect x="2.5" y="5.5" width="19" height="13" rx="2.4"/><path d="M6 9.5h.01"/><path d="M9.5 9.5h.01"/><path d="M13 9.5h.01"/><path d="M16.5 9.5h.01"/><path d="M8 13.5h8"/>',
  layout: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><path d="M9.5 4.5v15"/>',
  maximize: '<rect x="4.5" y="4.5" width="15" height="15" rx="2.5"/>',
  minimize: '<path d="M5.5 12h13"/>',
  minus: '<path d="M6 12h12"/>',
  move: '<path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>',
  newtab: '<path d="M12 5.5v13"/><path d="M5.5 12h13"/>',
  open: '<path d="M11 4.5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-5"/><path d="M14.5 3.5h6v6"/><path d="M20 4 10.5 13.5"/>',
  paste: '<path d="M9 4.5H7.5A2.5 2.5 0 0 0 5 7v11.5A2.5 2.5 0 0 0 7.5 21h9a2.5 2.5 0 0 0 2.5-2.5V7a2.5 2.5 0 0 0-2.5-2.5H15"/><rect x="9" y="2.5" width="6" height="4" rx="1.2"/>',
  pencil: '<path d="M16.6 3.9a2.3 2.3 0 0 1 3.25 3.25L7.4 19.6 3.5 20.5l.9-3.9Z"/><path d="M14.5 6l3.25 3.25"/>',
  pin: '<path d="M9.5 3.5h5l-.6 5.2 3.1 3.3H7l3.1-3.3Z"/><path d="M12 12v8.5"/>',
  plug: '<path d="M9 3.5v5"/><path d="M15 3.5v5"/><path d="M6.5 8.5h11v3a5.5 5.5 0 0 1-11 0Z"/><path d="M12 17v3.5"/>',
  plus: '<path d="M12 5.5v13"/><path d="M5.5 12h13"/>',
  redo: '<path d="M20 15.5V9.5a4 4 0 0 0-4-4H7.5"/><path d="M11 2.5 7.5 5.5 11 8.5"/>',
  refresh: '<path d="M20.5 12a8.5 8.5 0 1 1-2.49-6.01"/><path d="M20.5 4.2v4.6h-4.6"/>',
  resetzoom: '<path d="M4 8.5V5a1 1 0 0 1 1-1h3.5"/><path d="M20 8.5V5a1 1 0 0 0-1-1h-3.5"/><path d="M4 15.5V19a1 1 0 0 0 1 1h3.5"/><path d="M20 15.5V19a1 1 0 0 1-1 1h-3.5"/><path d="M9 12h6"/>',
  save: '<path d="M19.5 20.5h-15A1.5 1.5 0 0 1 3 19V5a1.5 1.5 0 0 1 1.5-1.5h11L21 9.5V19a1.5 1.5 0 0 1-1.5 1.5Z"/><path d="M7.5 3.5v5h7v-5"/><path d="M7.5 20.5v-6h9v6"/>',
  search: '<circle cx="11" cy="11" r="6.75"/><path d="M15.8 15.8 20.5 20.5"/>',
  selectall: '<path d="M4 8.5V5.5A1.5 1.5 0 0 1 5.5 4h3"/><path d="M15.5 4h3A1.5 1.5 0 0 1 20 5.5v3"/><path d="M20 15.5v3a1.5 1.5 0 0 1-1.5 1.5h-3"/><path d="M8.5 20h-3A1.5 1.5 0 0 1 4 18.5v-3"/><path d="M12 8.5v7"/><path d="M8.5 12h7"/>',
  settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.3 14.6a1.5 1.5 0 0 0 .3 1.66l.06.05a1.85 1.85 0 1 1-2.62 2.62l-.05-.05a1.5 1.5 0 0 0-1.66-.3 1.5 1.5 0 0 0-.91 1.37v.15a1.85 1.85 0 1 1-3.7 0v-.08a1.5 1.5 0 0 0-.98-1.37 1.5 1.5 0 0 0-1.66.3l-.05.05a1.85 1.85 0 1 1-2.62-2.62l.05-.05a1.5 1.5 0 0 0 .3-1.66 1.5 1.5 0 0 0-1.37-.91H4.2a1.85 1.85 0 1 1 0-3.7h.08a1.5 1.5 0 0 0 1.37-.98 1.5 1.5 0 0 0-.3-1.66l-.05-.05A1.85 1.85 0 1 1 7.92 5.77l.05.05a1.5 1.5 0 0 0 1.66.3h.07a1.5 1.5 0 0 0 .91-1.37V4.2a1.85 1.85 0 1 1 3.7 0v.08a1.5 1.5 0 0 0 .91 1.37 1.5 1.5 0 0 0 1.66-.3l.05-.05a1.85 1.85 0 1 1 2.62 2.62l-.05.05a1.5 1.5 0 0 0-.3 1.66v.07a1.5 1.5 0 0 0 1.37.91h.15a1.85 1.85 0 1 1 0 3.7h-.08a1.5 1.5 0 0 0-1.37.91Z"/>',
  staroff_gold: '<path d="M12 3.6l2.6 5.27 5.82.8-4.21 4.1.99 5.79L12 16.82 6.8 19.56l.99-5.79-4.21-4.1 5.82-.8Z"/>',
  swatch: '<path d="M12 3.5s5.6 6.1 5.6 9.6a5.6 5.6 0 0 1-11.2 0C6.4 9.6 12 3.5 12 3.5Z"/><path d="M9.4 14.4a2.6 2.6 0 0 0 2.6 2.6"/>',
  tabstate: '<path d="M12 3.5 3.5 8 12 12.5 20.5 8Z"/><path d="M3.5 12 12 16.5 20.5 12"/><path d="M3.5 16 12 20.5 20.5 16"/>',
  terminal: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M7.5 10 10 12.5 7.5 15"/><path d="M12.5 15.5h4"/>',
  trash: '<path d="M3.5 6.5h17"/><path d="M9.5 6.5V5a1.5 1.5 0 0 1 1.5-1.5h2A1.5 1.5 0 0 1 14.5 5v1.5"/><path d="M6 6.5 6.9 19.1A2 2 0 0 0 8.89 21h6.22a2 2 0 0 0 1.99-1.9L18 6.5"/><path d="M10 10.5v6"/><path d="M14 10.5v6"/>',
  undo: '<path d="M4 15.5V9.5a4 4 0 0 1 4-4h8.5"/><path d="M13 2.5l3.5 3-3.5 3"/>',
  warning: '<path d="M10.3 4.3 2.6 18a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0Z"/><path d="M12 9.5v4.5"/><path d="M12 17.5h.01"/>',
  wrap: '<path d="M4 6h16"/><path d="M4 11h11a3 3 0 0 1 0 6h-2.5"/><path d="M15 14.5 12.5 17 15 19.5"/><path d="M4 20.5h7"/>',
  zoomin: '<circle cx="11" cy="11" r="6.75"/><path d="M15.8 15.8 20.5 20.5"/><path d="M11 8.5v5"/><path d="M8.5 11h5"/>',
  zoomout: '<circle cx="11" cy="11" r="6.75"/><path d="M15.8 15.8 20.5 20.5"/><path d="M8.5 11h5"/>',
};

const ICON_FILL_BODIES = {
  run: '<path d="M7.6 4.9v14.2a.85.85 0 0 0 1.3.72l11.2-7.1a.85.85 0 0 0 0-1.44L8.9 4.18a.85.85 0 0 0-1.3.72Z"/>',
  star: '<path d="M12 3.6l2.6 5.27 5.82.8-4.21 4.1.99 5.79L12 16.82 6.8 19.56l.99-5.79-4.21-4.1 5.82-.8Z"/>',
  star_gold: '<path d="M12 3.6l2.6 5.27 5.82.8-4.21 4.1.99 5.79L12 16.82 6.8 19.56l.99-5.79-4.21-4.1 5.82-.8Z"/>',
};

const ICON_TONE_CLASSES = {
  error: "icon-tone-error",
  star_gold: "icon-tone-gold",
  staroff_gold: "icon-tone-gold",
  warning: "icon-tone-warning",
};

function GetIconBody(name) {
  if (Object.prototype.hasOwnProperty.call(ICON_FILL_BODIES, name)) {
    return ICON_FILL_BODIES[name];
  }

  return ICON_STROKE_BODIES[name] || "";
}

function IsFilledIcon(name) {
  return Object.prototype.hasOwnProperty.call(ICON_FILL_BODIES, name);
}

function GetIconClassList(name, extra_class) {
  const class_list = ["icon-glyph"];

  if (ICON_TONE_CLASSES[name]) {
    class_list.push(ICON_TONE_CLASSES[name]);
  }

  if (extra_class) {
    class_list.push(extra_class);
  }

  return class_list.join(" ");
}

function IconTag(name, extra_class) {
  const paint = IsFilledIcon(name) ? 'fill="currentColor" stroke="none"' : 'fill="none" stroke="currentColor"';

  return `<svg class="${GetIconClassList(name, extra_class)}" viewBox="${ICON_VIEW_BOX}" ${paint} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${GetIconBody(name)}</svg>`;
}

function BuildCheckGlyph(is_checked) {
  const on_class = is_checked ? " hexion-check-box-on" : "";
  return `<span class="hexion-check-box${on_class}"></span>`;
}

function CreateFolderIconSvg() {
  return IconTag("folder");
}

function CreateFolderOpenIconSvg() {
  return IconTag("folderopen");
}

function CreateStarIconSvg() {
  return IconTag("star_gold");
}

function GetFileIconAsset(file_name) {
  const name = (file_name || "").replace(/\\/g, "/").split("/").pop().toLowerCase();

  if (name.endsWith(".lua") || name.endsWith(".luau")) {
    return "codefile";
  }

  if (name.endsWith(".json")) {
    return "braces";
  }

  return "file";
}

function CreateFileIconSvg(file_name) {
  return IconTag(GetFileIconAsset(file_name));
}

function HydrateIconSlots(root) {
  const scope = root || document;
  scope.querySelectorAll("[data-icon]").forEach((slot) => {
    slot.innerHTML = IconTag(slot.dataset.icon);
  });
}
