const CONSOLE_COLLAPSE_THRESHOLD = 40;
const CONSOLE_HISTORY_LIMIT = 2000;
const CONSOLE_BOTTOM_SLACK = 12;
const CONSOLE_PENDING = [];
const CONSOLE_HISTORY = [];

const CONSOLE_IGNORED_PATTERNS = [
  /Couldn't find callback id/i,
];

const CONSOLE_TYPE_ICONS = {
  print: null,
  warn: "warning",
  error: "error",
};

const CONSOLE_LINE_COPY = new WeakMap();

const NATIVE_CONSOLE = {
  log: console.log.bind(console),
  info: console.info.bind(console),
  warn: console.warn.bind(console),
  error: console.error.bind(console),
};

let CONSOLE_ELS = null;

let CONSOLE_REDIRECTION_APPLIED = null;

function CacheConsoleEls() {
  CONSOLE_ELS = {
    panel: document.getElementById("console-panel"),
    resizer: document.getElementById("console-resizer"),
    reveal_strip: document.getElementById("console-reveal-strip"),
    output: document.getElementById("console-output"),
    clear_btn: document.getElementById("console-clear-btn"),
    editor_area: document.querySelector(".editor-area"),
  };

  return CONSOLE_ELS;
}

function GetConsoleEls() {
  return CONSOLE_ELS || CacheConsoleEls();
}

function PadConsoleNumber(value) {
  return String(value).padStart(2, "0");
}

function ToConsoleDate(value) {
  if (value instanceof Date) {
    if (!Number.isNaN(value.getTime())) {
      return value;
    }
  } else if (typeof value === "number" && Number.isFinite(value)) {
    const from_number = new Date(value);

    if (!Number.isNaN(from_number.getTime())) {
      return from_number;
    }
  } else if (typeof value === "string" && value !== "") {
    const from_text = new Date(value);

    if (!Number.isNaN(from_text.getTime())) {
      return from_text;
    }
  }

  return new Date();
}

function FormatConsoleTime(value) {
  const date = ToConsoleDate(value);
  return `${PadConsoleNumber(date.getHours())}:${PadConsoleNumber(date.getMinutes())}:${PadConsoleNumber(date.getSeconds())}`;
}

function NormalizeConsoleType(type_name) {
  const lowered = String(type_name || "print").toLowerCase();

  if (lowered === "warn" || lowered === "warning") {
    return "warn";
  }

  if (lowered === "error" || lowered === "err") {
    return "error";
  }

  return "print";
}

function StringifyConsoleArg(value) {
  if (typeof value === "string") {
    return value;
  }

  if (value instanceof Error) {
    return value.stack || value.message;
  }

  if (value === undefined) {
    return "undefined";
  }

  if (value === null) {
    return "null";
  }

  if (typeof value === "object") {
    try {
      return JSON.stringify(value);
    } catch (err) {
      return String(value);
    }
  }

  return String(value);
}

function ShouldIgnoreConsoleText(text) {
  return CONSOLE_IGNORED_PATTERNS.some((pattern) => pattern.test(text));
}

function ShouldIgnoreConsoleArgs(args) {
  return ShouldIgnoreConsoleText(args.map(StringifyConsoleArg).join(" "));
}

async function CopyTextToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    const helper = document.createElement("textarea");
    helper.value = text;
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    helper.style.pointerEvents = "none";
    document.body.appendChild(helper);
    helper.select();

    let did_copy = false;

    try {
      did_copy = document.execCommand("copy");
    } catch (copy_err) {
      did_copy = false;
    }

    helper.remove();
    return did_copy;
  }
}

function BuildConsoleSpan(class_name, text) {
  const span = document.createElement("span");
  span.className = class_name;
  span.textContent = text;
  return span;
}

function BuildConsoleLineIcon(type_name) {
  const icon_slot = document.createElement("span");
  icon_slot.className = "console-line-icon";

  const icon_name = CONSOLE_TYPE_ICONS[type_name];

  if (icon_name) {
    icon_slot.innerHTML = IconTag(icon_name);
  }

  return icon_slot;
}

function BuildConsoleLine(type_name, message, date) {
  const line = document.createElement("div");
  line.className = `console-line console-line-${type_name}`;

  const show_time = UI_STATE.console_timestamps !== false;
  const prefix = document.createElement("span");
  prefix.className = "console-line-prefix";
  prefix.appendChild(BuildConsoleLineIcon(type_name));

  if (show_time) {
    prefix.appendChild(BuildConsoleSpan("console-line-bracket", "["));
    prefix.appendChild(BuildConsoleSpan("console-line-time", FormatConsoleTime(date)));
    prefix.appendChild(BuildConsoleSpan("console-line-bracket", "]"));
  }

  const text = document.createElement("span");
  text.className = "console-line-text";
  text.appendChild(prefix);
  text.appendChild(document.createTextNode(" "));
  text.appendChild(BuildConsoleSpan("console-line-message", message));

  line.appendChild(text);

  const copy_btn = document.createElement("button");
  copy_btn.className = "console-line-copy";
  copy_btn.innerHTML = IconTag("copy");
  copy_btn.setAttribute("aria-label", "Copy message");

  const copy_text = show_time
    ? `[${FormatConsoleTime(date)}] ${message}`
    : message;
  CONSOLE_LINE_COPY.set(line, copy_text);

  copy_btn.addEventListener("click", async (event) => {
    event.stopPropagation();
    const did_copy = await CopyTextToClipboard(copy_text);

    if (!did_copy) {
      return;
    }

    copy_btn.classList.add("console-line-copy-done");
    copy_btn.innerHTML = IconTag("check");

    setTimeout(() => {
      copy_btn.classList.remove("console-line-copy-done");
      copy_btn.innerHTML = IconTag("copy");
    }, 900);
  });

  line.appendChild(copy_btn);

  return line;
}

function IsDebugOutputOn() {
  return UI_STATE.show_debug_output !== false;
}

const CONSOLE_LEVEL_RANK = { print: 0, warn: 1, error: 2 };
const CONSOLE_MIN_RANK = { all: 0, info: 0, warn: 1, error: 2 };

function GetConsoleMinRank() {
  const level = UI_STATE.console_min_level;
  return Object.prototype.hasOwnProperty.call(CONSOLE_MIN_RANK, level) ? CONSOLE_MIN_RANK[level] : 0;
}

function ShouldShowConsoleEntry(entry) {
  const rank = Object.prototype.hasOwnProperty.call(CONSOLE_LEVEL_RANK, entry.type_name)
    ? CONSOLE_LEVEL_RANK[entry.type_name]
    : 0;

  return rank >= GetConsoleMinRank();
}

function RecordConsoleEntry(entry) {
  CONSOLE_HISTORY.push(entry);

  while (CONSOLE_HISTORY.length > CONSOLE_HISTORY_LIMIT) {
    CONSOLE_HISTORY.shift();
  }
}

function SyncConsoleEmptyState() {
  const { panel, output } = GetConsoleEls();

  if (!panel || !output) {
    return;
  }

  panel.classList.toggle("console-panel-empty", output.childElementCount === 0);
}

function IsConsoleAtBottom() {
  const { output } = GetConsoleEls();

  if (!output) {
    return false;
  }

  return output.scrollTop + output.clientHeight >= output.scrollHeight - CONSOLE_BOTTOM_SLACK;
}

function ScrollConsoleToBottom() {
  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  output.scrollTop = output.scrollHeight;
}

function GetConsoleLineLimit() {
  return GetUiStateRangedNumber("console_max_lines");
}

function TrimConsoleOutput() {
  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  const line_limit = GetConsoleLineLimit();

  while (output.childElementCount > line_limit) {
    output.removeChild(output.firstElementChild);
  }
}

function RenderConsoleEntry(entry) {
  const { output } = GetConsoleEls();

  if (!output) {
    return false;
  }

  if (!ShouldShowConsoleEntry(entry)) {
    return true;
  }

  const stick_to_bottom = IsConsoleAtBottom();

  output.appendChild(BuildConsoleLine(entry.type_name, entry.message, entry.date));

  TrimConsoleOutput();

  if (stick_to_bottom && UI_STATE.console_autoscroll !== false) {
    ScrollConsoleToBottom();
  }

  SyncConsoleEmptyState();

  return true;
}

function AppendConsoleEntry(type_name, message, date) {
  if (ShouldIgnoreConsoleText(message)) {
    return;
  }

  const entry = { type_name, message, date: ToConsoleDate(date) };
  RecordConsoleEntry(entry);

  if (!IsDebugOutputOn()) {
    return;
  }

  if (!RenderConsoleEntry(entry)) {
    CONSOLE_PENDING.push(entry);
  }
}

function AppendConsoleBatch(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return;
  }

  const entries = [];

  for (const item of items) {
    if (!item) {
      continue;
    }

    const message = item.message == null ? "" : String(item.message);

    if (ShouldIgnoreConsoleText(message)) {
      continue;
    }

    entries.push({
      type_name: NormalizeConsoleType(item.type || item.level),
      message,
      date: new Date(),
    });
  }

  if (entries.length === 0) {
    return;
  }

  for (const entry of entries) {
    RecordConsoleEntry(entry);
  }

  if (!IsDebugOutputOn()) {
    return;
  }

  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  const stick_to_bottom = IsConsoleAtBottom();
  const fragment = document.createDocumentFragment();

  for (const entry of entries) {
    if (!ShouldShowConsoleEntry(entry)) {
      continue;
    }

    fragment.appendChild(BuildConsoleLine(entry.type_name, entry.message, entry.date));
  }

  output.appendChild(fragment);
  TrimConsoleOutput();

  if (stick_to_bottom && UI_STATE.console_autoscroll !== false) {
    ScrollConsoleToBottom();
  }

  SyncConsoleEmptyState();
}

function ReloadConsoleHistory() {
  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  output.innerHTML = "";
  SyncConsoleEmptyState();

  if (!IsDebugOutputOn()) {
    return;
  }

  for (const entry of CONSOLE_HISTORY) {
    RenderConsoleEntry(entry);
  }

  output.scrollTop = output.scrollHeight;
}

function FlushPendingConsoleEntries() {
  while (CONSOLE_PENDING.length > 0) {
    RenderConsoleEntry(CONSOLE_PENDING.shift());
  }
}

function ConsoleWrite(type_name, args) {
  const message = args.map(StringifyConsoleArg).join(" ");
  AppendConsoleEntry(NormalizeConsoleType(type_name), message, new Date());
}

function LogPrint(...args) {
  ConsoleWrite("print", args);
}

function LogWarn(...args) {
  ConsoleWrite("warn", args);
}

function LogError(...args) {
  ConsoleWrite("error", args);
}

async function HandleConsoleRedirectionChanged(enabled) {
  const is_on = Boolean(enabled);
  const first_time = CONSOLE_REDIRECTION_APPLIED === null;

  if (window.__TAURI__ && window.__TAURI__.core) {
    try {
      await window.__TAURI__.core.invoke("set_console_redirection", { enabled: is_on });
    } catch (err) {
      LogWarn("console redirection not available:", err);
      return;
    }
  }

  if (!first_time && is_on === CONSOLE_REDIRECTION_APPLIED) {
    return;
  }

  CONSOLE_REDIRECTION_APPLIED = is_on;

  if (!first_time) {
    LogPrint(`console redirection ${is_on ? "on" : "off"}`);
  }
}

function ClearConsole() {
  const { output } = GetConsoleEls();

  CONSOLE_HISTORY.length = 0;
  CONSOLE_PENDING.length = 0;

  if (output) {
    output.innerHTML = "";
    SyncConsoleEmptyState();
  }
}

function GetConsoleLineEl(target) {
  if (!target || !target.closest) {
    return null;
  }

  return target.closest(".console-line");
}

function GetConsoleLineText(line_el) {
  return line_el ? CONSOLE_LINE_COPY.get(line_el) || "" : "";
}

function GetConsoleAllText() {
  const { output } = GetConsoleEls();

  if (!output) {
    return "";
  }

  return Array.from(output.querySelectorAll(".console-line"))
    .map((line) => GetConsoleLineText(line))
    .filter((text) => text.length > 0)
    .join("\n");
}

async function CopyConsoleLine(line_el) {
  const text = GetConsoleLineText(line_el);

  if (text.length === 0) {
    return;
  }

  await CopyTextToClipboard(text);
}

async function CopyEntireConsole() {
  const text = GetConsoleAllText();

  if (text.length === 0) {
    return;
  }

  await CopyTextToClipboard(text);
}

function ShowConsoleContextMenu(event) {
  const line_el = GetConsoleLineEl(event.target);
  const line_text = GetConsoleLineText(line_el);
  const current_size = GetUiStateRangedNumber("console_font_size_px");

  ShowContextMenu(event.clientX, event.clientY, [
    { label: "Copy line", icon_name: "copy", disabled: line_text.length === 0, on_click: () => CopyConsoleLine(line_el) },
    { label: "Copy all", icon_name: "duplicate", on_click: () => CopyEntireConsole() },
    { separator: true },
    { label: "Clear console", icon_name: "trash", danger: true, on_click: () => ClearConsole() },
    { separator: true },
    { label: "Zoom In", icon_name: "zoomin", shortcut: "Ctrl+=", on_click: () => SetConsoleFontSize(current_size + 1) },
    { label: "Zoom Out", icon_name: "zoomout", shortcut: "Ctrl+-", on_click: () => SetConsoleFontSize(current_size - 1) },
    { label: "Reset Zoom", icon_name: "resetzoom", shortcut: "Ctrl+0", on_click: () => SetConsoleFontSize(GetUiStateDefault("console_font_size_px")) },
  ]);
}

function SetupConsoleContextMenu() {
  const { panel, output } = GetConsoleEls();

  if (!panel || !output) {
    return;
  }

  panel.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();
    ShowConsoleContextMenu(event);
  });
}

let CONSOLE_SETTLE_ARMED = null;

function ArmConsoleScrollSettle(panel) {
  if (CONSOLE_SETTLE_ARMED === panel) {
    return;
  }

  DisarmConsoleScrollSettle();
  CONSOLE_SETTLE_ARMED = panel;
  panel.addEventListener("transitionend", ScrollConsoleToBottom, { once: true });
}

function DisarmConsoleScrollSettle() {
  if (!CONSOLE_SETTLE_ARMED) {
    return;
  }

  CONSOLE_SETTLE_ARMED.removeEventListener("transitionend", ScrollConsoleToBottom);
  CONSOLE_SETTLE_ARMED = null;
}

function SetConsoleHidden(hidden) {
  const { panel, reveal_strip } = GetConsoleEls();

  if (!panel || !reveal_strip) {
    return;
  }

  const was_at_bottom = hidden && IsConsoleAtBottom();

  UI_STATE.console_hidden = hidden;
  panel.classList.toggle("console-panel-hidden", hidden);
  reveal_strip.classList.toggle("console-reveal-strip-visible", hidden);

  if (!hidden) {
    panel.style.height = `${UI_STATE.console_height}px`;

    if (was_at_bottom && UI_STATE.console_autoscroll !== false) {
      ArmConsoleScrollSettle(panel);
      requestAnimationFrame(ScrollConsoleToBottom);
    }
  }

  requestAnimationFrame(RefreshEditorMetrics);

  SaveUiState();
}

function ApplyConsoleFontSize(size_px) {
  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  const line_height = GetUiStateRangedNumber("console_line_height");
  output.style.setProperty("--con-font-size", `${size_px}px`);
  output.style.setProperty("--con-line-height", `${Math.round(size_px * line_height)}px`);
}

function ApplyConsoleWrap() {
  const { output } = GetConsoleEls();

  if (!output) {
    return;
  }

  output.style.whiteSpace = UI_STATE.console_wrap ? "pre-wrap" : "pre";
  output.style.wordBreak = UI_STATE.console_wrap ? "break-word" : "normal";
}

function SetConsoleFontSize(size_px) {
  const clamped = ClampUiStateNumber("console_font_size_px", Math.round(size_px));
  UI_STATE.console_font_size_px = clamped;
  ApplyConsoleFontSize(clamped);
  SaveUiState();
}

function SetConsoleHeight(height_px) {
  const { panel } = GetConsoleEls();

  if (!panel) {
    return;
  }

  if (UI_STATE.console_hidden) {
    SetConsoleHidden(false);
  }

  panel.style.height = `${height_px}px`;

  requestAnimationFrame(() => {
    RefreshEditorMetrics();
    ScrollConsoleToBottom();
  });
}

function IsPointerOverConsolePanel() {
  const { panel } = GetConsoleEls();
  return Boolean(panel && panel.matches(":hover"));
}

function ShouldConsoleOwnZoomShortcut() {
  return IsPointerOverConsolePanel();
}

function SetupConsoleZoom() {
  const { panel } = GetConsoleEls();

  if (!panel) {
    return;
  }

  if (typeof UI_STATE.console_font_size_px !== "number") {
    UI_STATE.console_font_size_px = GetUiStateDefault("console_font_size_px");
  }

  ApplyConsoleFontSize(UI_STATE.console_font_size_px);
  ApplyConsoleWrap();
  TrimConsoleOutput();

  window.addEventListener(
    "wheel",
    (event) => {
      if (!event.ctrlKey) {
        return;
      }

      if (!IsPointerOverConsolePanel()) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      const step = event.deltaY < 0 ? 1 : -1;
      SetConsoleFontSize(UI_STATE.console_font_size_px + step);
    },
    { passive: false, capture: true }
  );

  window.addEventListener(
    "keydown",
    (event) => {
      if (!event.ctrlKey || event.altKey) {
        return;
      }

      if (!ShouldConsoleOwnZoomShortcut()) {
        return;
      }

      const key = event.key;
      const current_size = GetUiStateRangedNumber("console_font_size_px");

      if (key === "=" || key === "+") {
        event.preventDefault();
        SetConsoleFontSize(current_size + 1);
        return;
      }

      if (key === "-" || key === "_") {
        event.preventDefault();
        SetConsoleFontSize(current_size - 1);
        return;
      }

      if (key === "0") {
        event.preventDefault();
        SetConsoleFontSize(GetUiStateDefault("console_font_size_px"));
      }
    },
    true
  );
}

function MirrorBrowserConsole() {
  console.log = (...args) => {
    if (ShouldIgnoreConsoleArgs(args)) {
      return;
    }

    NATIVE_CONSOLE.log(...args);
    LogPrint(...args);
  };

  console.info = (...args) => {
    if (ShouldIgnoreConsoleArgs(args)) {
      return;
    }

    NATIVE_CONSOLE.info(...args);
    LogPrint(...args);
  };

  console.warn = (...args) => {
    if (ShouldIgnoreConsoleArgs(args)) {
      return;
    }

    NATIVE_CONSOLE.warn(...args);
    LogWarn(...args);
  };

  console.error = (...args) => {
    if (ShouldIgnoreConsoleArgs(args)) {
      return;
    }

    NATIVE_CONSOLE.error(...args);
    LogError(...args);
  };

  window.addEventListener("error", (event) => {
    const location = event.filename ? ` (${event.filename}:${event.lineno}:${event.colno})` : "";
    LogError(`${event.message}${location}`);
  });

  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason;
    const text = reason && reason.stack ? reason.stack : StringifyConsoleArg(reason);
    LogError(`unhandled promise rejection: ${text}`);
  });
}

async function BindConsoleRustBridge() {
  if (!window.__TAURI__ || !window.__TAURI__.event) {
    return;
  }

  try {
    await window.__TAURI__.event.listen("console-log", (event) => {
      const payload = event.payload || {};
      const type_name = NormalizeConsoleType(payload.type || payload.level);
      const message = payload.message == null ? "" : String(payload.message);
      AppendConsoleEntry(type_name, message, new Date());
    });

    await window.__TAURI__.event.listen("console-batch", (event) => {
      AppendConsoleBatch(event.payload);
    });

    await window.__TAURI__.event.listen("console-clear", () => {
      ClearConsole();
    });
  } catch (err) {
    NATIVE_CONSOLE.warn("could not bind console rust bridge:", err);
  }

  try {
    await window.__TAURI__.core.invoke("console_ready");
  } catch (err) {
    NATIVE_CONSOLE.warn("console_ready not available:", err);
  }
}

function SetupConsole() {
  const { panel, resizer, reveal_strip, clear_btn, editor_area, output } = GetConsoleEls();

  if (!panel || !resizer || !reveal_strip || !editor_area) {
    NATIVE_CONSOLE.error("console elements missing, console not initialised");
    return;
  }

  MirrorBrowserConsole();

  if (UI_STATE.console_hidden) {
    panel.classList.add("console-panel-hidden");
    reveal_strip.classList.add("console-reveal-strip-visible");
  } else {
    panel.style.height = `${UI_STATE.console_height}px`;
  }

  FlushPendingConsoleEntries();
  SetupConsoleZoom();
  SetupConsoleContextMenu();
  SyncConsoleEmptyState();

  SetupPanelResizer(resizer, {
    axis: "vertical",
    collapse_threshold: CONSOLE_COLLAPSE_THRESHOLD,
    on_collapse_start: () => {
      if (UI_STATE.console_hidden) {
        SetConsoleHidden(false);
      }
    },
    on_collapse_end: () => SetConsoleHidden(true),
    measure: (event) => {
      const area_rect = editor_area.getBoundingClientRect();
      const toolbar_el = document.getElementById("console-toolbar");
      const toolbar_height = toolbar_el ? toolbar_el.getBoundingClientRect().height : 0;
      return area_rect.bottom - event.clientY - toolbar_height;
    },
    apply: (raw_height) => {
      panel.style.height = raw_height > 0 ? `${ClampUiStateNumber("console_height", raw_height)}px` : "0px";
      requestAnimationFrame(RefreshEditorMetrics);
    },
    commit: () => {
      UI_STATE.console_height = Math.round(panel.getBoundingClientRect().height);
      requestAnimationFrame(RefreshEditorMetrics);
      SaveUiState();
    },
  });

  reveal_strip.addEventListener("click", () => {
    SetConsoleHidden(false);
  });

  if (clear_btn) {
    clear_btn.addEventListener("click", ClearConsole);
  }

  if (output) {
    output.addEventListener("click", (event) => {
      if (UI_STATE.console_click_to_copy === false) {
        return;
      }

      const line_el = GetConsoleLineEl(event.target);

      if (line_el) {
        CopyConsoleLine(line_el);
      }
    });
  }

  BindConsoleRustBridge();
}
