const VIEW_TABS_STATE = {
  views: ["editor", "scripthub", "settings"],
  active_view: "editor",
};

function GetViewTabEls() {
  const tabs = document.querySelectorAll(".nav-tab");
  const panels = document.querySelectorAll(".view-panel");
  const tab_bar = document.getElementById("tab-bar");
  const editor_breadcrumbs = document.getElementById("editor-breadcrumbs");
  const editor_mount = document.getElementById("editor-mount");
  const explorer = document.querySelector(".explorer");
  const explorer_strip = document.getElementById("explorer-reveal-strip");
  const console_panel = document.getElementById("console-panel");
  const console_strip = document.getElementById("console-reveal-strip");
  return { tabs, panels, tab_bar, editor_breadcrumbs, editor_mount, explorer, explorer_strip, console_panel, console_strip };
}

function SwitchView(view_name) {
  const { tabs, panels, tab_bar, editor_breadcrumbs, editor_mount, explorer, explorer_strip, console_panel, console_strip } = GetViewTabEls();

  const leaving_editor = VIEW_TABS_STATE.active_view === "editor";
  const entering_editor = view_name === "editor";

  // Hide explorer and console when leaving editor
  if (leaving_editor) {
    if (explorer) explorer.classList.add("hidden");
    if (explorer_strip) explorer_strip.classList.remove("hidden");
    if (typeof SetConsoleHidden === "function") {
      SetConsoleHidden(true);
    }
  }

  VIEW_TABS_STATE.active_view = view_name;

  tabs.forEach((tab) => {
    const is_active = tab.dataset.view === view_name;
    tab.setAttribute("aria-selected", is_active);
  });

  panels.forEach((panel) => {
    const is_active = panel.id === `view-${view_name}`;
    panel.hidden = !is_active;
    if (is_active) {
      panel.removeAttribute("hidden");
    }
  });

  const show_editor_chrome = view_name === "editor";
  if (tab_bar) tab_bar.style.display = show_editor_chrome ? "flex" : "none";
  if (editor_breadcrumbs) editor_breadcrumbs.style.display = show_editor_chrome ? "block" : "none";

  if (entering_editor && editor_mount) {
    EnsureEditorMounted();
  }

  if (view_name === "scripthub") {
    RefreshScripthubGrid();
  }

  if (view_name === "settings" && typeof OpenSettingsPanel === "function") {
    OpenSettingsPanel();
  }

  SaveViewPreference(view_name);
}

function EnsureEditorMounted() {
  const { editor_mount } = GetViewTabEls();
  if (!editor_mount) return;

  const has_editor = editor_mount.querySelector(".editor-surface");
  if (!has_editor && typeof SetupEditorSurface === "function") {
    fetch("editor/html/editor.html")
      .then((response) => response.text())
      .then((html) => {
        editor_mount.innerHTML = html;
        SetupEditorSurface();
      })
      .catch((err) => console.error("Failed to load editor:", err));
  }
}

async function SaveViewPreference(view_name) {
  try {
    if (window.__TAURI__ && window.__TAURI__.core) {
      await window.__TAURI__.core.invoke("write_text_file", {
        path: (await GetConfigPath()) + "/last_view.json",
        content: JSON.stringify({ view: view_name }, null, 2),
      });
    }
  } catch (err) {
    console.warn("could not save view preference:", err);
  }
}

async function LoadViewPreference() {
  try {
    if (window.__TAURI__ && window.__TAURI__.core) {
      const path = (await GetConfigPath()) + "/last_view.json";
      const exists = await window.__TAURI__.core.invoke("path_exists", { path });
      if (exists) {
        const content = await window.__TAURI__.core.invoke("read_dropped_file", { path });
        const parsed = JSON.parse(content);
        if (parsed.view && VIEW_TABS_STATE.views.includes(parsed.view)) {
          SwitchView(parsed.view);
        }
      }
    }
  } catch (err) {
    console.warn("could not load view preference:", err);
  }
}

async function GetConfigPath() {
  if (window.__TAURI__ && window.__TAURI__.core) {
    const base = await window.__TAURI__.core.invoke("get_config_dir");
    return base;
  }
  return ".";
}

function SetupViewTabs() {
  const { tabs, panels, explorer, explorer_strip } = GetViewTabEls();

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      SwitchView(tab.dataset.view);
    });
  });

  // Explorer reveal strip click
  if (explorer_strip) {
    explorer_strip.addEventListener("click", () => {
      if (explorer) {
        explorer.classList.remove("hidden");
        explorer_strip.classList.add("hidden");
      }
    });
  }

  // Keyboard shortcut: Ctrl+1/2/3 for views
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey) {
      if (e.key === "1") {
        e.preventDefault();
        SwitchView("editor");
      } else if (e.key === "2") {
        e.preventDefault();
        SwitchView("scripthub");
      } else if (e.key === "3") {
        e.preventDefault();
        SwitchView("settings");
      }
    }
  });
}

function InitViewTabs() {
  SetupViewTabs();
  LoadViewPreference();
  BuildHomeGrid();
}

function GetActiveView() {
  return VIEW_TABS_STATE.active_view;
}


// ===== SCRIPT HUB STATE =====

const SCRIPT_HUB_STATE = {
  scripts: [],
  trending: [],
  filters: new Set(["all"]),
  sort: "updated",
  search: "",
  loading: false,
  debounceTimer: null,
};

function GetScripthubFilters() {
  const filter_btns = document.querySelectorAll(".hub-filter.active");
  return Array.from(filter_btns).map((btn) => btn.dataset.filter);
}

function GetScripthubSort() {
  const select = document.getElementById("hub-sort");
  return select ? select.value : "updated";
}

function GetScripthubSearch() {
  const input = document.getElementById("hub-search");
  return input ? input.value.toLowerCase() : "";
}

// Keeps the "N scripts" badge in the hub toolbar in sync
function UpdateScriptCount() {
  const badge = document.getElementById("hub-script-count");
  if (!badge) return;
  const count = SCRIPT_HUB_STATE.scripts.length;
  badge.textContent = `${count} script${count === 1 ? "" : "s"}`;
}

async function RefreshScripthubGrid(search_override) {
  const loading = document.getElementById("hub-loading");
  if (loading) loading.hidden = false;
  const previous = document.querySelector(".hub-error-state");
  if (previous) previous.remove();

  try {
    await RefreshScripthubFromAPI(search_override);
    RenderAllSections();
    UpdateScriptCount();
  } finally {
    if (loading) loading.hidden = true;
  }
}

function BuildScripthubCard(script) {
  const thumb = GetScriptThumbnail(script);
  const risk = GetScriptRisk(script);
  const game = script.game || script.gameName || null;

  return `
    <article class="hub-card" data-script-id="${EscapeHtml(script.id || script.slug)}" tabindex="0" role="button" aria-label="${EscapeHtml(script.title || script.name)}">
      <div class="hub-card-thumb">
        ${thumb ? `<img src="${EscapeHtml(thumb)}" alt="" loading="lazy"/>` : `
          <div class="hub-card-thumb-fallback">
            <span class="fallback-icon" data-icon="script"></span>
          </div>
        `}
        <div class="hub-card-badges">
          ${game ? `<span class="hub-badge-chip chip-game" data-icon="joystick">${EscapeHtml(game.title || game)}</span>` : ""}
          ${risk ? `<span class="hub-badge-chip chip-risk risk-${risk}">${risk.charAt(0).toUpperCase() + risk.slice(1)}</span>` : ""}
        </div>
        <div class="hub-card-actions">
          <button class="hub-card-action-btn" data-action="open-editor" title="Open in Editor">
            <span data-icon="external-link"></span>
            <span class="hub-card-action-text">Open in Editor</span>
          </button>
        </div>
      </div>
      <div class="hub-card-body">
        <div class="hub-card-title-row">
          <h4 class="hub-card-title">${EscapeHtml(script.title || script.name || "Unnamed Script")}</h4>
        </div>
        <p class="hub-card-desc">${EscapeHtml(script.description || "No description")}</p>
        <div class="hub-card-meta">
          ${script.creator ? `
            <span class="hub-card-creator">
              ${script.creator.avatarUrl ? `<img src="${EscapeHtml(script.creator.avatarUrl)}" alt=""/>` : `<span class="meta-icon" data-icon="user"></span>`}
              <span>${EscapeHtml(script.creator.username || "Unknown")}</span>
            </span>
          ` : ""}
          ${script.views ? `<span class="meta-icon" data-icon="eye"></span><span>${FormatNumber(script.views)}</span>` : ""}
          ${script.likes ? `<span class="meta-icon" data-icon="heart"></span><span>${FormatNumber(script.likes)}</span>` : ""}
          ${script.updated_at ? `<span>${FormatDate(script.updated_at)}</span>` : ""}
        </div>
      </div>
    </article>
  `;
}

function GetScriptThumbnail(script) {
  // Priority: game thumbnail > script imageUrl > game logo > null
  if (script.game?.thumbnailUrl) return script.game.thumbnailUrl;
  if (script.imageUrl) return script.imageUrl;
  if (script.game?.logoUrl) return script.game.logoUrl;
  if (script.game?.imageUrl) return script.game.imageUrl;
  return null;
}

function GetScriptRisk(script) {
  if (script.risk) {
    if (script.risk.level) {
      const level = script.risk.level.toLowerCase();
      if (level.includes("safe") || level.includes("low")) return "low";
      if (level.includes("medium") || level.includes("suspic")) return "medium";
      if (level.includes("high") || level.includes("malicious")) return "high";
    }
    if (typeof script.risk.score === "number") {
      if (script.risk.score <= 3) return "low";
      if (script.risk.score <= 6) return "medium";
      return "high";
    }
  }
  return null;
}

function FormatNumber(num) {
  if (!num) return "0";
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return String(num);
}

function FormatDate(dateStr) {
  try {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays}d ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)}mo ago`;
    return `${Math.floor(diffDays / 365)}y ago`;
  } catch {
    return "";
  }
}

function GetScripthubScripts() {
  try {
    const stored = localStorage.getItem("hexion_scripthub_scripts");
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (err) {
    console.warn("could not load scripthub scripts:", err);
  }
  return GetDefaultScripthubScripts();
}

function GetDefaultScripthubScripts() {
  return [
    {
      id: "example-1",
      title: "Loading scripts from rscripts.net...",
      description: "Fetching trending scripts...",
      type: "script",
      author: "Hexion",
      updated_at: new Date().toISOString(),
      views: 0,
      likes: 0,
      content: "",
      tags: [],
    },
  ];
}

// Reads the API key from Settings (Script Hub category), falling back to the bundled key.
function GetRscriptsApiKey() {
  // 1) Bundled key from Tauri config (set at build time, or by the dev shim)
  const bundled = (window.__TAURI__ && window.__TAURI__.config && window.__TAURI__.config.RSCRIPTS_API_KEY) || "";
  if (bundled && !/(secret|hidden|placeholder)/i.test(bundled)) return String(bundled).trim();

  // 2) User-provided key from Settings
  const user = (typeof UI_STATE !== "undefined" && UI_STATE && UI_STATE.rscripts_api_key) || "";
  return String(user).trim();
}
const RSCRIPTS_BASE_URL = "https://api.rscripts.net/v1";

// Shows a helpful empty state + toast when the API rejects the request
// (missing/expired key) so the user knows how to fix it.
function ShowScripthubApiError(err) {
  const msg = String(err && err.message ? err.message : err || "");
  const isAuth = /unauthor|invalid api key|api key|401/i.test(msg);
  if (isAuth) {
    Notify("RScripts API key missing or invalid — set it in Settings", "error");
  } else {
    Notify("Failed to load scripts from RScripts", "error");
  }

  const grid = document.getElementById("hub-trending-grid") || document.getElementById("hub-grid");
  if (grid && !SCRIPT_HUB_STATE.scripts.length) {
    const list = grid.closest("ul") || grid.closest(".hub-section-list") || grid;
    const empty = document.createElement("div");
    empty.className = "hub-error-state";
    empty.innerHTML = `
      <span data-icon="cloud-off"></span>
      <p>${isAuth ? "RScripts API key is missing or invalid." : "Could not reach RScripts."}</p>
      ${isAuth ? '<button class="btn primary" data-action="open-api-key-settings">Open Settings</button>' : '<button class="btn primary" data-action="retry-scripthub">Retry</button>'}
    `;
    if (!list.querySelector(".hub-error-state")) list.appendChild(empty);
  }
}

// Perform a GET request through the Tauri backend when available (avoids
// webview CORS restrictions), falling back to a direct fetch in a browser.
async function HttpGetJson(url) {
  // Prefer the Tauri backend proxy (no CORS). When the Tauri runtime is not
  // actually available (plain browser preview), the invoke rejects before the
  // request is ever made — fall back to a direct fetch instead of dying.
  if (window.__TAURI__ && window.__TAURI__.core) {
    try {
      const res = await window.__TAURI__.core.invoke("http_get_json", {
        url,
        apiKey: GetRscriptsApiKey(),
      });
      const data = JSON.parse(res.body);
      if (!res.ok || data.success === false) {
        throw new Error(data.error?.message || `HTTP ${res.status}`);
      }
      return data;
    } catch (err) {
      const msg = String(err && err.message ? err.message : err);
      if (!/Tauri runtime unavailable/i.test(msg)) throw err;
    }
  }
  const key = GetRscriptsApiKey();
  const headers = { "Content-Type": "application/json" };
  if (key) headers["Authorization"] = `Bearer ${key}`;
  const response = await fetch(url, { headers });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  if (!data.success) throw new Error(data.error?.message || "API error");
  return data;
}

async function FetchRscriptsTrending() {
  const data = await HttpGetJson(`${RSCRIPTS_BASE_URL}/trending`);
  return data.data || { trending: [], rising: [] };
}

async function FetchRscriptsSearch(query, page = 1, limit = 20) {
  const params = new URLSearchParams({
    q: query,
    index: "scripts",
    limit: String(limit),
  });
  const data = await HttpGetJson(`${RSCRIPTS_BASE_URL}/search?${params}`);
  return data.data?.scripts || data.scripts || [];
}

async function FetchRscriptsDetail(slug) {
  try {
    const data = await HttpGetJson(`${RSCRIPTS_BASE_URL}/scripts/${slug}`);
    return data.data;
  } catch (err) {
    console.warn("Failed to fetch script detail:", err);
    return null;
  }
}

async function RefreshScripthubFromAPI(search_override) {
  SCRIPT_HUB_STATE.loading = true;

  try {
    if (search_override !== undefined) {
      SCRIPT_HUB_STATE.search = search_override.toLowerCase();
    } else {
      SCRIPT_HUB_STATE.search = GetScripthubSearch();
    }
    SCRIPT_HUB_STATE.sort = GetScripthubSort();
    SCRIPT_HUB_STATE.filters = new Set(GetScripthubFilters());

    if (SCRIPT_HUB_STATE.search.length >= 2) {
      // Search mode
      const results = await FetchRscriptsSearch(SCRIPT_HUB_STATE.search, 1, 50);
      SCRIPT_HUB_STATE.scripts = results.map(MapRscriptsScript);
      SCRIPT_HUB_STATE.trending = [];
    } else {
      // Trending mode
      const data = await FetchRscriptsTrending();
      const trending = (data.trending || []).map(MapRscriptsScript);
      const rising = (data.rising || []).map(MapRscriptsScript);
      SCRIPT_HUB_STATE.trending = [...trending, ...rising].slice(0, 20);
      SCRIPT_HUB_STATE.scripts = [...SCRIPT_HUB_STATE.trending];
    }

    SaveScripthubScripts(SCRIPT_HUB_STATE.scripts);
  } catch (err) {
    console.error("Failed to refresh scripthub:", err);
    ShowScripthubApiError(err);
  } finally {
    SCRIPT_HUB_STATE.loading = false;
  }
}

function MapRscriptsScript(apiScript) {
  return {
    id: apiScript.id,
    slug: apiScript.slug,
    title: apiScript.title,
    description: apiScript.description,
    author: apiScript.creator?.username,
    creator: apiScript.creator,
    updated_at: apiScript.createdAt || apiScript.updatedAt || new Date().toISOString(),
    views: apiScript.views || 0,
    likes: apiScript.likes || 0,
    isKeySystem: apiScript.isKeySystem,
    isMobileReady: apiScript.isMobileReady,
    isPaid: apiScript.isPaid,
    rawScript: apiScript.rawScript,
    script: apiScript.script,
    game: apiScript.game,
    risk: apiScript.risk,
    imageUrl: apiScript.imageUrl,
    tags: [],
  };
}

async function LoadTrendingOnStart() {
  if (SCRIPT_HUB_STATE.loading) return;

  const loading = document.getElementById("hub-loading");
  if (loading) loading.hidden = false;

  try {
    await RefreshScripthubFromAPI();
    RenderAllSections();
    UpdateScriptCount();
  } finally {
    if (loading) loading.hidden = true;
  }
}

function SaveScripthubScripts(scripts) {
  try {
    localStorage.setItem("hexion_scripthub_scripts", JSON.stringify(scripts));
  } catch (err) {
    console.warn("could not save scripthub scripts:", err);
  }
}

function RenderAllSections() {
  RenderTrendingSection();
  RenderAllScriptsSection();
  BindCardEvents();
}

function RenderTrendingSection() {
  const grid = document.getElementById("hub-trending-grid");
  const section = document.getElementById("hub-section-trending");
  if (!grid || !section) return;

  if (SCRIPT_HUB_STATE.trending.length === 0) {
    section.style.display = "none";
    return;
  }

  section.style.display = "";
  grid.innerHTML = SCRIPT_HUB_STATE.trending.slice(0, 8).map(BuildScripthubCard).join("");
}

function RenderAllScriptsSection() {
  const grid = document.getElementById("hub-all-grid");
  const section = document.getElementById("hub-section-all");
  if (!grid || !section) return;

  const search = SCRIPT_HUB_STATE.search;
  const filters = SCRIPT_HUB_STATE.filters;
  const sort = SCRIPT_HUB_STATE.sort;

  let filtered = SCRIPT_HUB_STATE.scripts.filter((script) => {
    if (search) {
      const haystack = `${script.title} ${script.description} ${script.author || ""} ${script.game?.title || ""}`.toLowerCase();
      if (!haystack.includes(search)) return false;
    }
    return true;
  });

  // Sort
  filtered.sort((a, b) => {
    switch (sort) {
      case "popular":
        return (b.views || 0) - (a.views || 0);
      case "likes":
        return (b.likes || 0) - (a.likes || 0);
      case "views":
        return (b.views || 0) - (a.views || 0);
      case "name":
        return (a.title || "").localeCompare(b.title || "");
      case "updated":
      default:
        return new Date(b.updated_at || 0) - new Date(a.updated_at || 0);
    }
  });

  grid.innerHTML = filtered.map(BuildScripthubCard).join("");
}

function BindCardEvents() {
  // Script cards
  document.querySelectorAll(".hub-card").forEach((card) => {
    const scriptId = card.dataset.scriptId;
    const script = SCRIPT_HUB_STATE.scripts.find(s => s.id === scriptId || s.slug === scriptId) ||
                   SCRIPT_HUB_STATE.trending.find(s => s.id === scriptId || s.slug === scriptId);

    const activate = () => {
      if (script) OpenScripthubScript(script);
    };

    card.addEventListener("click", (e) => {
      if (e.target.closest(".hub-card-action-btn")) return;
      activate();
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        activate();
      }
    });
  });

  // "Open in Editor" action buttons on hover
  document.querySelectorAll(".hub-card-action-btn[data-action=\"open-editor\"]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".hub-card");
      if (!card) return;
      const scriptId = card.dataset.scriptId;
      const script = SCRIPT_HUB_STATE.scripts.find(s => s.id === scriptId || s.slug === scriptId) ||
                     SCRIPT_HUB_STATE.trending.find(s => s.id === scriptId || s.slug === scriptId);
      if (script) OpenScripthubScript(script);
    });
  });

  // Script cards - click on card (legacy hub-script-card class)
  document.querySelectorAll(".hub-script-card").forEach((card) => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".hub-script-action")) return;
      const scriptId = card.dataset.scriptId;
      const script = SCRIPT_HUB_STATE.scripts.find(s => s.id === scriptId || s.slug === scriptId) ||
                     SCRIPT_HUB_STATE.trending.find(s => s.id === scriptId || s.slug === scriptId);
      if (script) OpenScripthubScript(script);
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        const scriptId = card.dataset.scriptId;
        const script = SCRIPT_HUB_STATE.scripts.find(s => s.id === scriptId || s.slug === scriptId) ||
                       SCRIPT_HUB_STATE.trending.find(s => s.id === scriptId || s.slug === scriptId);
        if (script) OpenScripthubScript(script);
      }
    });
  });
}


// Search suggestions
function SetupSearchSuggestions() {
  const input = document.getElementById("hub-search");
  const suggestions = document.getElementById("hub-search-suggestions");
  if (!input || !suggestions) return;

  input.addEventListener("input", () => {
    clearTimeout(SCRIPT_HUB_STATE.debounceTimer);
    SCRIPT_HUB_STATE.debounceTimer = setTimeout(() => {
      const query = input.value.trim().toLowerCase();
      if (query.length < 2) {
        suggestions.hidden = true;
        return;
      }

      // Show suggestions from local scripts + popular searches
      const matches = SCRIPT_HUB_STATE.scripts
        .filter(s => (s.title || "").toLowerCase().includes(query))
        .slice(0, 5)
        .map(s => s.title);

      // Add popular search terms
      const popular = ["hub", "esp", "aimbot", "fly", "speed", "infinite yield", "dex", "hydroxide", "script hub"];
      popular.filter(p => p.includes(query)).forEach(p => {
        if (!matches.includes(p)) matches.push(p);
      });

      if (matches.length > 0) {
        suggestions.innerHTML = matches.map(m => `<div class="hub-suggestion" data-query="${EscapeHtml(m)}">${EscapeHtml(m)}</div>`).join("");
        suggestions.hidden = false;
      } else {
        suggestions.hidden = true;
      }
    }, 150);
  });

  input.addEventListener("focus", () => {
    if (input.value.trim().length >= 2) suggestions.hidden = false;
  });

  document.addEventListener("click", (e) => {
    if (!suggestions.contains(e.target) && e.target !== input) {
      suggestions.hidden = true;
    }
  });

  suggestions.addEventListener("click", (e) => {
    const item = e.target.closest(".hub-suggestion");
    if (item) {
      input.value = item.dataset.query;
      suggestions.hidden = true;
      RefreshScripthubGrid(item.dataset.query);
    }
  });
}

// Filter buttons
function SetupFilterButtons() {
  const container = document.getElementById("hub-filters");
  if (!container) return;

  const filters = [
    { id: "all", label: "All", icon: "library" },
    { id: "script", label: "Scripts", icon: "script" },
    { id: "hub", label: "Hubs", icon: "grid" },
    { id: "utility", label: "Utilities", icon: "tool" },
    { id: "game", label: "Game Specific", icon: "joystick" },
  ];

  container.innerHTML = filters.map(f => `
    <button class="hub-filter ${f.id === "all" ? "active" : ""}" data-filter="${f.id}" aria-pressed="${f.id === "all"}">
      <span data-icon="${f.icon}"></span>
      ${f.label}
    </button>
  `).join("");

  container.querySelectorAll(".hub-filter").forEach((btn) => {
    btn.addEventListener("click", () => {
      const filter = btn.dataset.filter;
      if (filter === "all") {
        container.querySelectorAll(".hub-filter").forEach(b => {
          b.classList.remove("active");
          b.setAttribute("aria-pressed", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
        SCRIPT_HUB_STATE.filters = new Set(["all"]);
      } else {
        const allBtn = container.querySelector('[data-filter="all"]');
        if (allBtn) {
          allBtn.classList.remove("active");
          allBtn.setAttribute("aria-pressed", "false");
        }
        btn.classList.toggle("active");
        btn.setAttribute("aria-pressed", btn.classList.contains("active"));
        SCRIPT_HUB_STATE.filters = new Set(
          Array.from(container.querySelectorAll(".hub-filter.active")).map(b => b.dataset.filter)
        );
        if (SCRIPT_HUB_STATE.filters.size === 0) {
          const allBtn = container.querySelector('[data-filter="all"]');
          if (allBtn) {
            allBtn.classList.add("active");
            allBtn.setAttribute("aria-pressed", "true");
            SCRIPT_HUB_STATE.filters.add("all");
          }
        }
      }
      RenderAllScriptsSection();
    });
  });
}

// Sort change
function SetupSort() {
  const select = document.getElementById("hub-sort");
  if (!select) return;
  select.addEventListener("change", () => {
    SCRIPT_HUB_STATE.sort = select.value;
    RenderAllScriptsSection();
  });
}

// Refresh button
function SetupRefresh() {
  const btn = document.getElementById("hub-refresh");
  if (!btn) return;
  btn.addEventListener("click", () => {
    btn.disabled = true;
    btn.style.opacity = "0.6";
    RefreshScripthubGrid().finally(() => {
      btn.disabled = false;
      btn.style.opacity = "";
    });
  });
}

// API key button — opens Settings focused on the RScripts key field
function SetupApiKeyButton() {
  const btn = document.getElementById("hub-api-key");
  if (!btn) return;
  btn.addEventListener("click", () => {
    SwitchView("settings");
    if (typeof SetSettingsQuery === "function") {
      SetSettingsQuery("rscripts");
    }
  });
}

// Buttons inside the hub error/empty state (Open Settings / Retry)
function SetupErrorStateButtons() {
  document.addEventListener("click", (e) => {
    const action = e.target.closest("[data-action]");
    if (!action) return;
    if (action.dataset.action === "open-api-key-settings") {
      SwitchView("settings");
      if (typeof SetSettingsQuery === "function") SetSettingsQuery("rscripts");
    } else if (action.dataset.action === "retry-scripthub") {
      action.closest(".hub-error-state")?.remove();
      RefreshScripthubGrid();
    }
  });
}

// Create new script button
function SetupCreateButton() {
  const btn = document.getElementById("hub-create");
  if (!btn) return;
  btn.addEventListener("click", () => {
    SwitchView("editor");
    if (typeof CreateNewTab === "function") CreateNewTab();
  });
}

// Initialize all Script Hub features
function InitScripthubFeatures() {
  SetupFilterButtons();
  SetupSort();
  SetupRefresh();
  SetupApiKeyButton();
  SetupErrorStateButtons();
  SetupCreateButton();
  SetupSearchSuggestions();
  LoadTrendingOnStart();
}

// Export
window.SwitchView = SwitchView;
window.GetActiveView = GetActiveView;
window.InitViewTabs = InitViewTabs;
window.RefreshScripthubGrid = RefreshScripthubGrid;
window.GetScripthubScripts = GetScripthubScripts;
window.AddScripthubScript = function(script) {
  const scripts = GetScripthubScripts();
  scripts.unshift(script);
  SaveScripthubScripts(scripts);
  RefreshScripthubGrid();
};
window.BuildHomeGrid = BuildHomeGrid;
window.InitScripthubFeatures = InitScripthubFeatures;

function SaveScripthubScripts(scripts) {
  try {
    localStorage.setItem("hexion_scripthub_scripts", JSON.stringify(scripts));
  } catch (err) {
    console.warn("could not save scripthub scripts:", err);
  }
}

function OpenScripthubScript(script) {
  SwitchView("editor");
  if (typeof CreateNewTab === "function") {
    CreateNewTab().then((tab) => {
      if (tab) {
        tab.content = script.content;
        tab.name = script.name + ".lua";
        const editor_input = document.getElementById("editor-input");
        if (editor_input) {
          editor_input.value = script.content;
          editor_input.dispatchEvent(new Event("input"));
        }
      }
    });
  }
}

function RunScripthubScript(script) {
  const raw_url = script.rawScriptUrl || script.raw_url || null;
  if (raw_url) {
    fetch(raw_url)
      .then((res) => res.text())
      .then((content) => {
        if (typeof ExecuteScript === "function") {
          ExecuteScript(content, script.name);
        }
      })
      .catch((err) => console.error("Failed to fetch script content:", err));
  } else if (script.content && typeof ExecuteScript === "function") {
    ExecuteScript(script.content, script.name);
  }
}

function EditScripthubScript(script) {
  OpenScripthubScript(script);
}

function DeleteScripthubScript(script) {
  if (!confirm(`Delete "${script.name}"?`)) return;
  const scripts = GetScripthubScripts().filter((s) => s.id !== script.id);
  SaveScripthubScripts(scripts);
  RefreshScripthubGrid();
}

function AddScripthubScript(script) {
  const scripts = GetScripthubScripts();
  const new_script = {
    id: "custom-" + Date.now(),
    name: script.name || "Untitled Script",
    description: script.description || "",
    type: script.type || "script",
    author: script.author || "Local",
    updated_at: new Date().toISOString(),
    downloads: 0,
    content: script.content || "",
    tags: script.tags || [],
  };
  scripts.unshift(new_script);
  SaveScripthubScripts(scripts);
  RefreshScripthubGrid();
  return new_script;
}

function FormatRelativeTime(date) {
  const now = new Date();
  const diff_ms = now - date;
  const diff_sec = Math.floor(diff_ms / 1000);
  const diff_min = Math.floor(diff_sec / 60);
  const diff_hour = Math.floor(diff_min / 60);
  const diff_day = Math.floor(diff_hour / 24);

  if (diff_sec < 60) return "just now";
  if (diff_min < 60) return `${diff_min}m ago`;
  if (diff_hour < 24) return `${diff_hour}h ago`;
  if (diff_day < 7) return `${diff_day}d ago`;
  if (diff_day < 30) return `${Math.floor(diff_day / 7)}w ago`;
  if (diff_day < 365) return `${Math.floor(diff_day / 30)}mo ago`;
  return `${Math.floor(diff_day / 365)}y ago`;
}

function FormatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return String(num);
}

function EscapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function BuildHomeGrid() {
  const grid = document.getElementById("home-grid");
  if (!grid) return;

  const cards = [
    {
      icon: "code",
      title: "New Script",
      desc: "Create a new Lua script in the editor",
      action: () => { SwitchView("editor"); CreateNewTab(); },
    },
    {
      icon: "folderopen",
      title: "Open File",
      desc: "Open an existing script from disk",
      action: () => { SwitchView("editor"); OpenFilePicker(); },
    },
    {
      icon: "library",
      title: "Script Hub",
      desc: "Browse and manage your script collection",
      action: () => SwitchView("scripthub"),
    },
    {
      icon: "settings",
      title: "Settings",
      desc: "Configure editor, themes, and preferences",
      action: () => SwitchView("settings"),
    },
    {
      icon: "terminal",
      title: "Console",
      desc: "View output and debug your scripts",
      action: () => { ToggleConsole(); },
    },
    {
      icon: "client",
      title: "Clients",
      desc: "Manage attached Roblox clients",
      action: () => { ToggleClientsPop(); },
    },
  ];

  grid.innerHTML = cards.map((card) => `
    <a class="home-card" href="#" data-view="${card.icon}">
      <div class="home-card-icon">
        <span data-icon="${card.icon}"></span>
      </div>
      <h3 class="home-card-title">${EscapeHtml(card.title)}</h3>
      <p class="home-card-desc">${EscapeHtml(card.desc)}</p>
    </a>
  `).join("");

  grid.querySelectorAll(".home-card").forEach((card, index) => {
    card.addEventListener("click", (e) => {
      e.preventDefault();
      cards[index].action();
    });
  });
}

function OpenFilePicker() {
  if (window.__TAURI__ && window.__TAURI__.dialog) {
    window.__TAURI__.dialog.open({
      multiple: false,
      filters: [{ name: "Lua", extensions: ["lua", "txt"] }, { name: "All", extensions: ["*"] }],
    }).then((path) => {
      if (path) {
        SwitchView("editor");
        if (typeof OpenFileTab === "function") {
          OpenFileTab(path, path.split(/[\\/]/).pop());
        }
      }
    });
  }
}

function ToggleConsole() {
  const console_panel = document.getElementById("console-panel");
  const strip = document.getElementById("console-reveal-strip");
  if (console_panel && strip) {
    const is_hidden = console_panel.classList.toggle("console-hidden");
    strip.classList.toggle("console-reveal-strip-hidden", is_hidden);
  }
}

window.SwitchView = SwitchView;
window.GetActiveView = GetActiveView;
window.InitViewTabs = InitViewTabs;
window.RefreshScripthubGrid = RefreshScripthubGrid;
window.GetScripthubScripts = GetScripthubScripts;
window.AddScripthubScript = AddScripthubScript;
window.BuildHomeGrid = BuildHomeGrid;