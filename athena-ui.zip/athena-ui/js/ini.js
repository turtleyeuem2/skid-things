function ParseIni(raw_text) {
  const result = {};
  let current_section = null;

  const lines = raw_text.split(/\r?\n/);

  for (const raw_line of lines) {
    const line = raw_line.trim();

    if (line.length === 0 || line.startsWith(";") || line.startsWith("#")) {
      continue;
    }

    const section_match = line.match(/^\[(.+)\]$/);
    if (section_match) {
      current_section = section_match[1];
      result[current_section] = {};
      continue;
    }

    if (current_section === null) {
      continue;
    }

    const eq_index = line.indexOf("=");
    if (eq_index === -1) {
      continue;
    }

    const key = line.slice(0, eq_index).trim();
    const value = line.slice(eq_index + 1).trim();
    result[current_section][key] = value;
  }

  return result;
}
