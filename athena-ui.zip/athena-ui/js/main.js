const EXPLORER_COLLAPSE_THRESHOLD = 90;

const WORKSPACE_FOLDERS = ["workspace", "config", "scripts", "autoexec"];

const UI_FONT_FALLBACKS = [
  "-apple-system",
  "BlinkMacSystemFont",
  "Avenir",
  "Helvetica",
  "Arial",
  "sans-serif",
];

const CODE_FONT_FALLBACKS = [
  "ui-monospace",
  "Cascadia Mono",
  "Consolas",
  "monospace",
];

const WORKSPACE_SEED_FILES = [
  { path: ["config", "explorer.ini"], content: () => DEFAULT_EXPLORER_INI }
];

async function ExecuteScript(source, file_name) {
  const script = source == null ? "" : String(source);
  const label = file_name || "script";

  if (script.trim().length === 0) {
    LogWarn("nothing to run");
    return;
  }

  const pids = GetSelectedClientPids();

  if (pids.length === 0) {
    LogWarn("no clients selected");
    if (UI_STATE.notify_show_errors !== false) {
      Notify("No clients selected", "warn");
    }
    return;
  }

  if (UI_STATE.console_clear_on_run) {
    ClearConsole();
  }

  let ok_count = 0;
  let needs_attach = false;

  for (const pid of pids) {
    try {
      const result = await window.__TAURI__.core.invoke("execute", { script, pid });

      if (!result) {
        LogError(`run failed on ${pid}: no response from the executor`);
        continue;
      }

      if (result.ok) {
        ok_count += 1;
        if (UI_STATE.console_show_script_run_prints !== false) {
          LogPrint(`ran ${label} on ${pid} in ${result.ms}ms`);
        }
        continue;
      }

      if (result.code === "not_attached") {
        needs_attach = true;
        SetConnectedState(false);
      }

      LogError(`run failed on ${pid}: ${result.message || "unknown error"}`);
    } catch (err) {
      LogError(`run failed on ${pid}: ${err}`);
    }
  }

  if (ok_count === 0) {
    if (needs_attach) {
      LogWarn("attach with the loader before running a script");
      if (UI_STATE.notify_show_errors !== false) {
        Notify("Not attached yet, press attach first", "warn");
      }
      return;
    }

    if (UI_STATE.notify_show_errors !== false) {
      Notify(`Failed on all ${pids.length} clients`, "error");
    }
    return;
  }

  if (ok_count < pids.length) {
    if (UI_STATE.notify_show_errors !== false) {
      Notify(`Ran on ${ok_count} of ${pids.length} clients`, "warn");
    }
    return;
  }

  if (UI_STATE.notify_show_script_run !== false) {
    Notify(`Ran on ${ok_count} client${ok_count === 1 ? "" : "s"}`, "success");
  }
}

function FlashAttachButton(did_work) {
  const attach_btn = document.getElementById("console-on-btn");

  if (!attach_btn) {
    return;
  }

  const class_name = did_work ? "tool-btn-ok" : "tool-btn-fail";

  attach_btn.classList.remove("tool-btn-ok", "tool-btn-fail");
  void attach_btn.offsetWidth;
  attach_btn.classList.add(class_name);

  window.setTimeout(() => {
    attach_btn.classList.remove(class_name);
  }, 620);
}

async function Attach() {
  try {
    const result = await window.__TAURI__.core.invoke("run_attach");

    if (!result || !result.ok) {
      const message = (result && result.message) || "attach failed";
      LogError(`attach failed: ${message}`);
      FlashAttachButton(false);
      SetConnectedState(false);
      if (UI_STATE.notify_show_errors !== false) {
        Notify(message, "error");
      }
      return;
    }

    LogPrint(result.message);
    FlashAttachButton(true);
    SetConnectedState(true);
    if (UI_STATE.notify_show_attach !== false) {
      Notify(result.message, "success");
    }
    await HandleConsoleRedirectionChanged(GetOption("ConsoleRedirection"));
  } catch (err) {
    LogError(`attach failed: ${err}`);
    FlashAttachButton(false);
    SetConnectedState(false);
    if (UI_STATE.notify_show_errors !== false) {
      Notify("Failed to attach", "error");
    }
  }
}

function ApplyUiFonts() {
  const root = document.documentElement;
  const SetFont = (name, value) => {
    if (value) {
      root.style.setProperty(name, value);
    }
  };

  SetFont("--ui-font", FontStack(UI_STATE.ui_font_family, UI_FONT_FALLBACKS));
  SetFont("--ui-weight", String(UI_STATE.ui_font_weight));
  SetFont("--ed-font", FontStack(UI_STATE.editor_font_family, CODE_FONT_FALLBACKS));
  SetFont("--ed-weight", String(UI_STATE.editor_font_weight));
  SetFont("--con-font", FontStack(UI_STATE.console_font_family, CODE_FONT_FALLBACKS));
  SetFont("--con-weight", String(UI_STATE.console_font_weight));
}

function FontStack(family_name, fallbacks) {
  const needs_quotes = /\s/.test(family_name);
  const quoted = needs_quotes ? `"${family_name}"` : family_name;
  return [quoted, ...fallbacks].join(", ");
}

function StripNativeTooltips(root) {
  const scope = root || document;

  const MoveTitle = (el) => {
    const text = el.getAttribute("title");

    if (text && !el.hasAttribute("data-tooltip")) {
      el.setAttribute("data-tooltip", text);
    }

    el.removeAttribute("title");
  };

  if (scope.querySelectorAll) {
    scope.querySelectorAll("[title]").forEach(MoveTitle);
  }

  if (scope.hasAttribute && scope.hasAttribute("title")) {
    MoveTitle(scope);
  }
}

function WatchForNativeTooltips() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === "attributes") {
        StripNativeTooltips(mutation.target);
        continue;
      }

      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === 1) {
          StripNativeTooltips(node);
        }
      });
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["title"],
  });
}

const OS_DROP_DEDUPE_MS = 600;

let os_drop_handled_at = 0;

function HasDraggedFiles(event) {
  if (!event.dataTransfer || !event.dataTransfer.types) {
    return false;
  }

  return Array.from(event.dataTransfer.types).includes("Files");
}

function MarkOsDropHandled() {
  os_drop_handled_at = Date.now();
}

function WasOsDropHandledRecently() {
  return Date.now() - os_drop_handled_at < OS_DROP_DEDUPE_MS;
}

async function OpenDroppedBrowserFile(file) {
  const file_name = file.name || "dropped file";

  if (!file.path) {
    LogError(`could not resolve a path for "${file_name}", the tab would not point at the file`);
    if (UI_STATE.notify_show_errors !== false) {
      Notify("Could not open that drop", "error");
    }
    return;
  }

  await OpenFileTab(file.path, file_name);
}

async function SetupOsFileDrop() {
  const editor_area = document.querySelector(".editor-area");
  const editor_pane = document.getElementById("editor-mount");

  const SetDropHover = (on) => {
    if (editor_area) {
      editor_area.classList.toggle("is-os-file-drop", on);
    }
    if (editor_pane) {
      editor_pane.classList.toggle("is-os-file-drop", on);
    }
  };

  if (window.__TAURI__ && window.__TAURI__.window) {
    try {
      const app_window = GetAppWindow();
      await app_window.onDragDropEvent((event) => {
        const payload = event.payload || {};
        const kind = payload.type;

        if (kind === "enter" || kind === "over") {
          SetDropHover(true);
          return;
        }

        if (kind === "leave") {
          SetDropHover(false);
          return;
        }

        if (kind === "drop") {
          SetDropHover(false);
          MarkOsDropHandled();

          OpenDroppedPaths(payload.paths || []);
        }
      });
    } catch (err) {
      LogError("could not bind window file drop:", err);
      if (UI_STATE.notify_show_errors !== false) {
        Notify("File drop is unavailable", "error");
      }
    }
  }

  window.addEventListener("dragover", (event) => {
    if (!HasDraggedFiles(event)) {
      return;
    }

    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
    SetDropHover(true);
  });

  window.addEventListener("dragleave", (event) => {
    if (event.relatedTarget) {
      return;
    }

    SetDropHover(false);
  });

  window.addEventListener("drop", async (event) => {
    const files = event.dataTransfer && event.dataTransfer.files;

    if (!files || files.length === 0) {
      return;
    }

    event.preventDefault();
    SetDropHover(false);

    if (WasOsDropHandledRecently()) {
      return;
    }

    MarkOsDropHandled();

    for (const file of Array.from(files)) {
      await OpenDroppedBrowserFile(file);
    }
  });
}

async function LoadPartial(url, mount_id) {
  const response = await fetch(url);
  const html = await response.text();
  const mount_el = document.getElementById(mount_id);
  mount_el.innerHTML = html;
}

async function LoadPartials() {
  await LoadPartial("main/html/body.html", "body-mount");
  await LoadPartial("main/html/titlebar.html", "titlebar-mount");
  await LoadPartial("editor/html/editor.html", "editor-mount");
}

function GetAppWindow() {
  return window.__TAURI__.window.getCurrentWindow();
}

function ParseVersionText(raw_text) {
  const line = String(raw_text || "")
    .split(/\r?\n/)
    .map((part) => part.trim())
    .find((part) => part.length > 0);

  return line ? line.toLowerCase() : "";
}

async function ReadVersionFileText() {
  const base_dir = await GetBaseDir();
  const version_path = await JoinPath(base_dir, "version.txt");

  if (!(await FsPathExists(version_path))) {
    return "";
  }

  return await FsReadTextFile(version_path);
}

async function ApplyTitlebarVersion() {
  const version_el = document.getElementById("titlebar-version");

  if (!version_el) {
    return;
  }

  let version = "";

  try {
    version = ParseVersionText(await ReadVersionFileText());
  } catch (err) {
    version = "";
  }

  version_el.textContent = version || "dev";
}

async function HandleMinimize() {
  const app_window = GetAppWindow();
  await app_window.minimize();
}

async function HandleMaximize() {
  const app_window = GetAppWindow();
  await app_window.toggleMaximize();
}

async function SaveAndQuit() {
  try {
    await SaveAllTabs();
  } catch (err) {
    console.warn("could not save tabs on close, closing anyway:", err);
  }

  try {
    await WriteExplorerIniNow();
  } catch (err) {
    console.warn("could not flush explorer.ini on close:", err);
  }

  try {
    await WriteUiStateNow();
  } catch (err) {
    console.warn("could not flush ui state on close:", err);
  }

  try {
    await SaveOptionsNow();
  } catch (err) {
    console.warn("could not flush options on close:", err);
  }

  const app_window = GetAppWindow();

  try {
    await app_window.destroy();
  } catch (err) {
    await app_window.close();
  }
}

async function HandleClose(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }

  await SaveAndQuit();
}

function SetupTitlebar() {
  if (!window.__TAURI__) {
    console.error("window.__TAURI__ is undefined, window controls will not work");
    return;
  }

  const minimize_btn = document.getElementById("titlebar-minimize");
  const maximize_btn = document.getElementById("titlebar-maximize");
  const close_btn = document.getElementById("titlebar-close");

  if (!minimize_btn || !maximize_btn || !close_btn) {
    console.error("titlebar buttons not found in DOM");
    return;
  }

  minimize_btn.addEventListener("click", HandleMinimize);
  maximize_btn.addEventListener("click", HandleMaximize);
  close_btn.addEventListener("mousedown", (event) => event.stopPropagation());
  close_btn.addEventListener("click", HandleClose);
}

async function IsDebugBuild() {
  if (!window.__TAURI__ || !window.__TAURI__.core) {
    return true;
  }

  try {
    return Boolean(await window.__TAURI__.core.invoke("is_debug_build"));
  } catch (err) {
    return true;
  }
}

function SuppressWebviewContextMenu() {
  document.addEventListener(
    "contextmenu",
    (event) => {
      event.preventDefault();
    },
    true
  );
}

async function DisableContextMenu() {
  if (await IsDebugBuild()) {
    return;
  }

  window.addEventListener(
    "keydown",
    (event) => {
      const key = event.key.toLowerCase();
      const has_mod = event.ctrlKey || event.metaKey;
      const is_devtools_combo =
        event.key === "F12" ||
        (has_mod && event.shiftKey && (key === "i" || key === "j" || key === "c")) ||
        (has_mod && key === "u");

      if (is_devtools_combo) {
        event.preventDefault();
        event.stopPropagation();
      }
    },
    true
  );
}

const EXPLORER_SIDE_LEFT = "left";
const EXPLORER_SIDE_RIGHT = "right";

function IsExplorerOnRight() {
  return UI_STATE.explorer_side === EXPLORER_SIDE_RIGHT;
}

function ApplyExplorerSide(side) {
  const app_body = document.querySelector(".app-body");
  const reveal_strip = document.getElementById("explorer-reveal-strip");

  const next_side = side === EXPLORER_SIDE_RIGHT ? EXPLORER_SIDE_RIGHT : EXPLORER_SIDE_LEFT;
  UI_STATE.explorer_side = next_side;

  if (app_body) {
    app_body.classList.toggle("app-body-explorer-right", next_side === EXPLORER_SIDE_RIGHT);
  }

  if (reveal_strip) {
    reveal_strip.innerHTML = IconTag(
      next_side === EXPLORER_SIDE_RIGHT ? "arrowleft" : "arrowright"
    );
  }

  const corner_el = document.getElementById("corner-resizer");

  if (corner_el) {
    corner_el.classList.toggle("corner-resizer-on-right", next_side === EXPLORER_SIDE_RIGHT);
  }

  requestAnimationFrame(RefreshEditorMetrics);
}

function GetExplorerWidthFromPointer(client_x) {
  return IsExplorerOnRight() ? window.innerWidth - client_x : client_x;
}

function GetExplorerPanel() {
  return document.querySelector(".explorer");
}

function SetExplorerHidden(explorer_el, reveal_strip, hidden) {
  const app_body = document.querySelector(".app-body");

  UI_STATE.explorer_hidden = hidden;
  explorer_el.classList.remove("explorer-no-anim");
  explorer_el.classList.toggle("explorer-hidden", hidden);
  reveal_strip.classList.toggle("explorer-reveal-strip-visible", hidden);

  if (app_body) {
    app_body.classList.toggle("app-body-explorer-collapsed", hidden);
  }

  if (!hidden) {
    explorer_el.style.width = `${UI_STATE.explorer_width}px`;
  }

  requestAnimationFrame(RefreshEditorMetrics);

  SaveUiState();
}

function SetExplorerWidth(width_px) {
  const explorer_el = GetExplorerPanel();

  if (!explorer_el) {
    return;
  }

  if (UI_STATE.explorer_hidden) {
    SetExplorerHidden(explorer_el, document.getElementById("explorer-reveal-strip"), false);
  }

  explorer_el.style.width = `${width_px}px`;

  requestAnimationFrame(RefreshEditorMetrics);
}

function SetupExplorerResizer() {
  const resizer = document.getElementById("explorer-resizer");
  const explorer_el = GetExplorerPanel();
  const reveal_strip = document.getElementById("explorer-reveal-strip");

  if (!resizer || !explorer_el || !reveal_strip) {
    return;
  }

  ApplyExplorerSide(UI_STATE.explorer_side);

  if (UI_STATE.explorer_hidden) {
    SetExplorerHidden(explorer_el, reveal_strip, true);
  } else {
    explorer_el.style.width = `${UI_STATE.explorer_width}px`;
  }

  SetupPanelResizer(resizer, {
    axis: "horizontal",
    collapse_threshold: EXPLORER_COLLAPSE_THRESHOLD,
    on_collapse_start: () => {
      if (UI_STATE.explorer_hidden) {
        SetExplorerHidden(explorer_el, reveal_strip, false);
      }
    },
    on_collapse_end: () => SetExplorerHidden(explorer_el, reveal_strip, true),
    measure: (event) => GetExplorerWidthFromPointer(event.clientX),
    apply: (raw_width) => {
      explorer_el.classList.add("explorer-no-anim");
      explorer_el.style.width = raw_width > 0 ? `${ClampUiStateNumber("explorer_width", raw_width)}px` : "0px";
      requestAnimationFrame(RefreshEditorMetrics);
    },
    commit: () => {
      explorer_el.classList.remove("explorer-no-anim");
      UI_STATE.explorer_width = explorer_el.getBoundingClientRect().width;
      SaveUiState();
    },
  });

  reveal_strip.addEventListener("click", () => {
    SetExplorerHidden(explorer_el, reveal_strip, false);
  });
}

function SetupCornerResizer() {
  const corner_handle = document.getElementById("corner-resizer");
  const explorer_el = GetExplorerPanel();
  const reveal_strip = document.getElementById("explorer-reveal-strip");
  const { panel: console_panel, editor_area } = GetConsoleEls();

  if (!corner_handle || !explorer_el || !reveal_strip || !console_panel || !editor_area) {
    return;
  }

  corner_handle.classList.toggle("corner-resizer-on-right", IsExplorerOnRight());

  let is_dragging = false;
  let collapse_explorer = false;
  let collapse_console = false;

  corner_handle.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    is_dragging = true;
    collapse_explorer = false;
    collapse_console = false;
    document.body.style.cursor = "nwse-resize";

    if (UI_STATE.explorer_hidden) {
      SetExplorerHidden(explorer_el, reveal_strip, false);
    }

    if (UI_STATE.console_hidden) {
      SetConsoleHidden(false);
    }
  });

  window.addEventListener("mousemove", (event) => {
    if (!is_dragging) {
      return;
    }

    const raw_width = GetExplorerWidthFromPointer(event.clientX);

    explorer_el.classList.add("explorer-no-anim");

    if (raw_width < EXPLORER_COLLAPSE_THRESHOLD) {
      collapse_explorer = true;
      explorer_el.style.width = "0px";
    } else {
      collapse_explorer = false;
      explorer_el.style.width = `${ClampUiStateNumber("explorer_width", raw_width)}px`;
    }

    const area_rect = editor_area.getBoundingClientRect();
    const toolbar_el = document.getElementById("console-toolbar");
    const toolbar_height = toolbar_el ? toolbar_el.getBoundingClientRect().height : 0;
    const raw_height = area_rect.bottom - event.clientY - toolbar_height;

    if (raw_height < CONSOLE_COLLAPSE_THRESHOLD) {
      collapse_console = true;
      console_panel.style.height = "0px";
    } else {
      collapse_console = false;
      console_panel.style.height = `${ClampUiStateNumber("console_height", raw_height)}px`;
    }

    requestAnimationFrame(RefreshEditorMetrics);
  });

  window.addEventListener("mouseup", () => {
    if (!is_dragging) {
      return;
    }

    is_dragging = false;
    document.body.style.cursor = "";
    explorer_el.classList.remove("explorer-no-anim");

    if (collapse_explorer) {
      SetExplorerHidden(explorer_el, reveal_strip, true);
    } else {
      UI_STATE.explorer_width = explorer_el.getBoundingClientRect().width;
    }

    if (collapse_console) {
      SetConsoleHidden(true);
    } else {
      UI_STATE.console_height = Math.round(console_panel.getBoundingClientRect().height);
    }

    requestAnimationFrame(RefreshEditorMetrics);
    SaveUiState();
  });
}

async function WriteSeedFile(base_dir, path_parts, content) {
  let file_path = base_dir;

  for (const path_part of path_parts) {
    file_path = await JoinPath(file_path, path_part);
  }

  try {
    const already_exists = await FsPathExists(file_path);

    if (already_exists) {
      return false;
    }

    await FsWriteTextFile(file_path, content);
    return true;
  } catch (err) {
    LogWarn("could not create default file:", file_path, err);
    return false;
  }
}

async function SetupWorkspaceScaffold() {
  const base_dir = await GetBaseDir();

  for (const folder_name of WORKSPACE_FOLDERS) {
    await EnsureFolder(await JoinPath(base_dir, folder_name));
  }

  for (const seed_file of WORKSPACE_SEED_FILES) {
    const did_write = await WriteSeedFile(base_dir, seed_file.path, seed_file.content());

    if (did_write) {
      LogPrint(`created ${seed_file.path.join("/")}`);
    }
  }
}

async function SetupHexionEnvVar() {
  if (!window.__TAURI__ || !window.__TAURI__.core) {
    return;
  }

  try {
    await window.__TAURI__.core.invoke("set_hexion_env_var");
  } catch (err) {
    LogWarn("could not set Hexion environment variable:", err);
  }
}

async function SetupCloseSave() {
  try {
    const app_window = GetAppWindow();
    await app_window.onCloseRequested(async (event) => {
      event.preventDefault();
      await SaveAndQuit();
    });
  } catch (err) {
    console.warn("could not register close-save handler:", err);
  }
}

async function SyncAlwaysOnTopWithWindowState() {
  if (!window.__TAURI__ || !window.__TAURI__.window) {
    return;
  }

  try {
    const app_window = GetAppWindow();
    const should_be_on_top = UI_STATE.always_on_top && !(await app_window.isMaximized());
    const currently_on_top = await app_window.isAlwaysOnTop();

    if (currently_on_top !== should_be_on_top) {
      await app_window.setAlwaysOnTop(should_be_on_top);
    }
  } catch (err) {
    LogWarn("could not sync always-on-top with window state:", err);
  }
}

async function SetupAlwaysOnTopRule() {
  if (!window.__TAURI__ || !window.__TAURI__.window) {
    return;
  }

  try {
    const app_window = GetAppWindow();
    app_window.onResized(() => {
      SyncAlwaysOnTopWithWindowState();
    });
    app_window.onMoved(() => {
      SyncAlwaysOnTopWithWindowState();
    });
    await SyncAlwaysOnTopWithWindowState();
  } catch (err) {
    LogWarn("could not set up always-on-top rules:", err);
  }
}

async function SetupStartMaximized() {
  if (!UI_STATE.start_maximized) {
    return;
  }

  try {
    const app_window = GetAppWindow();

    if (!(await app_window.isMaximized())) {
      await app_window.maximize();
    }
  } catch (err) {
    LogWarn("could not maximize the window:", err);
  }
}

async function RunSafe(label, task) {
  try {
    await task();
  } catch (err) {
    console.error(`${label} failed:`, err);
  }
}

window.addEventListener("DOMContentLoaded", async () => {
  SuppressWebviewContextMenu();

  await LoadPartials();
  HydrateIconSlots();
  CacheConsoleEls();
  StripNativeTooltips();
  WatchForNativeTooltips();
  await RunSafe("SetupTooltips", SetupTooltips);
  SetupTitlebar();
  await RunSafe("ApplyTitlebarVersion", ApplyTitlebarVersion);
  await RunSafe("InitViewTabs", InitViewTabs);
  await RunSafe("InitScripthubFeatures", InitScripthubFeatures);

  if (window.__TAURI__) {
    await RunSafe("LoadUiState", LoadUiState);
    await RunSafe("SetupStartMaximized", SetupStartMaximized);
    await RunSafe("SetupWorkspaceScaffold", SetupWorkspaceScaffold);
    await RunSafe("LoadOptions", LoadOptions);
  }

  await RunSafe("ApplyUiTheme", ApplyUiTheme);
  await RunSafe("ApplyRevealStrips", ApplyRevealStrips);
  await RunSafe("ApplyAccentColor", () => ApplyAccentColor(UI_STATE.accent_color));
  await RunSafe("ApplyUiDensity", ApplyUiDensity);
  await RunSafe("ApplyUiMotion", ApplyUiMotion);

  await RunSafe("SetupEditorSurface", SetupEditorSurface);
  await RunSafe("ApplyEditorCaretStyle", ApplyEditorCaretStyle);
  await RunSafe("ApplyEditorSelectionStyle", ApplyEditorSelectionStyle);
  await RunSafe("SetupLinter", SetupLinter);
  await RunSafe("SetupConsole", SetupConsole);
  await RunSafe("SetupToolbarButtons", SetupToolbarButtons);
  await RunSafe("SetupSettingsPanel", SetupSettingsPanel);
  await RunSafe("SetupCommandPalette", SetupCommandPalette);

  if (window.__TAURI__) {
    await RunSafe("SetupClientsPanel", SetupClientsPanel);
    await RunSafe("SetupExplorerResizer", SetupExplorerResizer);
    await RunSafe("SetupCornerResizer", SetupCornerResizer);
    await RunSafe("SetupOsFileDrop", SetupOsFileDrop);
    await RunSafe("LoadExplorerPanel", LoadExplorerPanel);
    await RunSafe("InitTabs", InitTabs);
    await RunSafe("SetupCloseSave", SetupCloseSave);
    await RunSafe("SetupDiscordRpc", SetupDiscordRpc);
  }

  await RunSafe("ApplyUiStateSettings", ApplyUiStateSettings);

  if (window.__TAURI__) {
    await RunSafe("SetupHexionEnvVar", SetupHexionEnvVar);
    await RunSafe("SetupAlwaysOnTopRule", SetupAlwaysOnTopRule);
  }
});
