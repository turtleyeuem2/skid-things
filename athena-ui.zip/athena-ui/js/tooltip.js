const TOOLTIP_OFFSET_X = 12;
const TOOLTIP_OFFSET_Y = 18;
const TOOLTIP_EDGE_GAP = 8;
const TOOLTIP_WRAP_LENGTH = 34;

const TOOLTIP_STATE = {
  el: null,
  target: null,
  timer_id: null,
  x: 0,
  y: 0,
};

function GetTooltipEl() {
  if (TOOLTIP_STATE.el) {
    return TOOLTIP_STATE.el;
  }

  const el = document.createElement("div");
  el.className = "app-tooltip";
  el.setAttribute("role", "tooltip");
  document.body.appendChild(el);
  TOOLTIP_STATE.el = el;
  return el;
}

function FindTooltipTarget(node) {
  if (!node || !node.closest) {
    return null;
  }

  return node.closest("[data-tooltip]");
}

function PositionTooltip() {
  const el = GetTooltipEl();
  const rect = el.getBoundingClientRect();

  let left = TOOLTIP_STATE.x + TOOLTIP_OFFSET_X;
  let top = TOOLTIP_STATE.y + TOOLTIP_OFFSET_Y;

  if (left + rect.width > window.innerWidth - TOOLTIP_EDGE_GAP) {
    left = TOOLTIP_STATE.x - rect.width - TOOLTIP_OFFSET_X;
  }

  if (top + rect.height > window.innerHeight - TOOLTIP_EDGE_GAP) {
    top = TOOLTIP_STATE.y - rect.height - 10;
  }

  el.style.left = `${Math.max(TOOLTIP_EDGE_GAP, left)}px`;
  el.style.top = `${Math.max(TOOLTIP_EDGE_GAP, top)}px`;
}

function HideTooltip() {
  if (TOOLTIP_STATE.timer_id) {
    clearTimeout(TOOLTIP_STATE.timer_id);
    TOOLTIP_STATE.timer_id = null;
  }

  TOOLTIP_STATE.target = null;

  if (TOOLTIP_STATE.el) {
    TOOLTIP_STATE.el.classList.remove("app-tooltip-visible");
  }
}

function ShowTooltip(target) {
  const text = target.getAttribute("data-tooltip");

  if (!text) {
    return;
  }

  const el = GetTooltipEl();
  el.textContent = text;
  el.classList.toggle("app-tooltip-wrap", text.length > TOOLTIP_WRAP_LENGTH);
  PositionTooltip();
  el.classList.add("app-tooltip-visible");
}

function GetTooltipDelayMs() {
  return GetUiStateRangedNumber("tooltip_delay_ms");
}

function ScheduleTooltip(target) {
  if (TOOLTIP_STATE.timer_id) {
    clearTimeout(TOOLTIP_STATE.timer_id);
  }

  TOOLTIP_STATE.timer_id = setTimeout(() => {
    TOOLTIP_STATE.timer_id = null;

    if (TOOLTIP_STATE.target === target && document.body.contains(target)) {
      ShowTooltip(target);
    }
  }, GetTooltipDelayMs());
}

function HandleTooltipMouseMove(event) {
  TOOLTIP_STATE.x = event.clientX;
  TOOLTIP_STATE.y = event.clientY;

  const target = FindTooltipTarget(event.target);

  if (!target) {
    if (TOOLTIP_STATE.target) {
      HideTooltip();
    }
    return;
  }

  if (target !== TOOLTIP_STATE.target) {
    HideTooltip();
    TOOLTIP_STATE.target = target;
    ScheduleTooltip(target);
    return;
  }

  if (TOOLTIP_STATE.el && TOOLTIP_STATE.el.classList.contains("app-tooltip-visible")) {
    PositionTooltip();
  }
}

function SetupTooltips() {
  GetTooltipEl();

  document.addEventListener("mousemove", HandleTooltipMouseMove, true);
  document.addEventListener("mousedown", HideTooltip, true);
  document.addEventListener("wheel", HideTooltip, true);
  document.addEventListener("keydown", HideTooltip, true);
  window.addEventListener("blur", HideTooltip);
  document.addEventListener("mouseleave", HideTooltip);
}
