const STATUS_BAR_STATE = {
  connected: false,
  last_position: "",
};

function UpdateStatusBarCaret() {
  const status_el = document.getElementById("status-ln-col");
  const textarea = document.getElementById("editor-input");

  if (!status_el) {
    return;
  }

  let ln = 1;
  let col = 1;
  let selected = 0;

  if (textarea) {
    const caret = textarea.selectionStart;
    const before = textarea.value.slice(0, caret);
    const lines = before.split("\n");
    ln = lines.length;
    col = (lines[lines.length - 1] || "").length + 1;
    selected = textarea.selectionEnd - textarea.selectionStart;
  }

  const text =
    selected > 0 ? `Ln ${ln}, Col ${col} (${selected} selected)` : `Ln ${ln}, Col ${col}`;

  if (STATUS_BAR_STATE.last_position !== text) {
    STATUS_BAR_STATE.last_position = text;
    status_el.textContent = text;
  }
}

function SetConnectedState(connected) {
  STATUS_BAR_STATE.connected = Boolean(connected);

  const status_el = document.getElementById("status-conn");
  if (!status_el) {
    return;
  }

  status_el.textContent = STATUS_BAR_STATE.connected ? "Connected" : "Not connected";
  status_el.classList.toggle("status-conn-on", STATUS_BAR_STATE.connected);
}

function UpdateStatusBarFileInfo() {
  const status_el = document.getElementById("status-file-type");
  if (!status_el) {
    return;
  }

  const active_tab = GetActiveTab();
  const name = active_tab ? active_tab.name : "";
  let file_type = "Text";

  if (name) {
    const dot = name.lastIndexOf(".");
    const ext = dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";

    if (ext === "lua") {
      file_type = "Lua";
    } else if (ext) {
      file_type = ext.toUpperCase();
    }
  }

  if (status_el.textContent !== file_type) {
    status_el.textContent = file_type;
  }
}