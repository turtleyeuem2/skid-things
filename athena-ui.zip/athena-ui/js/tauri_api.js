(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/@tauri-apps/api/external/tslib/tslib.es6.js
  function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
  }
  var init_tslib_es6 = __esm({
    "node_modules/@tauri-apps/api/external/tslib/tslib.es6.js"() {
    }
  });

  // node_modules/@tauri-apps/api/core.js
  function transformCallback(callback, once2 = false) {
    return window.__TAURI_INTERNALS__.transformCallback(callback, once2);
  }
  async function invoke(cmd, args = {}, options) {
    return window.__TAURI_INTERNALS__.invoke(cmd, args, options);
  }
  var _Channel_instances, _Channel_onmessage, _Channel_nextMessageIndex, _Channel_pendingMessages, _Channel_messageEndIndex, _Channel_deliver, _Resource_rid, SERIALIZE_TO_IPC_FN, Channel, Resource;
  var init_core = __esm({
    "node_modules/@tauri-apps/api/core.js"() {
      init_tslib_es6();
      SERIALIZE_TO_IPC_FN = "__TAURI_TO_IPC_KEY__";
      Channel = class {
        constructor(onmessage) {
          _Channel_instances.add(this);
          _Channel_onmessage.set(this, void 0);
          _Channel_nextMessageIndex.set(this, 0);
          _Channel_pendingMessages.set(this, []);
          _Channel_messageEndIndex.set(this, void 0);
          __classPrivateFieldSet(this, _Channel_onmessage, onmessage || (() => {
          }), "f");
          this.id = transformCallback((rawMessage) => {
            const index = rawMessage.index;
            if ("end" in rawMessage) {
              if (index == __classPrivateFieldGet(this, _Channel_nextMessageIndex, "f")) {
                this.cleanupCallback();
              } else {
                __classPrivateFieldSet(this, _Channel_messageEndIndex, index, "f");
              }
              return;
            }
            const message = rawMessage.message;
            if (index == __classPrivateFieldGet(this, _Channel_nextMessageIndex, "f")) {
              __classPrivateFieldGet(this, _Channel_instances, "m", _Channel_deliver).call(this, message);
              __classPrivateFieldSet(this, _Channel_nextMessageIndex, __classPrivateFieldGet(this, _Channel_nextMessageIndex, "f") + 1, "f");
              while (__classPrivateFieldGet(this, _Channel_nextMessageIndex, "f") in __classPrivateFieldGet(this, _Channel_pendingMessages, "f")) {
                const message2 = __classPrivateFieldGet(this, _Channel_pendingMessages, "f")[__classPrivateFieldGet(this, _Channel_nextMessageIndex, "f")];
                __classPrivateFieldGet(this, _Channel_instances, "m", _Channel_deliver).call(this, message2);
                delete __classPrivateFieldGet(this, _Channel_pendingMessages, "f")[__classPrivateFieldGet(this, _Channel_nextMessageIndex, "f")];
                __classPrivateFieldSet(this, _Channel_nextMessageIndex, __classPrivateFieldGet(this, _Channel_nextMessageIndex, "f") + 1, "f");
              }
              if (__classPrivateFieldGet(this, _Channel_nextMessageIndex, "f") === __classPrivateFieldGet(this, _Channel_messageEndIndex, "f")) {
                this.cleanupCallback();
              }
            } else {
              __classPrivateFieldGet(this, _Channel_pendingMessages, "f")[index] = message;
            }
          });
        }
        cleanupCallback() {
          window.__TAURI_INTERNALS__.unregisterCallback(this.id);
        }
        /**
         * The handler called for every message sent by the Rust side of this channel.
         *
         * Assigning a new handler replaces the previous one; messages that arrived
         * before a handler was set are not replayed, so set it (or pass it to the
         * constructor) before sending the channel to the backend.
         */
        set onmessage(handler) {
          __classPrivateFieldSet(this, _Channel_onmessage, handler, "f");
        }
        get onmessage() {
          return __classPrivateFieldGet(this, _Channel_onmessage, "f");
        }
        [(_Channel_onmessage = /* @__PURE__ */ new WeakMap(), _Channel_nextMessageIndex = /* @__PURE__ */ new WeakMap(), _Channel_pendingMessages = /* @__PURE__ */ new WeakMap(), _Channel_messageEndIndex = /* @__PURE__ */ new WeakMap(), _Channel_instances = /* @__PURE__ */ new WeakSet(), _Channel_deliver = function _Channel_deliver2(message) {
          try {
            __classPrivateFieldGet(this, _Channel_onmessage, "f").call(this, message);
          } catch (error) {
            queueMicrotask(() => {
              throw error;
            });
          }
        }, SERIALIZE_TO_IPC_FN)]() {
          return `__CHANNEL__:${this.id}`;
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      Resource = class {
        get rid() {
          return __classPrivateFieldGet(this, _Resource_rid, "f");
        }
        constructor(rid) {
          _Resource_rid.set(this, void 0);
          __classPrivateFieldSet(this, _Resource_rid, rid, "f");
        }
        /**
         * Destroys and cleans up this resource from memory.
         * **You should not call any method on this object anymore and should drop any reference to it.**
         *
         * @remarks Uses the `core:resources:allow-close` permission, which is part of
         * the `core:resources:default` permission set enabled by default.
         */
        async close() {
          return invoke("plugin:resources|close", {
            rid: this.rid
          });
        }
        async [(_Resource_rid = /* @__PURE__ */ new WeakMap(), Symbol.asyncDispose)]() {
          await this.close();
        }
      };
    }
  });

  // node_modules/@tauri-apps/api/path.js
  var path_exports = {};
  __export(path_exports, {
    BaseDirectory: () => BaseDirectory,
    appCacheDir: () => appCacheDir,
    appConfigDir: () => appConfigDir,
    appDataDir: () => appDataDir,
    appLocalDataDir: () => appLocalDataDir,
    appLogDir: () => appLogDir,
    audioDir: () => audioDir,
    basename: () => basename,
    cacheDir: () => cacheDir,
    configDir: () => configDir,
    dataDir: () => dataDir,
    delimiter: () => delimiter,
    desktopDir: () => desktopDir,
    dirname: () => dirname,
    documentDir: () => documentDir,
    downloadDir: () => downloadDir,
    executableDir: () => executableDir,
    extname: () => extname,
    fontDir: () => fontDir,
    homeDir: () => homeDir,
    isAbsolute: () => isAbsolute,
    join: () => join,
    localDataDir: () => localDataDir,
    normalize: () => normalize,
    pictureDir: () => pictureDir,
    publicDir: () => publicDir,
    resolve: () => resolve,
    resolveResource: () => resolveResource,
    resourceDir: () => resourceDir,
    runtimeDir: () => runtimeDir,
    sep: () => sep,
    tempDir: () => tempDir,
    templateDir: () => templateDir,
    videoDir: () => videoDir
  });
  async function appConfigDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.AppConfig
    });
  }
  async function appDataDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.AppData
    });
  }
  async function appLocalDataDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.AppLocalData
    });
  }
  async function appCacheDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.AppCache
    });
  }
  async function audioDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Audio
    });
  }
  async function cacheDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Cache
    });
  }
  async function configDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Config
    });
  }
  async function dataDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Data
    });
  }
  async function desktopDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Desktop
    });
  }
  async function documentDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Document
    });
  }
  async function downloadDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Download
    });
  }
  async function executableDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Executable
    });
  }
  async function fontDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Font
    });
  }
  async function homeDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Home
    });
  }
  async function localDataDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.LocalData
    });
  }
  async function pictureDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Picture
    });
  }
  async function publicDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Public
    });
  }
  async function resourceDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Resource
    });
  }
  async function resolveResource(resourcePath) {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Resource,
      path: resourcePath
    });
  }
  async function runtimeDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Runtime
    });
  }
  async function templateDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Template
    });
  }
  async function videoDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Video
    });
  }
  async function appLogDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.AppLog
    });
  }
  async function tempDir() {
    return invoke("plugin:path|resolve_directory", {
      directory: BaseDirectory.Temp
    });
  }
  function sep() {
    return window.__TAURI_INTERNALS__.plugins.path.sep;
  }
  function delimiter() {
    return window.__TAURI_INTERNALS__.plugins.path.delimiter;
  }
  async function resolve(...paths) {
    return invoke("plugin:path|resolve", { paths });
  }
  async function normalize(path) {
    return invoke("plugin:path|normalize", { path });
  }
  async function join(...paths) {
    return invoke("plugin:path|join", { paths });
  }
  async function dirname(path) {
    return invoke("plugin:path|dirname", { path });
  }
  async function extname(path) {
    return invoke("plugin:path|extname", { path });
  }
  async function basename(path, ext) {
    return invoke("plugin:path|basename", { path, ext });
  }
  async function isAbsolute(path) {
    return invoke("plugin:path|is_absolute", { path });
  }
  var BaseDirectory;
  var init_path = __esm({
    "node_modules/@tauri-apps/api/path.js"() {
      init_core();
      (function(BaseDirectory2) {
        BaseDirectory2[BaseDirectory2["Audio"] = 1] = "Audio";
        BaseDirectory2[BaseDirectory2["Cache"] = 2] = "Cache";
        BaseDirectory2[BaseDirectory2["Config"] = 3] = "Config";
        BaseDirectory2[BaseDirectory2["Data"] = 4] = "Data";
        BaseDirectory2[BaseDirectory2["LocalData"] = 5] = "LocalData";
        BaseDirectory2[BaseDirectory2["Document"] = 6] = "Document";
        BaseDirectory2[BaseDirectory2["Download"] = 7] = "Download";
        BaseDirectory2[BaseDirectory2["Picture"] = 8] = "Picture";
        BaseDirectory2[BaseDirectory2["Public"] = 9] = "Public";
        BaseDirectory2[BaseDirectory2["Video"] = 10] = "Video";
        BaseDirectory2[BaseDirectory2["Resource"] = 11] = "Resource";
        BaseDirectory2[BaseDirectory2["Temp"] = 12] = "Temp";
        BaseDirectory2[BaseDirectory2["AppConfig"] = 13] = "AppConfig";
        BaseDirectory2[BaseDirectory2["AppData"] = 14] = "AppData";
        BaseDirectory2[BaseDirectory2["AppLocalData"] = 15] = "AppLocalData";
        BaseDirectory2[BaseDirectory2["AppCache"] = 16] = "AppCache";
        BaseDirectory2[BaseDirectory2["AppLog"] = 17] = "AppLog";
        BaseDirectory2[BaseDirectory2["Desktop"] = 18] = "Desktop";
        BaseDirectory2[BaseDirectory2["Executable"] = 19] = "Executable";
        BaseDirectory2[BaseDirectory2["Font"] = 20] = "Font";
        BaseDirectory2[BaseDirectory2["Home"] = 21] = "Home";
        BaseDirectory2[BaseDirectory2["Runtime"] = 22] = "Runtime";
        BaseDirectory2[BaseDirectory2["Template"] = 23] = "Template";
      })(BaseDirectory || (BaseDirectory = {}));
    }
  });

  // node_modules/@tauri-apps/api/dpi.js
  var LogicalSize, PhysicalSize, Size, LogicalPosition, PhysicalPosition, Position;
  var init_dpi = __esm({
    "node_modules/@tauri-apps/api/dpi.js"() {
      init_core();
      LogicalSize = class {
        constructor(...args) {
          this.type = "Logical";
          if (args.length === 1) {
            if ("Logical" in args[0]) {
              this.width = args[0].Logical.width;
              this.height = args[0].Logical.height;
            } else {
              this.width = args[0].width;
              this.height = args[0].height;
            }
          } else {
            this.width = args[0];
            this.height = args[1];
          }
        }
        /**
         * Converts the logical size to a physical one.
         * @example
         * ```typescript
         * import { LogicalSize } from '@tauri-apps/api/dpi';
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         *
         * const appWindow = getCurrentWindow();
         * const factor = await appWindow.scaleFactor();
         * const size = new LogicalSize(400, 500);
         * const physical = size.toPhysical(factor);
         * ```
         *
         * @since 2.0.0
         */
        toPhysical(scaleFactor) {
          return new PhysicalSize(this.width * scaleFactor, this.height * scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            width: this.width,
            height: this.height
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      PhysicalSize = class {
        constructor(...args) {
          this.type = "Physical";
          if (args.length === 1) {
            if ("Physical" in args[0]) {
              this.width = args[0].Physical.width;
              this.height = args[0].Physical.height;
            } else {
              this.width = args[0].width;
              this.height = args[0].height;
            }
          } else {
            this.width = args[0];
            this.height = args[1];
          }
        }
        /**
         * Converts the physical size to a logical one.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const appWindow = getCurrentWindow();
         * const factor = await appWindow.scaleFactor();
         * const size = await appWindow.innerSize(); // PhysicalSize
         * const logical = size.toLogical(factor);
         * ```
         *
         * @since 2.0.0
         */
        toLogical(scaleFactor) {
          return new LogicalSize(this.width / scaleFactor, this.height / scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            width: this.width,
            height: this.height
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      Size = class {
        constructor(size) {
          this.size = size;
        }
        /**
         * Converts the wrapped size to a logical one.
         *
         * Returns the inner value untouched when it already is a {@linkcode LogicalSize}.
         *
         * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
         *
         * @since 2.1.0
         */
        toLogical(scaleFactor) {
          return this.size instanceof LogicalSize ? this.size : this.size.toLogical(scaleFactor);
        }
        /**
         * Converts the wrapped size to a physical one.
         *
         * Returns the inner value untouched when it already is a {@linkcode PhysicalSize}.
         *
         * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
         *
         * @since 2.1.0
         */
        toPhysical(scaleFactor) {
          return this.size instanceof PhysicalSize ? this.size : this.size.toPhysical(scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            [`${this.size.type}`]: {
              width: this.size.width,
              height: this.size.height
            }
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      LogicalPosition = class {
        constructor(...args) {
          this.type = "Logical";
          if (args.length === 1) {
            if ("Logical" in args[0]) {
              this.x = args[0].Logical.x;
              this.y = args[0].Logical.y;
            } else {
              this.x = args[0].x;
              this.y = args[0].y;
            }
          } else {
            this.x = args[0];
            this.y = args[1];
          }
        }
        /**
         * Converts the logical position to a physical one.
         * @example
         * ```typescript
         * import { LogicalPosition } from '@tauri-apps/api/dpi';
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         *
         * const appWindow = getCurrentWindow();
         * const factor = await appWindow.scaleFactor();
         * const position = new LogicalPosition(400, 500);
         * const physical = position.toPhysical(factor);
         * ```
         *
         * @since 2.0.0
         */
        toPhysical(scaleFactor) {
          return new PhysicalPosition(this.x * scaleFactor, this.y * scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            x: this.x,
            y: this.y
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      PhysicalPosition = class {
        constructor(...args) {
          this.type = "Physical";
          if (args.length === 1) {
            if ("Physical" in args[0]) {
              this.x = args[0].Physical.x;
              this.y = args[0].Physical.y;
            } else {
              this.x = args[0].x;
              this.y = args[0].y;
            }
          } else {
            this.x = args[0];
            this.y = args[1];
          }
        }
        /**
         * Converts the physical position to a logical one.
         * @example
         * ```typescript
         * import { PhysicalPosition } from '@tauri-apps/api/dpi';
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         *
         * const appWindow = getCurrentWindow();
         * const factor = await appWindow.scaleFactor();
         * const position = new PhysicalPosition(400, 500);
         * const logical = position.toLogical(factor);
         * ```
         *
         * @since 2.0.0
         */
        toLogical(scaleFactor) {
          return new LogicalPosition(this.x / scaleFactor, this.y / scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            x: this.x,
            y: this.y
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
      Position = class {
        constructor(position) {
          this.position = position;
        }
        /**
         * Converts the wrapped position to a logical one.
         *
         * Returns the inner value untouched when it already is a {@linkcode LogicalPosition}.
         *
         * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
         *
         * @since 2.1.0
         */
        toLogical(scaleFactor) {
          return this.position instanceof LogicalPosition ? this.position : this.position.toLogical(scaleFactor);
        }
        /**
         * Converts the wrapped position to a physical one.
         *
         * Returns the inner value untouched when it already is a {@linkcode PhysicalPosition}.
         *
         * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
         *
         * @since 2.1.0
         */
        toPhysical(scaleFactor) {
          return this.position instanceof PhysicalPosition ? this.position : this.position.toPhysical(scaleFactor);
        }
        [SERIALIZE_TO_IPC_FN]() {
          return {
            [`${this.position.type}`]: {
              x: this.position.x,
              y: this.position.y
            }
          };
        }
        toJSON() {
          return this[SERIALIZE_TO_IPC_FN]();
        }
      };
    }
  });

  // node_modules/@tauri-apps/api/event.js
  async function _unlisten(event, eventId) {
    window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(event, eventId);
    await invoke("plugin:event|unlisten", {
      event,
      eventId
    });
  }
  async function listen(event, handler, options) {
    var _a;
    const target = typeof (options === null || options === void 0 ? void 0 : options.target) === "string" ? { kind: "AnyLabel", label: options.target } : (_a = options === null || options === void 0 ? void 0 : options.target) !== null && _a !== void 0 ? _a : { kind: "Any" };
    return invoke("plugin:event|listen", {
      event,
      target,
      handler: transformCallback(handler)
    }).then((eventId) => {
      return async () => _unlisten(event, eventId);
    });
  }
  async function once(event, handler, options) {
    return listen(event, (eventData) => {
      void _unlisten(event, eventData.id);
      handler(eventData);
    }, options);
  }
  async function emit(event, payload) {
    await invoke("plugin:event|emit", {
      event,
      payload
    });
  }
  async function emitTo(target, event, payload) {
    const eventTarget = typeof target === "string" ? { kind: "AnyLabel", label: target } : target;
    await invoke("plugin:event|emit_to", {
      target: eventTarget,
      event,
      payload
    });
  }
  var TauriEvent;
  var init_event = __esm({
    "node_modules/@tauri-apps/api/event.js"() {
      init_core();
      (function(TauriEvent2) {
        TauriEvent2["WINDOW_RESIZED"] = "tauri://resize";
        TauriEvent2["WINDOW_MOVED"] = "tauri://move";
        TauriEvent2["WINDOW_CLOSE_REQUESTED"] = "tauri://close-requested";
        TauriEvent2["WINDOW_DESTROYED"] = "tauri://destroyed";
        TauriEvent2["WINDOW_FOCUS"] = "tauri://focus";
        TauriEvent2["WINDOW_BLUR"] = "tauri://blur";
        TauriEvent2["WINDOW_SCALE_FACTOR_CHANGED"] = "tauri://scale-change";
        TauriEvent2["WINDOW_THEME_CHANGED"] = "tauri://theme-changed";
        TauriEvent2["WINDOW_CREATED"] = "tauri://window-created";
        TauriEvent2["WINDOW_SUSPENDED"] = "tauri://suspended";
        TauriEvent2["WINDOW_RESUMED"] = "tauri://resumed";
        TauriEvent2["WEBVIEW_CREATED"] = "tauri://webview-created";
        TauriEvent2["DRAG_ENTER"] = "tauri://drag-enter";
        TauriEvent2["DRAG_OVER"] = "tauri://drag-over";
        TauriEvent2["DRAG_DROP"] = "tauri://drag-drop";
        TauriEvent2["DRAG_LEAVE"] = "tauri://drag-leave";
      })(TauriEvent || (TauriEvent = {}));
    }
  });

  // node_modules/@tauri-apps/api/image.js
  function transformImage(image) {
    const ret = image == null ? null : typeof image === "string" ? image : image instanceof Image ? image.rid : image;
    return ret;
  }
  var Image;
  var init_image = __esm({
    "node_modules/@tauri-apps/api/image.js"() {
      init_core();
      Image = class _Image extends Resource {
        /**
         * Creates an Image from a resource ID. For internal use only.
         *
         * @ignore
         */
        constructor(rid) {
          super(rid);
        }
        /**
         * Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height.
         *
         * The buffer must contain exactly `width * height * 4` bytes.
         * Unlike {@linkcode Image.fromBytes} and {@linkcode Image.fromPath} this does not
         * decode an image format, so it requires no extra Cargo feature.
         *
         * @example
         * ```typescript
         * import { Image } from '@tauri-apps/api/image';
         *
         * // a 1x1 opaque red image
         * const image = await Image.new(new Uint8Array([255, 0, 0, 255]), 1, 1);
         * ```
         *
         * @since 2.0.0
         */
        static async new(rgba, width, height) {
          return invoke("plugin:image|new", {
            rgba,
            width,
            height
          }).then((rid) => new _Image(rid));
        }
        /**
         * Creates a new image using the provided bytes by inferring the file format.
         *
         * Only `ico` and `png` are supported (based on activated feature flag).
         *
         * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
         * To enable it, change your Cargo.toml file:
         * ```toml
         * [dependencies]
         * tauri = { version = "...", features = ["...", "image-png"] }
         * ```
         *
         * @example
         * ```typescript
         * import { Image } from '@tauri-apps/api/image';
         *
         * const bytes = await fetch('/icon.png').then((r) => r.arrayBuffer());
         * const image = await Image.fromBytes(bytes);
         * ```
         *
         * @since 2.0.0
         */
        static async fromBytes(bytes) {
          return invoke("plugin:image|from_bytes", {
            bytes
          }).then((rid) => new _Image(rid));
        }
        /**
         * Creates a new image using the provided path.
         *
         * Only `ico` and `png` are supported (based on activated feature flag).
         *
         * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
         * To enable it, change your Cargo.toml file:
         * ```toml
         * [dependencies]
         * tauri = { version = "...", features = ["...", "image-png"] }
         * ```
         *
         * The path is resolved on the Rust side, so it must be a path on the user's
         * machine (for example one returned by the path APIs or a bundled resource
         * resolved with `resolveResource`), not a frontend asset URL.
         *
         * @example
         * ```typescript
         * import { Image } from '@tauri-apps/api/image';
         * import { resolveResource } from '@tauri-apps/api/path';
         *
         * const image = await Image.fromPath(await resolveResource('icons/icon.png'));
         * ```
         *
         * @since 2.0.0
         */
        static async fromPath(path) {
          return invoke("plugin:image|from_path", { path }).then((rid) => new _Image(rid));
        }
        /**
         * Returns the RGBA data for this image, in row-major order from top to bottom.
         *
         * The returned buffer has `width * height * 4` bytes, see {@linkcode Image.size}.
         *
         * @example
         * ```typescript
         * import { Image } from '@tauri-apps/api/image';
         *
         * const image = await Image.fromPath('icons/icon.png');
         * const rgba = await image.rgba();
         * ```
         *
         * @since 2.0.0
         */
        async rgba() {
          return invoke("plugin:image|rgba", {
            rid: this.rid
          }).then((buffer) => new Uint8Array(buffer));
        }
        /**
         * Returns the size of this image, in pixels.
         *
         * @example
         * ```typescript
         * import { Image } from '@tauri-apps/api/image';
         *
         * const image = await Image.fromPath('icons/icon.png');
         * const { width, height } = await image.size();
         * ```
         *
         * @since 2.0.0
         */
        async size() {
          return invoke("plugin:image|size", { rid: this.rid });
        }
      };
    }
  });

  // node_modules/@tauri-apps/api/window.js
  function getCurrentWindow() {
    return new Window(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
      // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
      skip: true
    });
  }
  async function getAllWindows() {
    return invoke("plugin:window|get_all_windows").then((windows) => windows.map((w) => new Window(w, {
      // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
      skip: true
    })));
  }
  var UserAttentionType, CloseRequestedEvent, ProgressBarStatus, localTauriEvents, Window, BackgroundThrottlingPolicy, ScrollBarStyle, Effect, EffectState;
  var init_window = __esm({
    "node_modules/@tauri-apps/api/window.js"() {
      init_dpi();
      init_dpi();
      init_event();
      init_core();
      init_image();
      (function(UserAttentionType2) {
        UserAttentionType2[UserAttentionType2["Critical"] = 1] = "Critical";
        UserAttentionType2[UserAttentionType2["Informational"] = 2] = "Informational";
      })(UserAttentionType || (UserAttentionType = {}));
      CloseRequestedEvent = class {
        constructor(event) {
          this._preventDefault = false;
          this.event = event.event;
          this.id = event.id;
        }
        /**
         * Prevents the window from being closed.
         *
         * Must be called before the handler returns (await anything you need first),
         * otherwise the window is destroyed as usual.
         */
        preventDefault() {
          this._preventDefault = true;
        }
        /** Whether {@link CloseRequestedEvent.preventDefault} was called on this event. */
        isPreventDefault() {
          return this._preventDefault;
        }
      };
      (function(ProgressBarStatus2) {
        ProgressBarStatus2["None"] = "none";
        ProgressBarStatus2["Normal"] = "normal";
        ProgressBarStatus2["Indeterminate"] = "indeterminate";
        ProgressBarStatus2["Paused"] = "paused";
        ProgressBarStatus2["Error"] = "error";
      })(ProgressBarStatus || (ProgressBarStatus = {}));
      localTauriEvents = ["tauri://created", "tauri://error"];
      Window = class {
        /**
         * Creates a new Window.
         * @example
         * ```typescript
         * import { Window } from '@tauri-apps/api/window';
         * const appWindow = new Window('my-label');
         * appWindow.once('tauri://created', function () {
         *  // window successfully created
         * });
         * appWindow.once('tauri://error', function (e) {
         *  // an error happened creating the window
         * });
         * ```
         *
         * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
         * @param options The window configuration, see {@link WindowOptions}.
         * @returns The {@link Window} instance to communicate with the window.
         *
         * @remarks Requires the `core:window:allow-create` permission (not included in
         * `core:window:default`).
         */
        constructor(label, options = {}) {
          var _a;
          this.label = label;
          this.listeners = /* @__PURE__ */ Object.create(null);
          if (!(options === null || options === void 0 ? void 0 : options.skip)) {
            invoke("plugin:window|create", {
              options: {
                ...options,
                parent: typeof options.parent === "string" ? options.parent : (_a = options.parent) === null || _a === void 0 ? void 0 : _a.label,
                label
              }
            }).then(async () => this.emit("tauri://created")).catch(async (e) => this.emit("tauri://error", e));
          }
        }
        /**
         * Gets the Window associated with the given label.
         * @example
         * ```typescript
         * import { Window } from '@tauri-apps/api/window';
         * const mainWindow = Window.getByLabel('main');
         * ```
         *
         * @param label The window label.
         * @returns The Window instance to communicate with the window or null if the window doesn't exist.
         */
        static async getByLabel(label) {
          var _a;
          return (_a = (await getAllWindows()).find((w) => w.label === label)) !== null && _a !== void 0 ? _a : null;
        }
        /**
         * Get an instance of `Window` for the current window.
         */
        static getCurrent() {
          return getCurrentWindow();
        }
        /**
         * Gets a list of instances of `Window` for all available windows.
         */
        static async getAll() {
          return getAllWindows();
        }
        /**
         *  Gets the focused window.
         * @example
         * ```typescript
         * import { Window } from '@tauri-apps/api/window';
         * const focusedWindow = Window.getFocusedWindow();
         * ```
         *
         * @returns The Window instance or `undefined` if there is not any focused window.
         */
        static async getFocusedWindow() {
          for (const w of await getAllWindows()) {
            if (await w.isFocused()) {
              return w;
            }
          }
          return null;
        }
        /**
         * Listen to an emitted event on this window.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
         *   console.log(`Got error: ${payload}`);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
         * @param handler Event handler.
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async listen(event, handler) {
          if (this._handleTauriEvent(event, handler)) {
            return () => {
              const listeners = this.listeners[event];
              listeners.splice(listeners.indexOf(handler), 1);
            };
          }
          return listen(event, handler, {
            target: { kind: "Window", label: this.label }
          });
        }
        /**
         * Listen to an emitted event on this window only once.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
         *   console.log(`Window initialized!`);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
         * @param handler Event handler.
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener removes itself after the first event and is also removed
         * automatically when this window is destroyed. Do call the returned function if
         * the listener's own scope ends before the event arrives.
         */
        async once(event, handler) {
          if (this._handleTauriEvent(event, handler)) {
            return () => {
              const listeners = this.listeners[event];
              listeners.splice(listeners.indexOf(handler), 1);
            };
          }
          return once(event, handler, {
            target: { kind: "Window", label: this.label }
          });
        }
        /**
         * Emits an event to all {@link EventTarget|targets}.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
         * ```
         *
         * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
         * @param payload Event payload.
         */
        async emit(event, payload) {
          if (localTauriEvents.includes(event)) {
            for (const handler of this.listeners[event] || []) {
              handler({
                event,
                id: -1,
                payload
              });
            }
            return;
          }
          return emit(event, payload);
        }
        /**
         * Emits an event to all {@link EventTarget|targets} matching the given target.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().emitTo('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
         * ```
         * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
         * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
         * @param payload Event payload.
         */
        async emitTo(target, event, payload) {
          if (localTauriEvents.includes(event)) {
            for (const handler of this.listeners[event] || []) {
              handler({
                event,
                id: -1,
                payload
              });
            }
            return;
          }
          return emitTo(target, event, payload);
        }
        /** @ignore */
        _handleTauriEvent(event, handler) {
          if (localTauriEvents.includes(event)) {
            if (!(event in this.listeners)) {
              this.listeners[event] = [handler];
            } else {
              this.listeners[event].push(handler);
            }
            return true;
          }
          return false;
        }
        // Getters
        /**
         * The scale factor that can be used to map physical pixels to logical pixels.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const factor = await getCurrentWindow().scaleFactor();
         * ```
         *
         * @returns The window's monitor scale factor.
         */
        async scaleFactor() {
          return invoke("plugin:window|scale_factor", {
            label: this.label
          });
        }
        /**
         * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const position = await getCurrentWindow().innerPosition();
         * ```
         *
         * @returns The window's inner position.
         */
        async innerPosition() {
          return invoke("plugin:window|inner_position", {
            label: this.label
          }).then((p) => new PhysicalPosition(p));
        }
        /**
         * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const position = await getCurrentWindow().outerPosition();
         * ```
         *
         * @returns The window's outer position.
         */
        async outerPosition() {
          return invoke("plugin:window|outer_position", {
            label: this.label
          }).then((p) => new PhysicalPosition(p));
        }
        /**
         * The physical size of the window's client area.
         * The client area is the content of the window, excluding the title bar and borders.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const size = await getCurrentWindow().innerSize();
         * ```
         *
         * @returns The window's inner size.
         */
        async innerSize() {
          return invoke("plugin:window|inner_size", {
            label: this.label
          }).then((s) => new PhysicalSize(s));
        }
        /**
         * The physical size of the entire window.
         * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const size = await getCurrentWindow().outerSize();
         * ```
         *
         * @returns The window's outer size.
         */
        async outerSize() {
          return invoke("plugin:window|outer_size", {
            label: this.label
          }).then((s) => new PhysicalSize(s));
        }
        /**
         * Gets the window's current fullscreen state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const fullscreen = await getCurrentWindow().isFullscreen();
         * ```
         *
         * @returns Whether the window is in fullscreen mode or not.
         */
        async isFullscreen() {
          return invoke("plugin:window|is_fullscreen", {
            label: this.label
          });
        }
        /**
         * Gets the window's current minimized state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const minimized = await getCurrentWindow().isMinimized();
         * ```
         */
        async isMinimized() {
          return invoke("plugin:window|is_minimized", {
            label: this.label
          });
        }
        /**
         * Gets the window's current maximized state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const maximized = await getCurrentWindow().isMaximized();
         * ```
         *
         * @returns Whether the window is maximized or not.
         */
        async isMaximized() {
          return invoke("plugin:window|is_maximized", {
            label: this.label
          });
        }
        /**
         * Gets the window's current focus state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const focused = await getCurrentWindow().isFocused();
         * ```
         *
         * @returns Whether the window is focused or not.
         */
        async isFocused() {
          return invoke("plugin:window|is_focused", {
            label: this.label
          });
        }
        /**
         * Gets the window's current decorated state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const decorated = await getCurrentWindow().isDecorated();
         * ```
         *
         * @returns Whether the window is decorated or not.
         */
        async isDecorated() {
          return invoke("plugin:window|is_decorated", {
            label: this.label
          });
        }
        /**
         * Gets the window's current resizable state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const resizable = await getCurrentWindow().isResizable();
         * ```
         *
         * @returns Whether the window is resizable or not.
         */
        async isResizable() {
          return invoke("plugin:window|is_resizable", {
            label: this.label
          });
        }
        /**
         * Gets the window's native maximize button state.
         *
         * #### Platform-specific
         *
         * - **Linux / iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const maximizable = await getCurrentWindow().isMaximizable();
         * ```
         *
         * @returns Whether the window's native maximize button is enabled or not.
         */
        async isMaximizable() {
          return invoke("plugin:window|is_maximizable", {
            label: this.label
          });
        }
        /**
         * Gets the window's native minimize button state.
         *
         * #### Platform-specific
         *
         * - **Linux / iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const minimizable = await getCurrentWindow().isMinimizable();
         * ```
         *
         * @returns Whether the window's native minimize button is enabled or not.
         */
        async isMinimizable() {
          return invoke("plugin:window|is_minimizable", {
            label: this.label
          });
        }
        /**
         * Gets the window's native close button state.
         *
         * #### Platform-specific
         *
         * - **iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const closable = await getCurrentWindow().isClosable();
         * ```
         *
         * @returns Whether the window's native close button is enabled or not.
         */
        async isClosable() {
          return invoke("plugin:window|is_closable", {
            label: this.label
          });
        }
        /**
         * Gets the window's current visible state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const visible = await getCurrentWindow().isVisible();
         * ```
         *
         * @returns Whether the window is visible or not.
         */
        async isVisible() {
          return invoke("plugin:window|is_visible", {
            label: this.label
          });
        }
        /**
         * Gets the window's current title.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const title = await getCurrentWindow().title();
         * ```
         */
        async title() {
          return invoke("plugin:window|title", {
            label: this.label
          });
        }
        /**
         * Gets the window's current theme.
         *
         * #### Platform-specific
         *
         * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const theme = await getCurrentWindow().theme();
         * ```
         *
         * @returns The window theme.
         */
        async theme() {
          return invoke("plugin:window|theme", {
            label: this.label
          });
        }
        /**
         * Whether the window is configured to be always on top of other windows or not.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
         * ```
         *
         * @returns Whether the window is visible or not.
         */
        async isAlwaysOnTop() {
          return invoke("plugin:window|is_always_on_top", {
            label: this.label
          });
        }
        /**
         * The name of the Android activity hosting this window.
         *
         * On Android each window is backed by its own activity. Use this to tell windows
         * apart from native code, or to match a window with the activity declared in your
         * `AndroidManifest.xml`.
         *
         * #### Platform-specific
         *
         * - **Android:** Supported.
         * - **Windows / Linux / macOS / iOS:** Unsupported, the call rejects because the
         *   command is not registered.
         *
         * See the [mobile multiwindow guide](https://tauri.app/learn/mobile-multiwindow/).
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const activity = await getCurrentWindow().activityName();
         * ```
         *
         * @returns The activity name.
         *
         * @remarks Uses the `core:window:allow-activity-name` permission, which is part
         * of `core:window:default`.
         *
         * @since 2.11.0
         */
        async activityName() {
          return invoke("plugin:window|activity_name", {
            label: this.label
          });
        }
        /**
         * The identifier of the iOS scene hosting this window.
         *
         * On iOS each window is backed by a `UIScene`. Use this to tell windows apart
         * from native code, or to match a window with a scene configuration declared in
         * your `Info.plist`.
         *
         * #### Platform-specific
         *
         * - **iOS:** Supported.
         * - **Windows / Linux / macOS / Android:** Unsupported, the call rejects because
         *   the command is not registered.
         *
         * See the [mobile multiwindow guide](https://tauri.app/learn/mobile-multiwindow/).
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const scene = await getCurrentWindow().sceneIdentifier();
         * ```
         *
         * @returns The scene identifier.
         *
         * @remarks Uses the `core:window:allow-scene-identifier` permission, which is part
         * of `core:window:default`.
         *
         * @since 2.11.0
         */
        async sceneIdentifier() {
          return invoke("plugin:window|scene_identifier", {
            label: this.label
          });
        }
        // Setters
        /**
         * Centers the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().center();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-center` permission (not included
         * in `core:window:default`).
         */
        async center() {
          return invoke("plugin:window|center", {
            label: this.label
          });
        }
        /**
         *  Requests user attention to the window, this has no effect if the application
         * is already focused. How requesting for user attention manifests is platform dependent,
         * see `UserAttentionType` for details.
         *
         * Providing `null` will unset the request for user attention. Unsetting the request for
         * user attention might not be done automatically by the WM when the window receives input.
         *
         * #### Platform-specific
         *
         * - **macOS:** `null` has no effect.
         * - **Linux:** Urgency levels have the same effect.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().requestUserAttention();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-request-user-attention` permission (not included
         * in `core:window:default`).
         */
        async requestUserAttention(requestType) {
          let requestType_ = null;
          if (requestType) {
            if (requestType === UserAttentionType.Critical) {
              requestType_ = { type: "Critical" };
            } else {
              requestType_ = { type: "Informational" };
            }
          }
          return invoke("plugin:window|request_user_attention", {
            label: this.label,
            value: requestType_
          });
        }
        /**
         * Updates the window resizable flag.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setResizable(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-resizable` permission (not included
         * in `core:window:default`).
         */
        async setResizable(resizable) {
          return invoke("plugin:window|set_resizable", {
            label: this.label,
            value: resizable
          });
        }
        /**
         * Enable or disable the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setEnabled(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-enabled` permission (not included
         * in `core:window:default`).
         *
         * @since 2.0.0
         */
        async setEnabled(enabled) {
          return invoke("plugin:window|set_enabled", {
            label: this.label,
            value: enabled
          });
        }
        /**
         * Whether the window is enabled or disabled.
         *
         * A disabled window ignores all user input; see {@link Window.setEnabled}.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * const enabled = await getCurrentWindow().isEnabled();
         * ```
         *
         * @returns `true` when the window accepts user input, `false` when it is disabled.
         *
         * @since 2.0.0
         */
        async isEnabled() {
          return invoke("plugin:window|is_enabled", {
            label: this.label
          });
        }
        /**
         * Sets whether the window's native maximize button is enabled or not.
         * If resizable is set to false, this setting is ignored.
         *
         * #### Platform-specific
         *
         * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
         * - **Linux / iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setMaximizable(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-maximizable` permission (not included
         * in `core:window:default`).
         */
        async setMaximizable(maximizable) {
          return invoke("plugin:window|set_maximizable", {
            label: this.label,
            value: maximizable
          });
        }
        /**
         * Sets whether the window's native minimize button is enabled or not.
         *
         * #### Platform-specific
         *
         * - **Linux / iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setMinimizable(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-minimizable` permission (not included
         * in `core:window:default`).
         */
        async setMinimizable(minimizable) {
          return invoke("plugin:window|set_minimizable", {
            label: this.label,
            value: minimizable
          });
        }
        /**
         * Sets whether the window's native close button is enabled or not.
         *
         * #### Platform-specific
         *
         * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
         * - **iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setClosable(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-closable` permission (not included
         * in `core:window:default`).
         */
        async setClosable(closable) {
          return invoke("plugin:window|set_closable", {
            label: this.label,
            value: closable
          });
        }
        /**
         * Sets the window title.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setTitle('Tauri');
         * ```
         *
         * @param title The new title
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-title` permission (not included
         * in `core:window:default`).
         */
        async setTitle(title) {
          return invoke("plugin:window|set_title", {
            label: this.label,
            value: title
          });
        }
        /**
         * Maximizes the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().maximize();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-maximize` permission (not included
         * in `core:window:default`).
         */
        async maximize() {
          return invoke("plugin:window|maximize", {
            label: this.label
          });
        }
        /**
         * Unmaximizes the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().unmaximize();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-unmaximize` permission (not included
         * in `core:window:default`).
         */
        async unmaximize() {
          return invoke("plugin:window|unmaximize", {
            label: this.label
          });
        }
        /**
         * Toggles the window maximized state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().toggleMaximize();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-toggle-maximize` permission (not included
         * in `core:window:default`).
         */
        async toggleMaximize() {
          return invoke("plugin:window|toggle_maximize", {
            label: this.label
          });
        }
        /**
         * Minimizes the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().minimize();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-minimize` permission (not included
         * in `core:window:default`).
         */
        async minimize() {
          return invoke("plugin:window|minimize", {
            label: this.label
          });
        }
        /**
         * Unminimizes the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().unminimize();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-unminimize` permission (not included
         * in `core:window:default`).
         */
        async unminimize() {
          return invoke("plugin:window|unminimize", {
            label: this.label
          });
        }
        /**
         * Sets the window visibility to true.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().show();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-show` permission (not included
         * in `core:window:default`).
         */
        async show() {
          return invoke("plugin:window|show", {
            label: this.label
          });
        }
        /**
         * Sets the window visibility to false.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().hide();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-hide` permission (not included
         * in `core:window:default`).
         */
        async hide() {
          return invoke("plugin:window|hide", {
            label: this.label
          });
        }
        /**
         * Closes the window.
         *
         * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().close();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-close` permission (not included
         * in `core:window:default`).
         */
        async close() {
          return invoke("plugin:window|close", {
            label: this.label
          });
        }
        /**
         * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().destroy();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-destroy` permission (not included
         * in `core:window:default`).
         */
        async destroy() {
          return invoke("plugin:window|destroy", {
            label: this.label
          });
        }
        /**
         * Whether the window should have borders and bars.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setDecorations(false);
         * ```
         *
         * @param decorations Whether the window should have borders and bars.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-decorations` permission (not included
         * in `core:window:default`).
         */
        async setDecorations(decorations) {
          return invoke("plugin:window|set_decorations", {
            label: this.label,
            value: decorations
          });
        }
        /**
         * Whether or not the window should have shadow.
         *
         * #### Platform-specific
         *
         * - **Windows:**
         *   - `false` has no effect on decorated window, shadows are always ON.
         *   - `true` will make undecorated window have a 1px white border,
         * and on Windows 11, it will have a rounded corners.
         * - **Linux:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setShadow(false);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-shadow` permission (not included
         * in `core:window:default`).
         */
        async setShadow(enable) {
          return invoke("plugin:window|set_shadow", {
            label: this.label,
            value: enable
          });
        }
        /**
         * Applies platform-specific window effects such as Mica, Acrylic, Blur or the
         * macOS vibrancy materials.
         *
         * Requires the window to be transparent, so create it with `transparent: true`
         * (or set `transparent` in `tauri.conf.json`). Give the page a transparent or
         * translucent background as well, otherwise the effect is hidden behind your own
         * background color.
         *
         * Conflicting effects are resolved by applying the first supported one and
         * ignoring the rest, so you can list a Windows and a macOS effect together.
         *
         * #### Platform-specific
         *
         * - **Windows:** If the window uses decorations or shadows, you may need
         *   [this workaround](https://github.com/tauri-apps/tao/issues/72#issuecomment-975607891).
         * - **Linux:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow, Effect, EffectState } from '@tauri-apps/api/window';
         *
         * await getCurrentWindow().setEffects({
         *   effects: [Effect.Mica, Effect.Acrylic, Effect.UnderWindowBackground],
         *   state: EffectState.Active,
         *   radius: 8
         * });
         * ```
         *
         * @param effects The effects to apply, see {@link Effects}.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-effects` permission (not included
         * in `core:window:default`).
         *
         * @since 2.0.0
         */
        async setEffects(effects) {
          return invoke("plugin:window|set_effects", {
            label: this.label,
            value: effects
          });
        }
        /**
         * Clear any applied effects if possible.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().clearEffects();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-effects` permission (not included
         * in `core:window:default`), the same one used by {@link Window.setEffects}.
         *
         * @since 2.0.0
         */
        async clearEffects() {
          return invoke("plugin:window|set_effects", {
            label: this.label,
            value: null
          });
        }
        /**
         * Whether the window should always be on top of other windows.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setAlwaysOnTop(true);
         * ```
         *
         * @param alwaysOnTop Whether the window should always be on top of other windows or not.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-always-on-top` permission (not included
         * in `core:window:default`).
         */
        async setAlwaysOnTop(alwaysOnTop) {
          return invoke("plugin:window|set_always_on_top", {
            label: this.label,
            value: alwaysOnTop
          });
        }
        /**
         * Whether the window should always be below other windows.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setAlwaysOnBottom(true);
         * ```
         *
         * @param alwaysOnBottom Whether the window should always be below other windows or not.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-always-on-bottom` permission (not included
         * in `core:window:default`).
         */
        async setAlwaysOnBottom(alwaysOnBottom) {
          return invoke("plugin:window|set_always_on_bottom", {
            label: this.label,
            value: alwaysOnBottom
          });
        }
        /**
         * Prevents the window contents from being captured by other apps.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setContentProtected(true);
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-content-protected` permission (not included
         * in `core:window:default`).
         */
        async setContentProtected(protected_) {
          return invoke("plugin:window|set_content_protected", {
            label: this.label,
            value: protected_
          });
        }
        /**
         * Resizes the window with a new inner size.
         * @example
         * ```typescript
         * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
         * await getCurrentWindow().setSize(new LogicalSize(600, 500));
         * ```
         *
         * @param size The logical or physical inner size.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-size` permission (not included
         * in `core:window:default`).
         */
        async setSize(size) {
          return invoke("plugin:window|set_size", {
            label: this.label,
            value: size instanceof Size ? size : new Size(size)
          });
        }
        /**
         * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
         * @example
         * ```typescript
         * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
         * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
         * ```
         *
         * @param size The logical or physical inner size, or `null` to unset the constraint.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-min-size` permission (not included
         * in `core:window:default`).
         */
        async setMinSize(size) {
          return invoke("plugin:window|set_min_size", {
            label: this.label,
            value: size instanceof Size ? size : size ? new Size(size) : null
          });
        }
        /**
         * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
         * @example
         * ```typescript
         * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
         * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
         * ```
         *
         * @param size The logical or physical inner size, or `null` to unset the constraint.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-max-size` permission (not included
         * in `core:window:default`).
         */
        async setMaxSize(size) {
          return invoke("plugin:window|set_max_size", {
            label: this.label,
            value: size instanceof Size ? size : size ? new Size(size) : null
          });
        }
        /**
         * Sets the window inner size constraints.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
         * ```
         *
         * @param constraints The inner size constraints in **logical pixels**, or `null`
         * to unset every constraint. Each field is optional and independent, so
         * `{ minWidth: 300 }` constrains only the width.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-size-constraints` permission (not included
         * in `core:window:default`).
         */
        async setSizeConstraints(constraints) {
          function logical(pixel) {
            return pixel ? { Logical: pixel } : null;
          }
          return invoke("plugin:window|set_size_constraints", {
            label: this.label,
            value: {
              minWidth: logical(constraints === null || constraints === void 0 ? void 0 : constraints.minWidth),
              minHeight: logical(constraints === null || constraints === void 0 ? void 0 : constraints.minHeight),
              maxWidth: logical(constraints === null || constraints === void 0 ? void 0 : constraints.maxWidth),
              maxHeight: logical(constraints === null || constraints === void 0 ? void 0 : constraints.maxHeight)
            }
          });
        }
        /**
         * Sets the window outer position.
         * @example
         * ```typescript
         * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
         * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
         * ```
         *
         * @param position The new position, in logical or physical pixels.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-position` permission (not included
         * in `core:window:default`).
         */
        async setPosition(position) {
          return invoke("plugin:window|set_position", {
            label: this.label,
            value: position instanceof Position ? position : new Position(position)
          });
        }
        /**
         * Sets the window fullscreen state.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setFullscreen(true);
         * ```
         *
         * @param fullscreen Whether the window should go to fullscreen or not.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-fullscreen` permission (not included
         * in `core:window:default`).
         */
        async setFullscreen(fullscreen) {
          return invoke("plugin:window|set_fullscreen", {
            label: this.label,
            value: fullscreen
          });
        }
        /**
         * Sets the window as fullscreen on the monitor that contains the given physical position.
         *
         * Does nothing if no monitor contains the position.
         * @example
         * ```typescript
         * import { getCurrentWindow, availableMonitors } from '@tauri-apps/api/window';
         * const monitors = await availableMonitors();
         * if (monitors.length > 1) {
         *   await getCurrentWindow().setFullscreenOnMonitor(monitors[1].position);
         * }
         * ```
         *
         * @param position A physical position inside the target monitor, such as {@linkcode Monitor.position}.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-fullscreen-on-monitor` permission (not included
         * in `core:window:default`).
         *
         * @since 2.12.0
         */
        async setFullscreenOnMonitor(position) {
          return invoke("plugin:window|set_fullscreen_on_monitor", {
            label: this.label,
            value: position
          });
        }
        /**
         * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won't work if the window was already in the native fullscreen).
         * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
         *
         * On other platforms, this is the same as {@link Window.setFullscreen}.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setSimpleFullscreen(true);
         * ```
         *
         * @param fullscreen Whether the window should go to simple fullscreen or not.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-simple-fullscreen` permission (not included
         * in `core:window:default`).
         *
         * @since 2.8.0
         */
        async setSimpleFullscreen(fullscreen) {
          return invoke("plugin:window|set_simple_fullscreen", {
            label: this.label,
            value: fullscreen
          });
        }
        /**
         * Bring the window to front and focus.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setFocus();
         * ```
         *
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-focus` permission (not included
         * in `core:window:default`).
         */
        async setFocus() {
          return invoke("plugin:window|set_focus", {
            label: this.label
          });
        }
        /**
         * Sets whether the window can be focused.
         *
         * #### Platform-specific
         *
         * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
         *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setFocusable(true);
         * ```
         *
         * @param focusable Whether the window can be focused.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-focusable` permission (not included
         * in `core:window:default`).
         */
        async setFocusable(focusable) {
          return invoke("plugin:window|set_focusable", {
            label: this.label,
            value: focusable
          });
        }
        /**
         * Sets the window icon.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setIcon('/tauri/awesome.png');
         * ```
         *
         * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
         * To enable it, change your Cargo.toml file:
         * ```toml
         * [dependencies]
         * tauri = { version = "...", features = ["...", "image-png"] }
         * ```
         *
         * @param icon Icon bytes or path to the icon file.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-icon` permission (not included
         * in `core:window:default`).
         */
        async setIcon(icon) {
          return invoke("plugin:window|set_icon", {
            label: this.label,
            value: transformImage(icon)
          });
        }
        /**
         * Whether the window icon should be hidden from the taskbar or not.
         *
         * #### Platform-specific
         *
         * - **macOS:** Unsupported.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setSkipTaskbar(true);
         * ```
         *
         * @param skip true to hide window icon, false to show it.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-skip-taskbar` permission (not included
         * in `core:window:default`).
         */
        async setSkipTaskbar(skip) {
          return invoke("plugin:window|set_skip_taskbar", {
            label: this.label,
            value: skip
          });
        }
        /**
         * Grabs the cursor, preventing it from leaving the window.
         *
         * There's no guarantee that the cursor will be hidden. You should
         * hide it by yourself if you want so.
         *
         * #### Platform-specific
         *
         * - **Linux:** Unsupported.
         * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setCursorGrab(true);
         * ```
         *
         * @param grab `true` to grab the cursor icon, `false` to release it.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-cursor-grab` permission (not included
         * in `core:window:default`).
         */
        async setCursorGrab(grab) {
          return invoke("plugin:window|set_cursor_grab", {
            label: this.label,
            value: grab
          });
        }
        /**
         * Modifies the cursor's visibility.
         *
         * #### Platform-specific
         *
         * - **Windows:** The cursor is only hidden within the confines of the window.
         * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
         *   outside of the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setCursorVisible(false);
         * ```
         *
         * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-cursor-visible` permission (not included
         * in `core:window:default`).
         */
        async setCursorVisible(visible) {
          return invoke("plugin:window|set_cursor_visible", {
            label: this.label,
            value: visible
          });
        }
        /**
         * Modifies the cursor icon of the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setCursorIcon('help');
         * ```
         *
         * @param icon The new cursor icon.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-cursor-icon` permission (not included
         * in `core:window:default`).
         */
        async setCursorIcon(icon) {
          return invoke("plugin:window|set_cursor_icon", {
            label: this.label,
            value: icon
          });
        }
        /**
         * Sets the window background color.
         *
         * #### Platform-specific:
         *
         * - **Windows:** alpha channel is ignored.
         * - **iOS / Android:** Unsupported.
         *
         * This sets the color of the window itself, which is what you see while the
         * webview is still loading or behind a transparent page. To also change the
         * webview background use {@link WebviewWindow.setBackgroundColor}.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setBackgroundColor('#2f2f2f');
         * // also accepts an RGB/RGBA tuple or an object
         * await getCurrentWindow().setBackgroundColor([47, 47, 47, 255]);
         * ```
         *
         * @param color The new background color, see {@link Color}.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-background-color` permission (not included
         * in `core:window:default`).
         *
         * @since 2.1.0
         */
        async setBackgroundColor(color) {
          return invoke("plugin:window|set_background_color", {
            label: this.label,
            value: color
          });
        }
        /**
         * Changes the position of the cursor in window coordinates.
         * @example
         * ```typescript
         * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
         * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
         * ```
         *
         * @param position The new cursor position.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-cursor-position` permission (not included
         * in `core:window:default`).
         */
        async setCursorPosition(position) {
          return invoke("plugin:window|set_cursor_position", {
            label: this.label,
            value: position instanceof Position ? position : new Position(position)
          });
        }
        /**
         * Changes the cursor events behavior.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setIgnoreCursorEvents(true);
         * ```
         *
         * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-ignore-cursor-events` permission (not included
         * in `core:window:default`).
         */
        async setIgnoreCursorEvents(ignore) {
          return invoke("plugin:window|set_ignore_cursor_events", {
            label: this.label,
            value: ignore
          });
        }
        /**
         * Starts dragging the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().startDragging();
         * ```
         *
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-start-dragging` permission (not included
         * in `core:window:default`).
         */
        async startDragging() {
          return invoke("plugin:window|start_dragging", {
            label: this.label
          });
        }
        /**
         * Starts resize-dragging the window.
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().startResizeDragging();
         * ```
         *
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-start-resize-dragging` permission (not included
         * in `core:window:default`).
         */
        async startResizeDragging(direction) {
          return invoke("plugin:window|start_resize_dragging", {
            label: this.label,
            value: direction
          });
        }
        /**
         * Sets the badge count. It is app wide and not specific to this window.
         *
         * #### Platform-specific
         *
         * - **Windows**: Unsupported. Use {@linkcode Window.setOverlayIcon} instead.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setBadgeCount(5);
         * ```
         *
         * @param count The badge count. Use `undefined` to remove the badge.
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-badge-count` permission (not included
         * in `core:window:default`).
         */
        async setBadgeCount(count) {
          return invoke("plugin:window|set_badge_count", {
            label: this.label,
            value: count
          });
        }
        /**
         * Sets the badge label shown on the app's dock icon. **macOS only**
         *
         * Unlike {@linkcode Window.setBadgeCount}, which takes a number, this shows
         * arbitrary short text. It is app-wide and not specific to this window.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setBadgeLabel("Hello");
         * ```
         *
         * @param label The badge label. Use `undefined` to remove the badge.
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-badge-label` permission (not included
         * in `core:window:default`).
         */
        async setBadgeLabel(label) {
          return invoke("plugin:window|set_badge_label", {
            label: this.label,
            value: label
          });
        }
        /**
         * Sets the overlay icon. **Windows only**
         * The overlay icon can be set for every window.
         *
         *
         * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
         * To enable it, change your Cargo.toml file:
         *
         * ```toml
         * [dependencies]
         * tauri = { version = "...", features = ["...", "image-png"] }
         * ```
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
         * ```
         *
         * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-overlay-icon` permission (not included
         * in `core:window:default`).
         */
        async setOverlayIcon(icon) {
          return invoke("plugin:window|set_overlay_icon", {
            label: this.label,
            value: icon ? transformImage(icon) : void 0
          });
        }
        /**
         * Sets the taskbar progress state.
         *
         * #### Platform-specific
         *
         * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
         * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
         *
         * @example
         * ```typescript
         * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
         * await getCurrentWindow().setProgressBar({
         *   status: ProgressBarStatus.Normal,
         *   progress: 50,
         * });
         * ```
         *
         * @return A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-progress-bar` permission (not included
         * in `core:window:default`).
         */
        async setProgressBar(state) {
          return invoke("plugin:window|set_progress_bar", {
            label: this.label,
            value: state
          });
        }
        /**
         * Sets whether the window should be visible on all workspaces or virtual desktops.
         *
         * #### Platform-specific
         *
         * - **Windows / iOS / Android:** Unsupported.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setVisibleOnAllWorkspaces(true);
         * ```
         *
         * @param visible Whether the window should follow the user across workspaces.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-visible-on-all-workspaces` permission (not included
         * in `core:window:default`).
         *
         * @since 2.0.0
         */
        async setVisibleOnAllWorkspaces(visible) {
          return invoke("plugin:window|set_visible_on_all_workspaces", {
            label: this.label,
            value: visible
          });
        }
        /**
         * Sets the title bar style. **macOS only**.
         *
         * Use `transparent` or `overlay` to build a custom title bar: with `overlay` the
         * page extends under the title bar and only the traffic lights remain, so leave
         * room for them in your layout and pair it with {@link Window.startDragging} on a
         * draggable region.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setTitleBarStyle('overlay');
         * ```
         *
         * @param style The new title bar style, see {@link TitleBarStyle}.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-title-bar-style` permission (not included
         * in `core:window:default`).
         *
         * @since 2.0.0
         */
        async setTitleBarStyle(style) {
          return invoke("plugin:window|set_title_bar_style", {
            label: this.label,
            value: style
          });
        }
        /**
         * Set window theme, pass in `null` or `undefined` to follow system theme
         *
         * #### Platform-specific
         *
         * - **Linux / macOS**: Theme is app-wide and not specific to this window.
         * - **iOS / Android:** Unsupported.
         *
         * Use {@link Window.theme} to read the effective theme and
         * {@link Window.onThemeChanged} to react to changes.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from '@tauri-apps/api/window';
         * await getCurrentWindow().setTheme('dark');
         * // follow the system theme again
         * await getCurrentWindow().setTheme(null);
         * ```
         *
         * @param theme The theme to apply, or `null`/`undefined` to follow the system theme.
         * @returns A promise indicating the success or failure of the operation.
         *
         * @remarks Requires the `core:window:allow-set-theme` permission (not included
         * in `core:window:default`).
         *
         * @since 2.0.0
         */
        async setTheme(theme) {
          return invoke("plugin:window|set_theme", {
            label: this.label,
            value: theme
          });
        }
        // Listeners
        /**
         * Listen to window resize.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
         *  console.log('Window resized', size);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onResized(handler) {
          return this.listen(TauriEvent.WINDOW_RESIZED, (e) => {
            e.payload = new PhysicalSize(e.payload);
            handler(e);
          });
        }
        /**
         * Listen to window move.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
         *  console.log('Window moved', position);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onMoved(handler) {
          return this.listen(TauriEvent.WINDOW_MOVED, (e) => {
            e.payload = new PhysicalPosition(e.payload);
            handler(e);
          });
        }
        /**
         * Listen to window close requested. Emitted when the user requests to closes the window.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * // `confirm` comes from the dialog plugin, which you have to add separately:
         * // `pnpm tauri add dialog`
         * import { confirm } from '@tauri-apps/plugin-dialog';
         * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
         *   const confirmed = await confirm('Are you sure?');
         *   if (!confirmed) {
         *     // user did not confirm closing the window; let's prevent it
         *     event.preventDefault();
         *   }
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onCloseRequested(handler) {
          return this.listen(TauriEvent.WINDOW_CLOSE_REQUESTED, async (event) => {
            const evt = new CloseRequestedEvent(event);
            await handler(evt);
            if (!evt.isPreventDefault()) {
              await this.destroy();
            }
          });
        }
        /**
         * Listen to a file drop event.
         * The listener is triggered when the user hovers the selected files on the webview,
         * drops the files or cancels the operation.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
         *  if (event.payload.type === 'over') {
         *    console.log('User hovering', event.payload.position);
         *  } else if (event.payload.type === 'drop') {
         *    console.log('User dropped', event.payload.paths);
         *  } else {
         *    console.log('File drop cancelled');
         *  }
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onDragDropEvent(handler) {
          const unlistenDrag = await this.listen(TauriEvent.DRAG_ENTER, (event) => {
            handler({
              ...event,
              payload: {
                type: "enter",
                paths: event.payload.paths,
                position: new PhysicalPosition(event.payload.position)
              }
            });
          });
          const unlistenDragOver = await this.listen(TauriEvent.DRAG_OVER, (event) => {
            handler({
              ...event,
              payload: {
                type: "over",
                position: new PhysicalPosition(event.payload.position)
              }
            });
          });
          const unlistenDrop = await this.listen(TauriEvent.DRAG_DROP, (event) => {
            handler({
              ...event,
              payload: {
                type: "drop",
                paths: event.payload.paths,
                position: new PhysicalPosition(event.payload.position)
              }
            });
          });
          const unlistenCancel = await this.listen(TauriEvent.DRAG_LEAVE, (event) => {
            handler({ ...event, payload: { type: "leave" } });
          });
          return async () => {
            await Promise.all([
              unlistenDrag(),
              unlistenDrop(),
              unlistenDragOver(),
              unlistenCancel()
            ]);
          };
        }
        /**
         * Listen to window focus change.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
         *  console.log('Focus changed, window is focused? ' + focused);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onFocusChanged(handler) {
          const unlistenFocus = await this.listen(TauriEvent.WINDOW_FOCUS, (event) => {
            handler({ ...event, payload: true });
          });
          const unlistenBlur = await this.listen(TauriEvent.WINDOW_BLUR, (event) => {
            handler({ ...event, payload: false });
          });
          return async () => {
            await Promise.all([unlistenFocus(), unlistenBlur()]);
          };
        }
        /**
         * Listen to window scale change. Emitted when the window's scale factor has changed.
         * The following user actions can cause DPI changes:
         * - Changing the display's resolution.
         * - Changing the display's scale factor (e.g. in Control Panel on Windows).
         * - Moving the window to a display with a different scale factor.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
         *  console.log('Scale changed', payload.scaleFactor, payload.size);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onScaleChanged(handler) {
          return this.listen(TauriEvent.WINDOW_SCALE_FACTOR_CHANGED, handler);
        }
        /**
         * Listen to the system theme change.
         *
         * @example
         * ```typescript
         * import { getCurrentWindow } from "@tauri-apps/api/window";
         * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
         *  console.log('New theme: ' + theme);
         * });
         *
         * // call unlisten when your handler goes out of scope e.g. the component is unmounted
         * unlisten();
         * ```
         *
         * @returns A promise resolving to a function to unlisten to the event.
         *
         * @remarks The listener is removed automatically when this window is destroyed,
         * so you do not need to unlisten just because the window is closing. Do call the
         * returned function when the listener's own scope ends, e.g. on page navigation
         * or when a component unmounts.
         */
        async onThemeChanged(handler) {
          return this.listen(TauriEvent.WINDOW_THEME_CHANGED, handler);
        }
      };
      (function(BackgroundThrottlingPolicy2) {
        BackgroundThrottlingPolicy2["Disabled"] = "disabled";
        BackgroundThrottlingPolicy2["Throttle"] = "throttle";
        BackgroundThrottlingPolicy2["Suspend"] = "suspend";
      })(BackgroundThrottlingPolicy || (BackgroundThrottlingPolicy = {}));
      (function(ScrollBarStyle2) {
        ScrollBarStyle2["Default"] = "default";
        ScrollBarStyle2["FluentOverlay"] = "fluentOverlay";
      })(ScrollBarStyle || (ScrollBarStyle = {}));
      (function(Effect2) {
        Effect2["AppearanceBased"] = "appearanceBased";
        Effect2["Light"] = "light";
        Effect2["Dark"] = "dark";
        Effect2["MediumLight"] = "mediumLight";
        Effect2["UltraDark"] = "ultraDark";
        Effect2["Titlebar"] = "titlebar";
        Effect2["Selection"] = "selection";
        Effect2["Menu"] = "menu";
        Effect2["Popover"] = "popover";
        Effect2["Sidebar"] = "sidebar";
        Effect2["HeaderView"] = "headerView";
        Effect2["Sheet"] = "sheet";
        Effect2["WindowBackground"] = "windowBackground";
        Effect2["HudWindow"] = "hudWindow";
        Effect2["FullScreenUI"] = "fullScreenUI";
        Effect2["Tooltip"] = "tooltip";
        Effect2["ContentBackground"] = "contentBackground";
        Effect2["UnderWindowBackground"] = "underWindowBackground";
        Effect2["UnderPageBackground"] = "underPageBackground";
        Effect2["LiquidGlassRegular"] = "liquidGlassRegular";
        Effect2["LiquidGlassClear"] = "liquidGlassClear";
        Effect2["Mica"] = "mica";
        Effect2["Blur"] = "blur";
        Effect2["Acrylic"] = "acrylic";
        Effect2["Tabbed"] = "tabbed";
        Effect2["TabbedDark"] = "tabbedDark";
        Effect2["TabbedLight"] = "tabbedLight";
      })(Effect || (Effect = {}));
      (function(EffectState2) {
        EffectState2["FollowsWindowActiveState"] = "followsWindowActiveState";
        EffectState2["Active"] = "active";
        EffectState2["Inactive"] = "inactive";
      })(EffectState || (EffectState = {}));
    }
  });

  // node_modules/@tauri-apps/plugin-dialog/dist-js/index.js
  async function open(options = {}) {
    if (typeof options === "object") {
      Object.freeze(options);
    }
    return await invoke("plugin:dialog|open", { options });
  }
  async function save(options = {}) {
    if (typeof options === "object") {
      Object.freeze(options);
    }
    return await invoke("plugin:dialog|save", { options });
  }
  var init_dist_js = __esm({
    "node_modules/@tauri-apps/plugin-dialog/dist-js/index.js"() {
      init_core();
    }
  });

  // node_modules/@tauri-apps/plugin-clipboard-manager/dist-js/index.js
  async function writeText(text, opts) {
    await invoke("plugin:clipboard-manager|write_text", {
      label: opts?.label,
      text
    });
  }
  async function readText() {
    return await invoke("plugin:clipboard-manager|read_text");
  }
  var init_dist_js2 = __esm({
    "node_modules/@tauri-apps/plugin-clipboard-manager/dist-js/index.js"() {
      init_core();
      init_image();
    }
  });

  // tauri_shim.js
  var require_tauri_shim = __commonJS({
    "tauri_shim.js"() {
      init_core();
      init_path();
      init_window();
      init_event();
      init_dist_js();
      init_dist_js2();
      if (!window.__TAURI__) {
        window.__TAURI__ = {};
      }
      window.__TAURI__.core = {
        invoke
      };
      window.__TAURI__.event = {
        listen,
        once,
        emit,
        emitTo
      };
      window.__TAURI__.path = path_exports;
      window.__TAURI__.window = {
        getCurrentWindow
      };
      window.__TAURI__.dialog = {
        save,
        open
      };
      window.__TAURI__.clipboardManager = {
        readText,
        writeText
      };
      window.__TAURI__.config = {
        RSCRIPTS_API_KEY: "rsc_live_BiyIMQoRnMwM70R3zq4tP5iuahnx0SHw"
      };
      window.__TAURI__.fs = {
        writeTextFile: async (path, content) => {
          return await invoke("write_text_file", { path, content });
        },
        readTextFile: async (path) => {
          return await invoke("read_dropped_file", { path });
        },
        exists: async (path) => {
          return await invoke("path_exists", { path });
        },
        mkdir: async (path, options) => {
          return await invoke("create_dir", { path });
        },
        remove: async (path, options) => {
          return await invoke("remove_path", { path });
        },
        rename: async (oldPath, newPath) => {
          return await invoke("rename_path", { oldPath, newPath });
        },
        readDir: async (path) => {
          const entries = await invoke("read_dir_entries", { path });
          return entries.map((entry) => ({
            name: entry.name,
            isDirectory: Boolean(entry.is_dir),
            isFile: !Boolean(entry.is_dir),
            isSymlink: false
          }));
        },
        stat: async (path) => {
          return await invoke("path_stat", { path });
        }
      };
    }
  });
  require_tauri_shim();
})();
