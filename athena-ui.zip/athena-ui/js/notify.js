const NOTIFY_MAX = 3;

const NOTIFY_ICONS = {
  info: "check",
  success: "check",
  warn: "warning",
  error: "error",
};

function GetNotifyDurations() {
  return {
    info: UI_STATE.notify_duration_info ?? 2400,
    success: UI_STATE.notify_duration_success ?? 2200,
    warn: UI_STATE.notify_duration_warn ?? 3200,
    error: UI_STATE.notify_duration_error ?? 4200,
  };
}

function GetNotifyStack() {
  let stack = document.getElementById("notify-stack");

  if (!stack) {
    stack = document.createElement("div");
    stack.id = "notify-stack";
    stack.className = "notify-stack";
    document.body.appendChild(stack);
  }

  return stack;
}

function DismissNotify(toast) {
  if (!toast || toast.dataset.leaving === "1") {
    return;
  }

  toast.dataset.leaving = "1";
  toast.classList.remove("notify-toast-visible");
  window.setTimeout(() => toast.remove(), 200);
}

function Notify(message, kind) {
  if (UI_STATE.notifications_enabled === false) {
    return;
  }

  const durations = GetNotifyDurations();
  const toast_kind = kind && durations[kind] ? kind : "info";
  const stack = GetNotifyStack();

  while (stack.children.length >= NOTIFY_MAX) {
    DismissNotify(stack.firstElementChild);
    stack.firstElementChild.remove();
  }

  const toast = document.createElement("div");
  toast.className = `notify-toast notify-toast-${toast_kind}`;
  toast.setAttribute("role", "status");

  const icon = document.createElement("span");
  icon.className = "notify-icon";
  icon.innerHTML = IconTag(NOTIFY_ICONS[toast_kind]);
  toast.appendChild(icon);

  const text = document.createElement("span");
  text.className = "notify-text";
  text.textContent = message;
  toast.appendChild(text);

  const close_btn = document.createElement("button");
  close_btn.className = "notify-close";
  close_btn.dataset.tooltip = "Dismiss";
  close_btn.innerHTML = IconTag("close");
  close_btn.addEventListener("click", () => DismissNotify(toast));
  toast.appendChild(close_btn);

  stack.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("notify-toast-visible"));

  window.setTimeout(() => DismissNotify(toast), durations[toast_kind]);
}
