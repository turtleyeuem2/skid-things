const CLIENTS_POLL_MS = 2500;
const CLIENTS_POP_GAP = 6;
const CLIENTS_POP_EDGE = 8;
const CLIENTS_POP_WIDTH = 332;

const CLIENT_SELECTION = new Map();

const clients_new_pids = new Set();
let clients_pop_el = null;
let clients_list_el = null;
let clients_count_el = null;
let clients_foot_el = null;
let clients_refresh_btn = null;
let clients_poll_id = null;

function GetClientsButton() {
  return document.getElementById("console-clients-btn");
}

function BuildClientsPop() {
  const pop_el = document.createElement("div");
  pop_el.id = "clients-pop";
  pop_el.className = "clients-pop";

  const head_el = document.createElement("div");
  head_el.className = "clients-head";

  const title_el = document.createElement("span");
  title_el.className = "clients-title";
  title_el.textContent = "Clients (0)";
  head_el.appendChild(title_el);

  const spacer_el = document.createElement("div");
  spacer_el.className = "clients-head-spacer";
  head_el.appendChild(spacer_el);

  const refresh_btn = document.createElement("button");
  refresh_btn.className = "clients-head-btn";
  refresh_btn.dataset.tooltip = "Refresh";
  refresh_btn.innerHTML = IconTag("refresh");
  refresh_btn.addEventListener("click", () => RefreshClients());
  head_el.appendChild(refresh_btn);

  pop_el.appendChild(head_el);

  const list_el = document.createElement("div");
  list_el.className = "clients-list";
  pop_el.appendChild(list_el);

  const foot_el = document.createElement("div");
  foot_el.className = "clients-foot";
  pop_el.appendChild(foot_el);

  document.body.appendChild(pop_el);

  clients_pop_el = pop_el;
  clients_list_el = list_el;
  clients_count_el = title_el;
  clients_foot_el = foot_el;
  clients_refresh_btn = refresh_btn;

  return pop_el;
}

function GetClientsPop() {
  if (!clients_pop_el) {
    BuildClientsPop();
  }

  return clients_pop_el;
}

function PlaceClientsPop() {
  const pop_el = GetClientsPop();
  const button_el = GetClientsButton();

  if (!button_el) {
    return;
  }

  const rect = button_el.getBoundingClientRect();
  const pop_w = pop_el.offsetWidth || CLIENTS_POP_WIDTH;
  const pop_h = pop_el.offsetHeight;
  const view_w = window.innerWidth;
  const view_h = window.innerHeight;

  let left = rect.right + CLIENTS_POP_GAP;

  if (left + pop_w + CLIENTS_POP_EDGE > view_w) {
    left = rect.left - pop_w - CLIENTS_POP_GAP;
  }

  if (left + pop_w + CLIENTS_POP_EDGE > view_w) {
    left = view_w - pop_w - CLIENTS_POP_EDGE;
  }

  left = Math.max(left, CLIENTS_POP_EDGE);

  let top = rect.bottom + CLIENTS_POP_GAP;

  if (top + pop_h + CLIENTS_POP_EDGE > view_h) {
    top = rect.top - pop_h - CLIENTS_POP_GAP;
  }

  top = Math.max(top, CLIENTS_POP_EDGE);

  pop_el.style.left = `${left}px`;
  pop_el.style.top = `${top}px`;
  pop_el.classList.toggle("clients-pop-above", top < rect.top);
}

function IsClientsPopOpen() {
  const pop_el = clients_pop_el;

  return Boolean(pop_el && pop_el.classList.contains("clients-pop-open"));
}

function CloseClientsPop() {
  if (clients_pop_el) {
    clients_pop_el.classList.remove("clients-pop-open", "clients-pop-above");
  }
}

function GetSelectedClientPids() {
  return Array.from(CLIENT_SELECTION.entries())
    .filter(([, is_selected]) => is_selected)
    .map(([pid]) => pid)
    .sort((a, b) => a - b);
}

function SetClientSelected(pid, is_selected) {
  CLIENT_SELECTION.set(pid, is_selected);

  if (!window.__TAURI__ || !window.__TAURI__.core) {
    return;
  }

  window.__TAURI__.core
    .invoke("set_client_selected", { pid, selected: is_selected })
    .catch((err) => LogWarn(`could not store client selection: ${err}`));
}

function MergeClientSelection(clients) {
  if (!Array.isArray(clients)) {
    return;
  }

  const live_pids = new Set();

  for (const client of clients) {
    live_pids.add(client.pid);

    if (CLIENT_SELECTION.has(client.pid)) {
      continue;
    }

    CLIENT_SELECTION.set(client.pid, true);
    SetClientSelected(client.pid, true);
  }

  for (const pid of Array.from(CLIENT_SELECTION.keys())) {
    if (!live_pids.has(pid)) {
      CLIENT_SELECTION.delete(pid);
    }
  }
}

function BuildClientCheck(is_checked, on_toggle) {
  const label_el = document.createElement("label");
  label_el.className = "hexion-check client-check";

  const input_el = document.createElement("input");
  input_el.type = "checkbox";
  input_el.className = "hexion-check-input";
  input_el.checked = is_checked;
  input_el.setAttribute("aria-label", "Include this client");
  input_el.addEventListener("change", () => on_toggle(input_el.checked));

  label_el.appendChild(input_el);
  label_el.insertAdjacentHTML("beforeend", BuildCheckGlyph(false));

  return label_el;
}

function BuildClientRow(client) {
  const row_el = document.createElement("div");
  row_el.className = "client-row";
  row_el.dataset.pid = String(client.pid);

  if (clients_new_pids.has(client.pid)) {
    row_el.classList.add("client-row-new");
  }

  row_el.appendChild(
    BuildClientCheck(CLIENT_SELECTION.get(client.pid) === true, (is_checked) => {
      SetClientSelected(client.pid, is_checked);
      RefreshClientsFoot();
    })
  );

  const info_el = document.createElement("div");
  info_el.className = "client-info";

  const name_el = document.createElement("span");
  name_el.className = "client-name";
  name_el.textContent = client.name || "RobloxPlayerBeta";
  info_el.appendChild(name_el);

  const pid_el = document.createElement("span");
  pid_el.className = "client-pid";
  pid_el.textContent = `pid ${client.pid} | port ${1337 + (client.pid % 1000)}`;
  info_el.appendChild(pid_el);

  row_el.appendChild(info_el);

  const kill_btn = document.createElement("button");
  kill_btn.className = "client-kill-btn";
  kill_btn.textContent = "terminate";
  kill_btn.addEventListener("click", () => TerminateClient(client.pid, kill_btn));
  row_el.appendChild(kill_btn);

  return row_el;
}

function RefreshClientsFoot() {
  if (!clients_foot_el) {
    return;
  }

  clients_foot_el.innerHTML = "";

  const total = CLIENT_SELECTION.size;
  const picked = GetSelectedClientPids().length;

  const label_el = document.createElement("span");
  label_el.innerHTML = `<b>${picked}</b> of <b>${total}</b> selected`;
  clients_foot_el.appendChild(label_el);

  const state_el = document.createElement("span");
  state_el.className = "clients-foot-state";

  if (total === 0) {
    state_el.textContent = "no clients";
  } else if (picked === 0) {
    state_el.textContent = "select any client";
  } else {
    state_el.textContent = `${picked} ready`;
  }

  clients_foot_el.appendChild(state_el);
}

function RenderClients(clients) {
  if (!clients_list_el || !clients_count_el) {
    return;
  }

  clients_count_el.textContent = `Clients (${clients.length})`;
  clients_list_el.innerHTML = "";

  if (clients.length === 0) {
    const empty_el = document.createElement("div");
    empty_el.className = "clients-empty";
    empty_el.textContent = "No clients running";

    const hint_el = document.createElement("span");
    hint_el.className = "clients-empty-hint";
    hint_el.textContent = "RobloxPlayerBeta shows up here on its own";
    empty_el.appendChild(hint_el);

    clients_list_el.appendChild(empty_el);
  } else {
    for (const client of clients) {
      clients_list_el.appendChild(BuildClientRow(client));
    }
  }

  clients_new_pids.clear();
  RefreshClientsFoot();
}

async function FetchClients() {
  const clients = await window.__TAURI__.core.invoke("list_clients");

  MergeClientSelection(clients);

  return clients;
}

async function RefreshClients() {
  if (clients_refresh_btn) {
    clients_refresh_btn.classList.add("clients-refreshing");
  }

  try {
    RenderClients(await FetchClients());
  } catch (err) {
    LogWarn(`could not list clients: ${err}`);
  } finally {
    window.setTimeout(() => {
      if (clients_refresh_btn) {
        clients_refresh_btn.classList.remove("clients-refreshing");
      }
    }, 420);
  }
}

async function TerminateClient(pid, button_el) {
  if (button_el) {
    button_el.disabled = true;
  }

  try {
    const result = await window.__TAURI__.core.invoke("terminate_client", { pid });

    LogPrint(result);
    if (UI_STATE.notify_show_script_run !== false) {
      Notify(`Terminated ${pid}`, "success");
    }
  } catch (err) {
    LogError(`terminate failed: ${err}`);
    if (UI_STATE.notify_show_errors !== false) {
      Notify("Failed to terminate", "error");
    }

    if (button_el) {
      button_el.disabled = false;
    }

    return;
  }

  await RefreshClients();
}

function HandleClientsOutsideClick(event) {
  if (!IsClientsPopOpen()) {
    return;
  }

  if (clients_pop_el && clients_pop_el.contains(event.target)) {
    return;
  }

  const button_el = GetClientsButton();

  if (button_el && button_el.contains(event.target)) {
    return;
  }

  CloseClientsPop();
}

async function ToggleClientsPop() {
  const pop_el = GetClientsPop();

  if (IsClientsPopOpen()) {
    CloseClientsPop();
    return;
  }

  await RefreshClients();

  PlaceClientsPop();
  pop_el.classList.add("clients-pop-open");
}

async function HandleClientsButton() {
  await ToggleClientsPop();
}

async function SetupClientsPanel() {
  const button_el = GetClientsButton();

  if (!button_el) {
    return;
  }

  BuildClientsPop();

  button_el.addEventListener("mousedown", (event) => event.stopPropagation());
  button_el.addEventListener("click", () => RunSafe("HandleClientsButton", HandleClientsButton));
  document.addEventListener("mousedown", HandleClientsOutsideClick, true);

  window.addEventListener("resize", () => {
    if (IsClientsPopOpen()) {
      PlaceClientsPop();
    }
  });

  if (window.__TAURI__ && window.__TAURI__.event) {
    try {
      await window.__TAURI__.event.listen("client-added", async (event) => {
        const pid = event && event.payload ? event.payload.pid : 0;

        if (pid) {
          clients_new_pids.add(pid);
        }

        if (IsClientsPopOpen()) {
          await RefreshClients();
          return;
        }

        await RunSafe("RefreshClients", RefreshClients);
      });

      await window.__TAURI__.event.listen("client-removed", async () => {
        if (IsClientsPopOpen()) {
          await RefreshClients();
        }
      });
    } catch (err) {
      LogWarn("could not watch for clients:", err);
    }
  }

  clients_poll_id = window.setInterval(() => {
    if (IsClientsPopOpen()) {
      RunSafe("RefreshClients", RefreshClients);
    }
  }, CLIENTS_POLL_MS);

  await RunSafe("RefreshClients", RefreshClients);
}
