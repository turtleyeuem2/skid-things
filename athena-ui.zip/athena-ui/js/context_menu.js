const CONTEXT_MENU_STACK = [];

function CloseContextMenu() {
  while (CONTEXT_MENU_STACK.length > 0) {
    const entry = CONTEXT_MENU_STACK.pop();
    entry.el.remove();
  }

  document.removeEventListener("mousedown", HandleContextMenuOutsideClick, true);
  document.removeEventListener("contextmenu", HandleContextMenuOutsideRightClick, true);
}

function CloseContextMenuAbove(depth) {
  while (CONTEXT_MENU_STACK.length > depth) {
    const entry = CONTEXT_MENU_STACK.pop();
    entry.el.remove();
  }
}

function IsPointInsideAnyMenu(x, y) {
  return CONTEXT_MENU_STACK.some((entry) => {
    const rect = entry.el.getBoundingClientRect();
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  });
}

function HandleContextMenuOutsideClick(event) {
  const inside = CONTEXT_MENU_STACK.some((entry) => entry.el.contains(event.target));
  if (!inside) {
    CloseContextMenu();
  }
}

function HandleContextMenuOutsideRightClick(event) {
  if (!IsPointInsideAnyMenu(event.clientX, event.clientY)) {
    CloseContextMenu();
  }
}

function ShowContextMenu(x, y, items, opts) {
  const resolved_opts = opts || {};
  const is_submenu = Boolean(resolved_opts.is_submenu);

  if (!is_submenu) {
    CloseContextMenu();
  }

  const depth = CONTEXT_MENU_STACK.length;

  const menu = document.createElement("div");
  menu.className = "context-menu";

  items.forEach((item) => {
    if (item.separator) {
      const separator = document.createElement("div");
      separator.className = "context-menu-separator";
      menu.appendChild(separator);
      return;
    }

    const button = document.createElement("button");
    button.className = "context-menu-item" + (item.danger ? " context-menu-item-danger" : "") + (item.disabled ? " context-menu-item-disabled" : "");

    if (item.disabled) {
      button.disabled = true;
    }

    const icon = document.createElement("span");

    if (item.checkbox) {
      icon.className = "context-menu-check";
      icon.innerHTML = BuildCheckGlyph(item.checked);
    } else {
      icon.className = "context-menu-icon";

      if (item.icon_name) {
        icon.innerHTML = IconTag(item.icon_name);
      }
    }

    button.appendChild(icon);

    const label = document.createElement("span");
    label.className = "context-menu-label";
    label.textContent = item.label;
    button.appendChild(label);

    if (item.shortcut) {
      const shortcut = document.createElement("span");
      shortcut.className = "context-menu-shortcut";
      shortcut.textContent = item.shortcut;
      button.appendChild(shortcut);
    }

    if (!item.disabled) {
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        CloseContextMenu();
        item.on_click();
      });
    }

    if (item.on_context_menu) {
      button.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        event.stopPropagation();
        CloseContextMenuAbove(depth + 1);
        item.on_context_menu(event);
      });
    }

    menu.appendChild(button);
  });

  document.body.appendChild(menu);
  CONTEXT_MENU_STACK.push({ el: menu, depth });

  const menu_rect = menu.getBoundingClientRect();
  const clamped_x = Math.min(x, window.innerWidth - menu_rect.width - 6);
  const clamped_y = Math.min(y, window.innerHeight - menu_rect.height - 6);
  menu.style.left = `${Math.max(6, clamped_x)}px`;
  menu.style.top = `${Math.max(6, clamped_y)}px`;

  document.removeEventListener("mousedown", HandleContextMenuOutsideClick, true);
  document.removeEventListener("contextmenu", HandleContextMenuOutsideRightClick, true);
  setTimeout(() => {
    document.addEventListener("mousedown", HandleContextMenuOutsideClick, true);
    document.addEventListener("contextmenu", HandleContextMenuOutsideRightClick, true);
  }, 0);
}
