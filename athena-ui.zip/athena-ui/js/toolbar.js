function GetActiveTab() {
  return FindTab(TABS_STATE.active_id) || null;
}

function GetEditorText() {
  const editor_input = document.getElementById("editor-input");

  if (editor_input) {
    return editor_input.value;
  }

  const tab = GetActiveTab();
  return tab && typeof tab.content === "string" ? tab.content : "";
}

function GetFileNameFromPath(file_path) {
  return String(file_path).split(/[\\/]/).pop() || "";
}

function SyncActiveTabFromEditor() {
  const tab = GetActiveTab();

  if (!tab) {
    return null;
  }

  tab.content = GetEditorText();
  return tab;
}

async function HandleRun() {
  const tab = SyncActiveTabFromEditor();
  const source = GetEditorText();

  if (source.trim().length === 0) {
    LogWarn("nothing to run");
    return;
  }

  try {
    await ExecuteScript(source, tab ? tab.name : "");
  } catch (err) {
    LogError(`run failed: ${err && err.message ? err.message : err}`);
  }
}

function HandleAttach() {
  Attach();
}

async function DialogWithWindowRules(dialog_call) {
  const tauri_window = window.__TAURI__ && window.__TAURI__.window;

  if (!tauri_window) {
    return dialog_call();
  }

  let suspended_on_top = false;

  try {
    const app_window = tauri_window.getCurrentWindow();

    if (UI_STATE.always_on_top && !(await app_window.isMaximized())) {
      await app_window.setAlwaysOnTop(false);
      suspended_on_top = true;
    }
  } catch (err) {
    LogWarn("could not suspend always-on-top for the file dialog:", err);
  }

  try {
    return await dialog_call();
  } finally {
    if (suspended_on_top) {
      try {
        await tauri_window.getCurrentWindow().setAlwaysOnTop(true);
      } catch (err) {
        LogWarn("could not restore always-on-top after the file dialog:", err);
      }
    }
  }
}

async function PickSavePath(default_name) {
  return DialogWithWindowRules(() => {
    const dialog = window.__TAURI__ && window.__TAURI__.dialog;

    if (!dialog) {
      return null;
    }

    return dialog.save({
      defaultPath: default_name || "script.lua",
      filters: [
        { name: "Lua", extensions: ["lua", "luau", "txt"] },
        { name: "All files", extensions: ["*"] },
      ],
    });
  });
}

async function PickOpenPaths() {
  const picked = await DialogWithWindowRules(() => {
    const dialog = window.__TAURI__ && window.__TAURI__.dialog;

    if (!dialog) {
      return [];
    }

    return dialog.open({
      multiple: true,
      filters: [
        { name: "Lua", extensions: ["lua", "luau", "txt"] },
        { name: "All files", extensions: ["*"] },
      ],
    });
  });

  if (!picked) {
    return [];
  }

  return Array.isArray(picked) ? picked : [picked];
}

async function HandleSave() {
  const tab = SyncActiveTabFromEditor();

  if (!tab) {
    LogWarn("no tab to save");
    return;
  }

  const target_path = tab.file_path || null;

  if (!target_path) {
    await HandleSaveAs(tab);
    return;
  }

  try {
    await FsWriteTextFile(target_path, tab.content);

    tab.saved_content = tab.content;
    tab.dirty = false;

    if (typeof InvalidateEntrySize === "function") {
      InvalidateEntrySize(target_path);
    }

    if (typeof RefreshTabsSection === "function") {
      await RefreshTabsSection();
    }

    await RenderTabs();

    LogPrint(`saved ${tab.name}`);
  } catch (err) {
    LogError(`save failed: ${err && err.message ? err.message : err}`);
  }
}

async function HandleSaveAs(tab) {
  if (!tab) {
    tab = GetActiveTab();
  }

  if (!tab) {
    LogWarn("no tab to save");
    return;
  }

  const target_path = await PickSavePath(tab.name);

  if (!target_path) {
    return;
  }

  const new_name = GetFileNameFromPath(target_path);
  const ok = await RelocateTabToPath(tab, target_path, new_name);

  if (ok) {
    if (typeof InvalidateEntrySize === "function") {
      InvalidateEntrySize(target_path);
    }

    if (typeof RefreshTabsSection === "function") {
      await RefreshTabsSection();
    }

    await RenderTabs();

    LogPrint(`saved ${tab.name}`);
  } else {
    LogError(`save failed: could not write ${new_name}`);
  }
}

async function HandleOpen() {
  let paths = [];

  try {
    paths = await PickOpenPaths();
  } catch (err) {
    LogError(`open dialog failed: ${err && err.message ? err.message : err}`);
    return;
  }

  if (paths.length === 0) {
    return;
  }

  await OpenDroppedPaths(paths);
}

function HandleClearEditor() {
  const tab = GetActiveTab();
  const editor_input = document.getElementById("editor-input");

  if (!editor_input) {
    return;
  }

  editor_input.value = "";
  editor_input.dispatchEvent(new Event("input"));

  if (tab) {
    tab.content = "";
  }

  RenderTabs();

  LogPrint("editor cleared");
}

function SetupToolbarButtons() {
  const run_btn = document.getElementById("console-run-btn");
  const clear_editor_btn = document.getElementById("console-clear-editor-btn");
  const on_btn = document.getElementById("console-on-btn");

  if (run_btn) {
    run_btn.addEventListener("click", HandleRun);
  }

  if (clear_editor_btn) {
    clear_editor_btn.addEventListener("click", HandleClearEditor);
  }

  if (on_btn) {
    on_btn.addEventListener("click", HandleAttach);
  }

  window.addEventListener("keydown", (event) => {
    const has_mod = event.ctrlKey || event.metaKey;

    if (!has_mod || event.shiftKey || event.altKey) {
      return;
    }

    const key = event.key.toLowerCase();

    if (key === "s") {
      event.preventDefault();
      HandleSave();
      return;
    }

    if (key === "o") {
      event.preventDefault();
      HandleOpen();
    }
  });
}
