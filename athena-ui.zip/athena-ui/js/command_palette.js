const PALETTE_DEBUG_KEYWORD = "debug";
const PALETTE_MAX_RESULTS = 30;
const PALETTE_RECENT_MAX = 12;
const PALETTE_RECENT_SHOWN = 5;
const PALETTE_RECENCY_STEP = 14;

const PALETTE_COMMANDS = [
  {
    name: "run",
    hint: "Send the active tab to every selected client",
    icon: "run",
    run: () => HandleRun(),
  },
  {
    name: "attach",
    hint: "Start the loader and attach to Roblox",
    icon: "plug",
    run: () => Attach(),
  },
  {
    name: "refresh clients",
    hint: "Look for running clients again",
    icon: "refresh",
    run: () => RefreshClients(),
  },
  {
    name: "clear console",
    hint: "Empty the console output",
    icon: "trash",
    run: () => ClearConsole(),
  },
  {
    name: "clear explorer history",
    hint: "Empty the Recent list in the explorer",
    icon: "history",
    run: () => HandleClearAllHistory(),
  },
  {
    name: "copy console",
    hint: "Put the whole console output on the clipboard",
    icon: "copy",
    run: () => CopyEntireConsole(),
  },
  {
    name: "open file",
    hint: "Pick a file and open it in a tab",
    icon: "open",
    keys: ["Ctrl", "O"],
    run: () => HandleOpen(),
  },
  {
    name: "save",
    hint: "Write the active tab back to disk",
    icon: "save",
    keys: ["Ctrl", "S"],
    run: () => HandleSave(),
  },
  {
    name: "save all tabs",
    hint: "Write every open tab back to disk",
    icon: "duplicate",
    run: () => SaveAllTabs(),
  },
  {
    name: "new tab",
    hint: "Open a fresh empty tab",
    icon: "newtab",
    keys: ["Ctrl", "T"],
    run: () => CreateNewTab(),
  },
  {
    name: "close tab",
    hint: "Close the tab you are on",
    icon: "close",
    keys: ["Ctrl", "W"],
    run: () => RemoveTab(TABS_STATE.active_id),
  },
  {
    name: "reopen tab",
    hint: "Bring back the last tab you closed",
    icon: "redo",
    keys: ["Ctrl", "Shift", "T"],
    run: () => ReopenLastClosedTab(),
  },
  {
    name: "next tab",
    hint: "Move to the tab after the one you are on",
    icon: "arrowright",
    run: () => StepActiveTab(1),
  },
  {
    name: "previous tab",
    hint: "Move to the tab before the one you are on",
    icon: "arrowleft",
    run: () => StepActiveTab(-1),
  },
  {
    name: "close all tabs",
    hint: "Close every open tab",
    icon: "close",
    run: () => CloseEveryPaletteTab(),
  },
  {
    name: "new file",
    hint: "Create a file in the Scripts folder",
    icon: "file",
    run: () => CreatePaletteEntry(false),
  },
  {
    name: "new folder",
    hint: "Create a folder in the Scripts folder",
    icon: "folder",
    run: () => CreatePaletteEntry(true),
  },
  {
    name: "reload explorer",
    hint: "Read the Scripts and Autoexec folders from disk again",
    icon: "refresh",
    run: () => RefreshExplorerFromDisk(),
  },
  {
    name: "clear editor",
    hint: "Empty the editor without closing the tab",
    icon: "cleareditor",
    run: () => HandleClearEditor(),
  },
  {
    name: "format document",
    hint: "Tidy the indentation of the tab you are on",
    icon: "align",
    keys: ["Shift", "Alt", "F"],
    run: () => FormatActiveEditor(),
  },
  {
    name: "toggle comment",
    hint: "Comment or uncomment the lines the caret is on",
    icon: "comment",
    keys: ["Ctrl", "/"],
    run: () => ToggleEditorLineComment(),
  },
  {
    name: "duplicate line",
    hint: "Copy the line the caret is on and put it underneath",
    icon: "duplicate",
    keys: ["Ctrl", "D"],
    run: () => DuplicateEditorLine(),
  },
  {
    name: "cut",
    hint: "Cut the selection in the editor",
    icon: "cut",
    keys: ["Ctrl", "X"],
    run: () => RunEditorCommand("cut"),
  },
  {
    name: "copy",
    hint: "Copy the selection in the editor",
    icon: "copy",
    keys: ["Ctrl", "C"],
    run: () => RunEditorCommand("copy"),
  },
  {
    name: "paste",
    hint: "Paste the clipboard into the editor",
    icon: "paste",
    keys: ["Ctrl", "V"],
    run: () => PasteIntoEditor(),
  },
  {
    name: "undo",
    hint: "Undo the last edit",
    icon: "undo",
    keys: ["Ctrl", "Z"],
    run: () => RunEditorCommand("undo"),
  },
  {
    name: "redo",
    hint: "Redo the edit you undid",
    icon: "redo",
    keys: ["Ctrl", "Y"],
    run: () => RunEditorCommand("redo"),
  },
  {
    name: "select all",
    hint: "Select the whole tab",
    icon: "selectall",
    keys: ["Ctrl", "A"],
    run: () => RunEditorCommand("selectAll"),
  },
  {
    name: "increase tab size",
    hint: "Indent one more space per level",
    icon: "indentout",
    run: () => StepSettingRow("editor_tab_size", 1),
  },
  {
    name: "decrease tab size",
    hint: "Indent one less space per level",
    icon: "indentin",
    run: () => StepSettingRow("editor_tab_size", -1),
  },
  {
    name: "toggle explorer",
    hint: "Show or hide the file explorer",
    icon: "layout",
    run: () => ToggleExplorerPanel(),
  },
  {
    name: "toggle console",
    hint: "Show or hide the console",
    icon: "terminal",
    run: () => ToggleConsolePanel(),
  },
  {
    name: "toggle line numbers",
    hint: "Show or hide the numbered gutter",
    icon: "codefile",
    hint_fn: () => (GetSettingValue(FindSettingsRow("show_gutter")) ? "Hide the numbered gutter" : "Show the numbered gutter"),
    run: () => ToggleSettingRow("show_gutter"),
  },
  {
    name: "toggle indent guides",
    hint: "Show or hide the indent level lines",
    icon: "indentin",
    hint_fn: () => (GetSettingValue(FindSettingsRow("show_indent_guides")) ? "Hide the indent guide lines" : "Show the indent guide lines"),
    run: () => ToggleSettingRow("show_indent_guides"),
  },
  {
    name: "toggle problems",
    hint: "Show or hide the unclosed blocks reported under the editor",
    icon: "warning",
    hint_fn: () => (GetSettingValue(FindSettingsRow("show_problems")) ? "Stop reporting problems" : "Report problems under the editor"),
    run: () => ToggleSettingRow("show_problems"),
  },
  {
    name: "toggle active line",
    hint: "Show or hide the line the caret sits on",
    icon: "align",
    hint_fn: () => (GetSettingValue(FindSettingsRow("show_active_line")) ? "Hide the active line highlight" : "Show the active line highlight"),
    run: () => ToggleSettingRow("show_active_line"),
  },
  {
    name: "toggle console wrap",
    hint: "Fold a console line that runs off the edge instead of cutting it",
    icon: "wrap",
    hint_fn: () => (GetSettingValue(FindSettingsRow("console_wrap")) ? "Cut long console lines" : "Wrap long console lines"),
    run: () => ToggleSettingRow("console_wrap"),
  },
  {
    name: "toggle timestamps",
    hint: "Show or hide the time next to every console line",
    icon: "history",
    hint_fn: () => (GetSettingValue(FindSettingsRow("console_timestamps")) ? "Hide console timestamps" : "Show console timestamps"),
    run: () => ToggleSettingRow("console_timestamps"),
  },
  {
    name: "toggle autoscroll",
    hint: "Follow the newest line as output arrives",
    icon: "arrowup",
    hint_fn: () => (GetSettingValue(FindSettingsRow("console_autoscroll")) ? "Stop following new console output" : "Follow new console output"),
    run: () => ToggleSettingRow("console_autoscroll"),
  },
  {
    name: "toggle debug output",
    hint: "Show or hide the internal Hexion messages",
    icon: "terminal",
    hint_fn: () => (GetSettingValue(FindSettingsRow("show_debug_output")) ? "Hide internal Hexion messages" : "Show internal Hexion messages"),
    run: () => ToggleSettingRow("show_debug_output"),
  },
  {
    name: "toggle explorer side",
    hint: "Dock the file explorer to the other side of the window",
    icon: "move",
    hint_fn: () => (GetSettingValue(FindSettingsRow("explorer_side")) === "right" ? "Dock the explorer on the left" : "Dock the explorer on the right"),
    run: () => ToggleSettingEnum("explorer_side", "left", "right"),
  },
  {
    name: "toggle compact density",
    hint: "Squeeze the rows, panels and tab bar tighter",
    icon: "layout",
    hint_fn: () => (GetSettingValue(FindSettingsRow("ui_density")) === "compact" ? "Go back to the cosy density" : "Switch to the compact density"),
    run: () => ToggleSettingEnum("ui_density", "cosy", "compact"),
  },
  {
    name: "toggle always on top",
    hint: "Keep Hexion above other windows",
    icon: "pin",
    hint_fn: () => (GetSettingValue(FindSettingsRow("always_on_top")) ? "Stop keeping Hexion on top" : "Keep Hexion on top"),
    run: () => ToggleSettingRow("always_on_top"),
  },
  {
    name: "zoom in",
    hint: "Make the text bigger",
    icon: "zoomin",
    keys: ["Ctrl", "="],
    run: () => ZoomPalettePane(1),
  },
  {
    name: "zoom out",
    hint: "Make the text smaller",
    icon: "zoomout",
    keys: ["Ctrl", "-"],
    run: () => ZoomPalettePane(-1),
  },
  {
    name: "reset zoom",
    hint: "Put the text back to its default size",
    icon: "resetzoom",
    keys: ["Ctrl", "0"],
    run: () => ZoomPalettePane(0),
  },
  {
    name: "settings",
    hint: "Open the Hexion settings",
    icon: "settings",
    run: () => OpenSettingsPanel(),
  },
  {
    name: "keyboard shortcuts",
    hint: "Open the list of every key Hexion listens for",
    icon: "keyboard",
    run: () => OpenSettingsCategory("Shortcuts"),
  },
  {
    name: "appearance settings",
    hint: "Jump to the colour, density and font options",
    icon: "swatch",
    run: () => OpenSettingsCategory("Appearance"),
  },
  {
    name: "editor settings",
    hint: "Jump to the editor options",
    icon: "codefile",
    run: () => OpenSettingsCategory("Editor"),
  },
  {
    name: "console settings",
    hint: "Jump to the console options",
    icon: "terminal",
    run: () => OpenSettingsCategory("Console"),
  },
  {
    name: "export settings",
    hint: "Write every option and interface setting to a json file",
    icon: "save",
    run: () => HandleExportSettings(),
  },
  {
    name: "import settings",
    hint: "Load a previously exported json file and restart Hexion",
    icon: "open",
    run: () => HandleImportSettings(),
  },
  {
    name: "open config folder",
    hint: "Open the folder Hexion keeps its settings and snippets in",
    icon: "folderopen",
    run: () => HandleOpenConfigFolder(),
  },
  {
    name: "reset settings",
    hint: "Put every option and interface setting back to its default",
    icon: "undo",
    run: () => HandleResetSettings(),
  },
  {
    name: "restart hexion",
    hint: "Close and start Hexion again",
    icon: "refresh",
    run: () => window.location.reload(),
  },
];

const PALETTE_DEFAULT_GROUPS = [
  { group: "First", names: ["run", "attach", "refresh clients", "keyboard shortcuts"] },
  { group: "Files", names: ["open file", "save", "new file", "new tab", "close tab", "reload explorer"] },
  { group: "Edit", names: ["format document", "toggle comment", "duplicate line", "clear editor", "undo", "redo"] },
  { group: "View", names: ["settings", "toggle explorer", "toggle console", "toggle line numbers"] },
];

let palette_active_index = 0;
let palette_results = [];
let palette_row_index = 0;

function GetPaletteEls() {
  return {
    overlay: document.getElementById("command-palette"),
    input: document.getElementById("command-palette-input"),
    list: document.getElementById("command-palette-list"),
  };
}

function ToggleExplorerPanel() {
  HandleExplorerVisibleChanged(GetExplorerVisible() === false);
}

function ToggleConsolePanel() {
  HandleConsoleVisibleChanged(GetConsoleVisible() === false);
}

function FindSettingsRow(key) {
  for (const page of SETTINGS_SCHEMA) {
    for (const row of page.rows) {
      if (row.key === key) {
        return row;
      }
    }
  }

  return null;
}

function SetSettingRowValue(key, value) {
  const row = FindSettingsRow(key);

  if (!row) {
    return;
  }

  SetSettingValue(row, value);
  NotifySettingChanged(row, value);
}

function ToggleSettingRow(key) {
  const row = FindSettingsRow(key);

  if (!row) {
    return;
  }

  SetSettingRowValue(key, !GetSettingValue(row));
}

function ToggleSettingEnum(key, first_value, second_value) {
  const row = FindSettingsRow(key);

  if (!row) {
    return;
  }

  const next = GetSettingValue(row) === second_value ? first_value : second_value;

  SetSettingRowValue(key, next);
}

function StepSettingRow(key, direction) {
  const row = FindSettingsRow(key);

  if (!row) {
    return;
  }

  const { min, max, step } = GetSettingBounds(row);
  const current = Number(GetSettingValue(row));

  if (!Number.isFinite(current)) {
    return;
  }

  const next = Math.min(Math.max(current + step * direction, min), max);

  SetSettingRowValue(key, Math.round(next * 1000) / 1000);
}

async function CloseEveryPaletteTab() {
  const tab_ids = TABS_STATE.tabs.map((tab) => tab.id);

  for (const tab_id of tab_ids) {
    if (!FindTab(tab_id)) {
      continue;
    }

    await RemoveTab(tab_id);
  }
}

async function CreatePaletteEntry(is_folder) {
  const base_dir = await GetBaseDir();
  const target_path = await JoinPath(base_dir, "scripts");

  await EnsureFolder(target_path);

  if (is_folder) {
    await HandleAddFolder(target_path);
    return;
  }

  await HandleAddFile(target_path);
}

function StepActiveTab(step) {
  const tabs = TABS_STATE.tabs;

  if (tabs.length === 0) {
    return;
  }

  const current = tabs.findIndex((tab) => tab.id === TABS_STATE.active_id);
  const next = current < 0 ? 0 : (current + step + tabs.length) % tabs.length;

  SetActiveTab(tabs[next].id);
}

function ZoomPalettePane(step) {
  if (step === 0) {
    SetEditorFontSize(GetUiStateDefault(EDITOR_FONT_SIZE_KEY));
    SetConsoleFontSize(GetUiStateDefault("console_font_size_px"));
    return;
  }

  SetEditorFontSize(UI_STATE.editor_font_size_px + step);
  SetConsoleFontSize(UI_STATE.console_font_size_px + step);
}

function ResolvePaletteHint(command) {
  return typeof command.hint_fn === "function" ? command.hint_fn() : command.hint;
}

function GetPaletteRecencyBoost(name) {
  const index = UI_STATE.palette_recents.indexOf(name);

  if (index === -1) {
    return 0;
  }

  return Math.max(0, PALETTE_RECENT_MAX * PALETTE_RECENCY_STEP - index * PALETTE_RECENCY_STEP);
}

function RecordPaletteUsage(name) {
  if (!name || name === PALETTE_DEBUG_KEYWORD) {
    return;
  }

  UI_STATE.palette_recents = UI_STATE.palette_recents.filter((entry) => entry !== name);
  UI_STATE.palette_recents.unshift(name);

  if (UI_STATE.palette_recents.length > PALETTE_RECENT_MAX) {
    UI_STATE.palette_recents.length = PALETTE_RECENT_MAX;
  }

  SaveUiState();
}

function IsSubsequence(needle, haystack) {
  if (needle.length === 0) {
    return true;
  }

  let cursor = 0;

  for (const char of haystack) {
    if (char === needle[cursor]) {
      cursor += 1;
    }
  }

  return cursor === needle.length;
}

function ScorePaletteCommand(command, query) {
  const name = command.name;
  const initials = name.split(" ").map((part) => part[0]).join("");

  if (name === query) {
    return 1200;
  }

  if (name.startsWith(query)) {
    return 900;
  }

  if (initials.startsWith(query)) {
    return 720;
  }

  if (name.split(" ").some((part) => part.startsWith(query))) {
    return 640;
  }

  if (name.includes(query)) {
    return 520;
  }

  if (IsSubsequence(query, name)) {
    return 340;
  }

  if (String(command.hint).toLowerCase().includes(query)) {
    return 180;
  }

  return 0;
}

function ParseDebugQuery(raw_query) {
  const text = String(raw_query || "").trim();
  const lower = text.toLowerCase();

  if (
    lower !== PALETTE_DEBUG_KEYWORD
    && !lower.startsWith(`${PALETTE_DEBUG_KEYWORD} `)
    && !lower.startsWith(`${PALETTE_DEBUG_KEYWORD}:`)
  ) {
    return null;
  }

  return text
    .slice(PALETTE_DEBUG_KEYWORD.length)
    .replace(/^[\s:]+/, "")
    .replace(/^"(.*)"$/, "$1")
    .replace(/^'(.*)'$/, "$1");
}

function BuildPaletteDebugEntry(message, is_hint) {
  return {
    key: is_hint ? "debug-hint" : "debug",
    group: is_hint ? "Print" : "Print",
    name: is_hint ? 'debug "message"' : "debug",
    hint: is_hint
      ? "Print a line straight to the Hexion console"
      : message.length > 0
      ? "Print a line to the Hexion console"
      : "Type a message after debug",
    icon: "terminal",
    badge: message,
    stays_open: message.length === 0,
    run: is_hint ? () => FillPaletteQuery("debug ") : () => LogPrint(message),
  };
}

function BuildPaletteCommandEntry(command, group, score) {
  return {
    key: command.name,
    group,
    name: command.name,
    hint: ResolvePaletteHint(command),
    icon: command.icon,
    keys: command.keys,
    score,
    run: command.run,
  };
}

function CollectPaletteDefaults() {
  const results = [];
  const seen = new Set();

  const recent_names = UI_STATE.palette_recents
    .filter((name) => PALETTE_COMMANDS.some((command) => command.name === name))
    .slice(0, PALETTE_RECENT_SHOWN);

  if (recent_names.length > 0) {
    for (const name of recent_names) {
      const command = PALETTE_COMMANDS.find((entry) => entry.name === name);
      results.push(BuildPaletteCommandEntry(command, "Recent", 0));
      seen.add(name);
    }
  }

  for (const group of PALETTE_DEFAULT_GROUPS) {
    for (const name of group.names) {
      if (seen.has(name)) {
        continue;
      }

      const command = PALETTE_COMMANDS.find((entry) => entry.name === name);

      if (!command) {
        continue;
      }

      results.push(BuildPaletteCommandEntry(command, group.group, 0));
      seen.add(name);
    }
  }

  results.push(BuildPaletteDebugEntry("", true));

  return results;
}

function CollectPaletteResults(raw_query) {
  const query = String(raw_query || "").trim().toLowerCase();
  const debug_message = ParseDebugQuery(raw_query);
  const results = [];

  if (debug_message === null && query.length === 0) {
    return CollectPaletteDefaults();
  }

  if (debug_message !== null) {
    results.push(BuildPaletteDebugEntry(debug_message, false));
  }

  const search_text = debug_message === null ? query : "";

  if (search_text.length === 0) {
    return results;
  }

  for (const command of PALETTE_COMMANDS) {
    const score = ScorePaletteCommand(command, search_text);

    if (score === 0) {
      continue;
    }

    results.push(BuildPaletteCommandEntry(command, "Commands", score + GetPaletteRecencyBoost(command.name)));
  }

  results.sort((a, b) => b.score - a.score);

  return results.slice(0, PALETTE_MAX_RESULTS);
}

function BuildPaletteKeys(keys) {
  const keys_el = document.createElement("span");
  keys_el.className = "palette-item-keys";

  for (const key of keys) {
    const key_el = document.createElement("span");
    key_el.className = "palette-item-key";
    key_el.textContent = key;
    keys_el.appendChild(key_el);
  }

  return keys_el;
}

function BuildPaletteItem(entry, is_active) {
  const item_el = document.createElement("button");
  item_el.className = is_active ? "palette-item palette-item-active" : "palette-item";
  item_el.type = "button";
  item_el.dataset.paletteIndex = String(palette_row_index);

  palette_row_index += 1;

  if (is_active) {
    item_el.setAttribute("aria-selected", "true");
  }

  const icon_el = document.createElement("span");
  icon_el.className = "palette-item-icon";
  icon_el.innerHTML = IconTag(entry.icon);
  item_el.appendChild(icon_el);

  const body_el = document.createElement("span");
  body_el.className = "palette-item-body";

  const name_el = document.createElement("span");
  name_el.className = "palette-item-name";
  name_el.textContent = entry.name;
  body_el.appendChild(name_el);

  const hint_el = document.createElement("span");
  hint_el.className = "palette-item-hint";
  hint_el.textContent = entry.hint;
  body_el.appendChild(hint_el);

  item_el.appendChild(body_el);

  if (entry.badge) {
    const badge_el = document.createElement("span");
    badge_el.className = "palette-item-badge";
    badge_el.textContent = `"${entry.badge}"`;
    item_el.appendChild(badge_el);
  }

  if (entry.keys && entry.keys.length > 0) {
    item_el.appendChild(BuildPaletteKeys(entry.keys));
  }

  item_el.addEventListener("mouseenter", () => {
    const index = Number(item_el.dataset.paletteIndex);

    if (!Number.isNaN(index)) {
      SetPaletteActiveIndex(index);
    }
  });

  item_el.addEventListener("click", () => {
    RunPaletteEntry(entry);
  });

  return item_el;
}

function BuildPaletteGroupLabel(text) {
  const group_el = document.createElement("div");
  group_el.className = "palette-group";
  group_el.textContent = text;
  return group_el;
}

function BuildPaletteEmpty(query) {
  const empty_el = document.createElement("div");
  empty_el.className = "palette-empty";
  empty_el.textContent = "Nothing matches that";

  const hint_el = document.createElement("span");
  hint_el.className = "palette-empty-hint";
  hint_el.textContent =
    ParseDebugQuery(query) !== null
      ? "Add a message after debug, like debug \"hello there\""
      : "Try a shorter name, or type debug \"hello there\" to print a line";
  empty_el.appendChild(hint_el);

  return empty_el;
}

function RenderPaletteList() {
  const { list, input } = GetPaletteEls();

  if (!list) {
    return;
  }

  list.innerHTML = "";
  palette_active_index = 0;
  palette_row_index = 0;

  if (palette_results.length === 0) {
    list.appendChild(BuildPaletteEmpty(input ? input.value : ""));
    return;
  }

  let last_group = "";

  palette_results.forEach((entry, index) => {
    if (entry.group !== last_group) {
      list.appendChild(BuildPaletteGroupLabel(entry.group));
      last_group = entry.group;
    }

    list.appendChild(BuildPaletteItem(entry, index === 0));
  });
}

function SetPaletteActiveIndex(next_index) {
  if (palette_results.length === 0) {
    return;
  }

  const clamped = Math.min(Math.max(next_index, 0), palette_results.length - 1);
  const { list } = GetPaletteEls();
  const items = list ? list.querySelectorAll(".palette-item") : [];

  if (items[palette_active_index]) {
    items[palette_active_index].classList.remove("palette-item-active");
    items[palette_active_index].removeAttribute("aria-selected");
  }

  if (items[clamped]) {
    items[clamped].classList.add("palette-item-active");
    items[clamped].setAttribute("aria-selected", "true");
    items[clamped].scrollIntoView({ block: "nearest" });
  }

  palette_active_index = clamped;
}

function RunPaletteEntry(entry) {
  if (!entry) {
    return;
  }

  if (entry.stays_open) {
    RunSafe(`palette:${entry.name}`, () => entry.run());
    return;
  }

  RecordPaletteUsage(entry.key);
  CloseCommandPalette();
  RunSafe(`palette:${entry.name}`, () => entry.run());
}

function RunActivePaletteEntry() {
  RunPaletteEntry(palette_results[palette_active_index]);
}

function FillPaletteQuery(text) {
  const { input } = GetPaletteEls();

  if (!input) {
    return;
  }

  input.value = text;
  input.focus();
  input.setSelectionRange(text.length, text.length);
  SetPaletteQuery(input.value);
}

function SetPaletteQuery(raw_text) {
  palette_results = CollectPaletteResults(raw_text);
  RenderPaletteList();
}

function OpenCommandPalette() {
  const { overlay, input } = GetPaletteEls();

  if (!overlay) {
    return;
  }

  CloseSettingsPanel();
  CloseClientsPop();
  CloseContextMenu();

  if (input) {
    input.value = "";
  }

  SetPaletteQuery("");
  overlay.classList.add("palette-overlay-visible");

  requestAnimationFrame(() => {
    if (input) {
      input.focus();
      input.setSelectionRange(0, 0);
    }
  });
}

function CloseCommandPalette() {
  const { overlay, input } = GetPaletteEls();

  if (!overlay) {
    return;
  }

  overlay.classList.remove("palette-overlay-visible");

  if (input && document.activeElement === input) {
    input.blur();
  }
}

function IsCommandPaletteOpen() {
  const { overlay } = GetPaletteEls();

  return Boolean(overlay && overlay.classList.contains("palette-overlay-visible"));
}

const PALETTE_NAV_KEYS = ["ArrowDown", "ArrowUp", "Home", "End", "PageDown", "PageUp"];

function HandlePaletteNavKey(key) {
  if (!PALETTE_NAV_KEYS.includes(key)) {
    return false;
  }

  if (key === "ArrowDown" || key === "PageDown") {
    SetPaletteActiveIndex(palette_active_index + 1);
    return true;
  }

  if (key === "ArrowUp" || key === "PageUp") {
    SetPaletteActiveIndex(palette_active_index - 1);
    return true;
  }

  if (key === "Home") {
    SetPaletteActiveIndex(0);
    return true;
  }

  SetPaletteActiveIndex(palette_results.length - 1);
  return true;
}

function SetupCommandPalette() {
  const { overlay, input, list } = GetPaletteEls();

  if (!overlay || !input || !list) {
    LogError("palette elements missing, command palette not initialised");
    return;
  }

  input.addEventListener("input", () => SetPaletteQuery(input.value));

  input.addEventListener("keydown", (event) => {
    if (HandlePaletteNavKey(event.key)) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      RunActivePaletteEntry();
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      CloseCommandPalette();
    }
  });

  overlay.addEventListener("mousedown", (event) => {
    if (event.target === overlay) {
      CloseCommandPalette();
    }
  });

  list.addEventListener("mousedown", (event) => {
    event.stopPropagation();
  });

  window.addEventListener("keydown", (event) => {
    const is_mod = event.ctrlKey || event.metaKey;

    if (is_mod && event.shiftKey && !event.altKey && event.key.toLowerCase() === "p") {
      event.preventDefault();
      event.stopPropagation();

      if (IsCommandPaletteOpen()) {
        CloseCommandPalette();
      } else {
        OpenCommandPalette();
      }

      return;
    }

    if (IsCommandPaletteOpen() && event.target !== input) {
      if (HandlePaletteNavKey(event.key)) {
        event.preventDefault();
        return;
      }

      if (event.key === "Enter") {
        event.preventDefault();
        RunActivePaletteEntry();
        return;
      }
    }

    if (event.key === "Escape" && IsCommandPaletteOpen()) {
      event.preventDefault();
      CloseCommandPalette();
    }
  });
}
