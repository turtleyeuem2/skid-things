const OPTIONS_STATE = {
  values: {},
  unknown_values: {},
};

let OPTIONS_DEFAULTS = null;

function BoolToOptionText(value) {
  return value ? "True" : "False";
}

function OptionTextToBool(raw_value) {
  return String(raw_value || "").trim().toLowerCase() === "true";
}

async function GetOptionsPath() {
  const base_dir = await GetBaseDir();
  return JoinPath(base_dir, "options.txt");
}

function SerializeOptions(values, unknown_values) {
  const lines = Object.keys(values).map((key) => `${key}=${BoolToOptionText(values[key])}`);

  for (const [key, raw_value] of Object.entries(unknown_values || {})) {
    lines.push(`${key}=${raw_value}`);
  }

  return lines.join("\n") + "\n";
}

function ParseOptionsText(raw_text) {
  const parsed = {};
  const lines = raw_text.split(/\r?\n/);

  for (const raw_line of lines) {
    const line = raw_line.trim();

    if (line.length === 0 || line.startsWith(";") || line.startsWith("#")) {
      continue;
    }

    const eq_index = line.indexOf("=");
    if (eq_index === -1) {
      continue;
    }

    const key = line.slice(0, eq_index).trim();
    const raw_value = line.slice(eq_index + 1).trim();
    parsed[key] = raw_value;
  }

  return parsed;
}

function GetOptionDefaults() {
  if (OPTIONS_DEFAULTS) {
    return OPTIONS_DEFAULTS;
  }

  const defaults = {};

  for (const page of SETTINGS_SCHEMA) {
    for (const row of page.rows) {
      if (row.is_option) {
        defaults[row.key] = Boolean(row.option_default);
      }
    }
  }

  OPTIONS_DEFAULTS = defaults;
  return OPTIONS_DEFAULTS;
}

async function LoadOptions() {
  const defaults = GetOptionDefaults();

  if (!window.__TAURI__) {
    OPTIONS_STATE.values = { ...defaults };
    return;
  }

  try {
    const options_path = await GetOptionsPath();
    const already_exists = await FsPathExists(options_path);

    if (!already_exists) {
      OPTIONS_STATE.values = { ...defaults };
      await FsWriteTextFile(options_path, SerializeOptions(OPTIONS_STATE.values));
      LogPrint(`created options.txt at ${options_path}`);
      return;
    }

    const raw_text = await FsReadTextFile(options_path);
    const parsed = ParseOptionsText(raw_text);

    OPTIONS_STATE.values = { ...defaults };
    OPTIONS_STATE.unknown_values = {};

    for (const [key, raw_value] of Object.entries(parsed)) {
      if (Object.prototype.hasOwnProperty.call(defaults, key)) {
        OPTIONS_STATE.values[key] = OptionTextToBool(raw_value);
      } else {
        OPTIONS_STATE.unknown_values[key] = raw_value;
      }
    }
  } catch (err) {
    LogError("could not load options.txt, using defaults:", err);
    OPTIONS_STATE.values = { ...defaults };
  }
}

async function SaveOptionsNow() {
  if (!window.__TAURI__) {
    return;
  }

  try {
    const options_path = await GetOptionsPath();
    await FsWriteTextFile(options_path, SerializeOptions(OPTIONS_STATE.values, OPTIONS_STATE.unknown_values));
  } catch (err) {
    LogError("could not save options.txt:", err);
  }
}

const SaveOptions = Debounce(SaveOptionsNow, 200);

function ResetOptionValues() {
  OPTIONS_STATE.values = { ...GetOptionDefaults() };
  SaveOptions();
}

function GetOption(key) {
  return Boolean(OPTIONS_STATE.values[key]);
}

function SetOption(key, value) {
  OPTIONS_STATE.values[key] = Boolean(value);
  SaveOptions();
}
