const DISCORD_JOIN_URL = "https://discord.gg/HHRtZGvm9N";
const DISCORD_DEFAULT_APP_ID = "1368946443985096785";

let discord_rpc_ready = false;

function DiscordRpcBackendAvailable() {
  return Boolean(window.__TAURI__ && window.__TAURI__.core);
}

async function DiscordRpcInvoke(command, args) {
  return window.__TAURI__.core.invoke(command, args || {});
}

async function DiscordRpcPushAppId(app_id) {
  const trimmed = String(app_id || "").trim();

  if (!trimmed) {
    return false;
  }

  if (!DiscordRpcBackendAvailable()) {
    return false;
  }

  try {
    await DiscordRpcInvoke("discord_set_app_id", { appId: trimmed });
    return true;
  } catch (err) {
    console.warn("could not configure discord rpc:", err);
    return false;
  }
}

async function DiscordRpcSetEnabled(is_on) {
  if (!DiscordRpcBackendAvailable()) {
    return false;
  }

  try {
    await DiscordRpcInvoke("discord_set_enabled", { enabled: Boolean(is_on) });
    return true;
  } catch (err) {
    console.warn("could not toggle discord rpc:", err);
    return false;
  }
}

function FormatDiscordCount(value) {
  return String(Number(value) || 0).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

async function BuildDiscordPresenceState(tab) {
  const parts = [];
  const textarea = document.getElementById("editor-input");
  let line_count = 0;

  if (typeof GetEditorLineCount === "function") {
    line_count = GetEditorLineCount();
  } else if (tab && typeof tab.content === "string") {
    line_count = tab.content.split("\n").length;
  }

  if (line_count > 0) {
    const line_label = line_count === 1 ? "line" : "lines";
    parts.push(`${FormatDiscordCount(line_count)} ${line_label}`);
  }

  if (textarea) {
    const caret = textarea.selectionStart;
    let line_index = 0;
    let line_start = 0;

    if (typeof FindLineIndexAt === "function" && typeof GetLineStartOffset === "function") {
      line_index = FindLineIndexAt(caret);
      line_start = GetLineStartOffset(line_index);
    }

    const column = caret - line_start + 1;
    parts.push(`Ln ${FormatDiscordCount(line_index + 1)}, Col ${column}`);
  }

  if (tab && tab.path && typeof FsStatPath === "function") {
    try {
      const stat = await FsStatPath(tab.path);
      const bytes = Number(stat.size) || 0;
      parts.push(typeof FormatSizeBytes === "function" ? FormatSizeBytes(bytes) : `${bytes} B`);
    } catch (stat_err) {}
  }

  return parts.join(" · ");
}

async function UpdateDiscordPresence() {
  if (!discord_rpc_ready) {
    return;
  }

  if (!UI_STATE.discord_rpc_enabled) {
    return;
  }

  const active_tab = GetActiveTab();
  let details = "Idle";
  let state_text = "";

  if (active_tab && active_tab.name) {
    details = `Editing File: ${active_tab.name}`;
    state_text = await BuildDiscordPresenceState(active_tab);
  }

  try {
    await DiscordRpcInvoke("discord_set_presence", { details, stateText: state_text });
  } catch (err) {
    console.warn("could not update discord presence:", err);
  }
}

const UpdateDiscordPresenceDebounced = Debounce(UpdateDiscordPresence, 350);

async function HandleDiscordRpcEnabledChanged(is_on) {
  const pushed = await DiscordRpcSetEnabled(is_on);

  if (pushed && is_on) {
    UpdateDiscordPresenceDebounced();
  }
}

async function HandleDiscordRpcReconnect() {
  const pushed = await DiscordRpcPushAppId(DISCORD_DEFAULT_APP_ID);

  if (!pushed) {
    Notify("Could not reach Discord", "error");
    return;
  }

  await DiscordRpcSetEnabled(UI_STATE.discord_rpc_enabled === true);

  if (UI_STATE.discord_rpc_enabled) {
    UpdateDiscordPresenceDebounced();
  }

  Notify("Discord presence reconnected", "success");
}

async function HandleJoinDiscordServer() {
  try {
    await FsOpenExternalUrl(DISCORD_JOIN_URL);
  } catch (err) {
    LogError("could not open the Discord invite:", err);
  }
}

async function SetupDiscordRpc() {
  if (!DiscordRpcBackendAvailable()) {
    discord_rpc_ready = false;
    return;
  }

  await DiscordRpcPushAppId(DISCORD_DEFAULT_APP_ID);
  await DiscordRpcSetEnabled(UI_STATE.discord_rpc_enabled === true);

  discord_rpc_ready = true;

  if (UI_STATE.discord_rpc_enabled) {
    UpdateDiscordPresenceDebounced();
  }
}