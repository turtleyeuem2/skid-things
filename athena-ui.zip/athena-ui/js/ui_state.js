const UI_THEMES = [
  { id: "dark", label: "Dark" },
  { id: "light", label: "Light" },
  { id: "retro", label: "Retro" },
  { id: "nord", label: "Nord" },
  { id: "halloween", label: "Halloween" },
  { id: "halloween-light", label: "Halloween Light" },
];

const UI_THEME_IDS = UI_THEMES.map((theme) => theme.id);

const UI_THEME_DEFAULT = UI_THEME_IDS[0];

const UI_THEME_RENAMES = {
  hexion: "dark",
  xp: "retro",
  ocean: "dark",
  gruvbox: "dark",
  solarized: "dark",
  mono: "light",
};

const UI_STATE = {
  accent_color: "#5e9eff",
  ui_theme: UI_THEME_DEFAULT,
  ui_density: "cosy",
  ui_motion: "on",
  explorer_width: 248,
  explorer_hidden: false,
  explorer_side: "left",
  console_height: 180,
  console_hidden: false,
  collapsed_sections: {},
  hidden_sections: {
    recent: true,
    favourites: true,
    tabs: true,
    autoexec: false,
    scripts: false,
  },
  pinned_scripts: [],
  pinned_tabs: [],
  pinned_favourites: [],
  editor_font_size_px: 13,
  editor_tab_size: 4,
  editor_line_height: 1.6,
  editor_caret_style: "bar",
  editor_caret_blink: true,
  editor_selection_style: "block",
  show_gutter: true,
  show_indent_guides: true,
  show_active_line: true,
  show_problems: true,
  disable_snippets: false,
  confirm_before_delete: true,
  confirm_on_close_unsaved: true,
  default_file_extension: "lua",
  console_font_size_px: 11,
  console_line_height: 1.55,
  console_wrap: false,
  console_max_lines: 2000,
  console_timestamps: true,
  console_autoscroll: true,
  console_clear_on_run: false,
  console_min_level: "all",
  console_click_to_copy: true,
  show_explorer_reveal_strip: true,
  show_console_reveal_strip: true,
  tooltip_delay_ms: 500,
  show_debug_output: true,
  palette_recents: [],
  always_on_top: false,
  restore_tabs_on_start: true,
  start_maximized: false,
  ui_font_family: "Inter",
  ui_font_weight: 400,
  editor_font_family: "JetBrains Mono",
  editor_font_weight: 500,
  console_font_family: "JetBrains Mono",
  console_font_weight: 400,
  notifications_enabled: false,
  notify_duration_info: 2400,
  notify_duration_success: 2200,
  notify_duration_warn: 3200,
  notify_duration_error: 4200,
  notify_show_script_run: true,
  notify_show_attach: true,
  notify_show_errors: true,
  console_show_script_run_prints: false,
  discord_rpc_enabled: true,
  show_explorer_file_sizes: false,
  rscripts_api_key: "",
};

const UI_STATE_RANGES = {
  editor_font_size_px: [8, 28, 1],
  editor_tab_size: [2, 8, 1],
  editor_line_height: [1.2, 2.2, 0.05],
  console_font_size_px: [8, 24, 1],
  console_line_height: [1.1, 2.4, 0.05],
  console_max_lines: [100, 20000, 100],
  explorer_width: [160, 480, 4],
  console_height: [80, 480, 4],
  tooltip_delay_ms: [0, 2000, 50],
  notify_duration_info: [500, 10000, 100],
  notify_duration_success: [500, 10000, 100],
  notify_duration_warn: [500, 15000, 100],
  notify_duration_error: [500, 20000, 100],
};

const UI_STATE_ENUMS = {
  ui_theme: UI_THEME_IDS,
  ui_density: ["cosy", "compact"],
  ui_motion: ["on", "off"],
  editor_caret_style: ["bar", "block", "underline"],
  editor_selection_style: ["block", "rounded"],
  default_file_extension: ["lua", "luau", "txt"],
  console_min_level: ["all", "info", "warn", "error"],
};

const UI_STATE_DEFAULTS = { ...UI_STATE };

function Debounce(fn, wait_ms) {
  let timeout_id = null;
  return (...args) => {
    if (timeout_id) {
      clearTimeout(timeout_id);
    }
    timeout_id = setTimeout(() => fn(...args), wait_ms);
  };
}

const INVALID_NAME_CHARS = /[\\/:*?"<>|]/g;

function SplitNameAndExt(full_name) {
  const dot_index = full_name.lastIndexOf(".");

  if (dot_index <= 0) {
    return { base: full_name, ext: "" };
  }

  return { base: full_name.slice(0, dot_index), ext: full_name.slice(dot_index) };
}

function SanitizeFileName(raw_name, fallback) {
  const trimmed = String(raw_name || "").trim();

  if (trimmed.length === 0) {
    return fallback;
  }

  return trimmed.replace(INVALID_NAME_CHARS, "_");
}

async function GetUiStatePath() {
  const base_dir = await GetBaseDir();
  const config_dir = await JoinPath(base_dir, "config");
  await EnsureFolder(config_dir);
  return JoinPath(config_dir, "ui_state.json");
}

function PruneUnknownUiStateKeys(loaded) {
  if (!loaded || typeof loaded !== "object") {
    return;
  }

  for (const key of Object.keys(loaded)) {
    if (!Object.prototype.hasOwnProperty.call(UI_STATE_DEFAULTS, key)) {
      delete UI_STATE[key];
    }
  }
}

function GetUiStateDefault(key) {
  return UI_STATE_DEFAULTS[key];
}

function ClampUiStateNumber(key, value) {
  const bounds = UI_STATE_RANGES[key];

  if (!bounds) {
    return value;
  }

  if (value === null || value === undefined || value === "") {
    return UI_STATE_DEFAULTS[key];
  }

  const parsed = Number(value);

  if (!Number.isFinite(parsed)) {
    return UI_STATE_DEFAULTS[key];
  }

  const stepped = bounds[2] ? Math.round(parsed / bounds[2]) * bounds[2] : Math.round(parsed);
  const tidy = Math.round(stepped * 1000) / 1000;
  return Math.min(bounds[1], Math.max(bounds[0], tidy));
}

function GetUiStateRangedNumber(key) {
  return ClampUiStateNumber(key, UI_STATE[key]);
}

function MigrateUiStateValues() {
  const renamed = UI_THEME_RENAMES[UI_STATE.ui_theme];

  if (renamed && UI_THEME_IDS.includes(renamed)) {
    UI_STATE.ui_theme = renamed;
  }
}

function SanitizeUiStateValues() {
  for (const [key, allowed] of Object.entries(UI_STATE_ENUMS)) {
    if (!allowed.includes(UI_STATE[key])) {
      UI_STATE[key] = UI_STATE_DEFAULTS[key];
    }
  }

  for (const key of Object.keys(UI_STATE_RANGES)) {
    UI_STATE[key] = ClampUiStateNumber(key, UI_STATE[key]);
  }

  if (!IsHexColor(UI_STATE.accent_color)) {
    UI_STATE.accent_color = UI_STATE_DEFAULTS.accent_color;
  }

  if (!Array.isArray(UI_STATE.palette_recents)) {
    UI_STATE.palette_recents = [];
  }
}

function IsHexColor(value) {
  return /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(String(value || ""));
}

function NormalizeHexColor(value) {
  const text = String(value || "").trim().toLowerCase();

  if (/^#[0-9a-f]{6}$/.test(text)) {
    return text;
  }

  if (/^#[0-9a-f]{3}$/.test(text)) {
    return `#${text[1]}${text[1]}${text[2]}${text[2]}${text[3]}${text[3]}`;
  }

  return null;
}

function HexToRgbChannels(hex_color) {
  const normalized = NormalizeHexColor(hex_color);

  if (!normalized) {
    return null;
  }

  return [
    parseInt(normalized.slice(1, 3), 16),
    parseInt(normalized.slice(3, 5), 16),
    parseInt(normalized.slice(5, 7), 16),
  ];
}

function ApplyAccentColor(hex_color) {
  const root_element = document.documentElement;
  const theme_accent_rgb = getComputedStyle(root_element).getPropertyValue("--theme-accent-rgb").trim();

  if (theme_accent_rgb && hex_color === UI_STATE_DEFAULTS.accent_color) {
    root_element.style.setProperty("--accent-rgb", theme_accent_rgb);
    return;
  }

  const channels = HexToRgbChannels(hex_color);

  if (!channels) {
    return;
  }

  root_element.style.setProperty("--accent-rgb", channels.join(" "));
}

async function LoadUiState() {
  try {
    const state_path = await GetUiStatePath();
    const already_exists = await FsPathExists(state_path);

    if (!already_exists) {
      await FsWriteTextFile(state_path, JSON.stringify(UI_STATE, null, 2));
      return;
    }

    const raw_text = await FsReadTextFile(state_path);
    const parsed = JSON.parse(raw_text);
    Object.assign(UI_STATE, parsed);
    PruneUnknownUiStateKeys(parsed);
    MigrateUiStateValues();
    SanitizeUiStateValues();
  } catch (err) {
    console.warn("could not load ui state, using defaults:", err);
  }
}

async function WriteUiStateNow() {
  try {
    const state_path = await GetUiStatePath();
    await FsWriteTextFile(state_path, JSON.stringify(UI_STATE, null, 2));
  } catch (err) {
    console.warn("could not save ui state:", err);
  }
}

const SETTINGS_EXPORT_VERSION = 1;

function BuildSettingsBundle() {
  return {
    format: "hexion-settings",
    version: SETTINGS_EXPORT_VERSION,
    exported_at: new Date().toISOString(),
    ui_state: { ...UI_STATE },
    options: { ...OPTIONS_STATE.values },
  };
}

async function WriteSettingsBundle(file_path) {
  const bundle = BuildSettingsBundle();
  await FsWriteTextFile(file_path, JSON.stringify(bundle, null, 2));
  return bundle;
}

function ParseSettingsBundle(raw_text) {
  let parsed;

  try {
    parsed = JSON.parse(raw_text);
  } catch (err) {
    throw new Error("that file is not valid json");
  }

  if (!parsed || typeof parsed !== "object" || parsed.format !== "hexion-settings") {
    throw new Error("that file is not a hexion settings export");
  }

  if (!parsed.ui_state || typeof parsed.ui_state !== "object") {
    throw new Error("that export has no ui_state block");
  }

  return parsed;
}

async function ApplySettingsBundle(bundle) {
  for (const key of Object.keys(UI_STATE)) {
    delete UI_STATE[key];
  }

  Object.assign(UI_STATE, bundle.ui_state);
  PruneUnknownUiStateKeys(bundle.ui_state);
  SanitizeUiStateValues();

  if (bundle.options && typeof bundle.options === "object") {
    const defaults = GetOptionDefaults();

    for (const key of Object.keys(OPTIONS_STATE.values)) {
      delete OPTIONS_STATE.values[key];
    }

    for (const [key, value] of Object.entries(bundle.options)) {
      if (Object.prototype.hasOwnProperty.call(defaults, key)) {
        OPTIONS_STATE.values[key] = Boolean(value);
      }
    }

    for (const [key, value] of Object.entries(defaults)) {
      if (!Object.prototype.hasOwnProperty.call(OPTIONS_STATE.values, key)) {
        OPTIONS_STATE.values[key] = value;
      }
    }
  }

  await Promise.all([WriteUiStateNow(), SaveOptionsNow()]);
}

const SaveUiState = Debounce(WriteUiStateNow, 200);

function CloneDefaultValue(value) {
  if (Array.isArray(value)) {
    return [...value];
  }

  if (value && typeof value === "object") {
    return { ...value };
  }

  return value;
}

function ResetUiStateValues() {
  for (const key of Object.keys(UI_STATE_DEFAULTS)) {
    UI_STATE[key] = CloneDefaultValue(UI_STATE_DEFAULTS[key]);
  }

  SanitizeUiStateValues();
}

function ApplyUiDensity() {
  document.documentElement.dataset.density = UI_STATE.ui_density === "compact" ? "compact" : "cosy";
  SaveUiState();
}

function ApplyUiTheme() {
  const theme = UI_STATE_ENUMS.ui_theme.includes(UI_STATE.ui_theme) ? UI_STATE.ui_theme : UI_STATE_DEFAULTS.ui_theme;
  document.documentElement.dataset.theme = theme;
  SaveUiState();
}

function SetRevealStripFlag(flag_name, is_on) {
  if (is_on) {
    document.documentElement.removeAttribute(flag_name);
    return;
  }

  document.documentElement.setAttribute(flag_name, "off");
}

function ApplyRevealStrips() {
  SetRevealStripFlag("data-explorer-strip", UI_STATE.show_explorer_reveal_strip !== false);
  SetRevealStripFlag("data-console-strip", UI_STATE.show_console_reveal_strip !== false);
}

function ApplyUiMotion() {
  document.documentElement.dataset.motion = UI_STATE.ui_motion === "off" ? "off" : "on";
  SaveUiState();
}

const PANEL_AXIS_CURSOR = {
  horizontal: "col-resize",
  vertical: "row-resize",
};

function SetupPanelResizer(handle, options) {
  if (!handle) {
    return;
  }

  const {
    axis = "horizontal",
    collapse_threshold = 0,
    cursor = PANEL_AXIS_CURSOR[axis] || "auto",
    on_collapse_start = null,
    on_collapse_end = null,
    measure = null,
    apply = null,
    commit = null,
  } = options || {};

  let is_dragging = false;
  let did_drag_past_threshold = false;

  handle.addEventListener("mousedown", (event) => {
    event.preventDefault();
    is_dragging = true;
    did_drag_past_threshold = false;
    handle.classList.add("panel-sep-active");
    document.body.style.cursor = cursor;

    if (on_collapse_start) {
      on_collapse_start();
    }
  });

  window.addEventListener("mousemove", (event) => {
    if (!is_dragging) {
      return;
    }

    const raw_size = measure(event);

    if (raw_size < collapse_threshold) {
      did_drag_past_threshold = true;
      apply(0);
      return;
    }

    did_drag_past_threshold = false;
    apply(raw_size);
  });

  window.addEventListener("mouseup", () => {
    if (!is_dragging) {
      return;
    }

    is_dragging = false;
    handle.classList.remove("panel-sep-active");
    document.body.style.cursor = "";

    if (did_drag_past_threshold) {
      if (on_collapse_end) {
        on_collapse_end();
      }
      return;
    }

    if (commit) {
      commit();
    }
  });
}
