function FsBridgeHasPlugin() {
  return Boolean(window.__TAURI__ && window.__TAURI__.fs && window.__TAURI__.core);
}

function FsBridgeHasCore() {
  return Boolean(window.__TAURI__ && window.__TAURI__.core);
}

async function FsBridgePluginOrCore(plugin_call, command, args) {
  if (FsBridgeHasPlugin()) {
    try {
      return await plugin_call();
    } catch (err) {}
  }

  if (FsBridgeHasCore()) {
    return await window.__TAURI__.core.invoke(command, args);
  }

  throw new Error("no file system backend is available");
}

async function FsWriteTextFile(path, content) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.writeTextFile(path, content),
    "write_text_file",
    { path, content }
  );
}

async function FsReadTextFile(path) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.readTextFile(path),
    "read_dropped_file",
    { path }
  );
}

async function FsPathExists(path) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.exists(path),
    "path_exists",
    { path }
  );
}

async function FsEnsureFolder(path) {
  if (FsBridgeHasPlugin()) {
    try {
      if (await window.__TAURI__.fs.exists(path)) {
        return;
      }
      await window.__TAURI__.fs.mkdir(path, { recursive: true });
      return;
    } catch (err) {}
  }

  if (FsBridgeHasCore()) {
    await window.__TAURI__.core.invoke("create_dir", { path });
    return;
  }

  throw new Error("no file system backend is available");
}

async function FsRemovePath(path) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.remove(path, { recursive: true }),
    "remove_path",
    { path }
  );
}

async function FsRenamePath(old_path, new_path) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.rename(old_path, new_path),
    "rename_path",
    { oldPath: old_path, newPath: new_path }
  );
}

async function FsReadDirEntries(path) {
  if (FsBridgeHasPlugin()) {
    try {
      return await window.__TAURI__.fs.readDir(path);
    } catch (err) {}
  }

  if (FsBridgeHasCore()) {
    const entries = await window.__TAURI__.core.invoke("read_dir_entries", { path });
    return entries.map((entry) => ({
      name: entry.name,
      isDirectory: Boolean(entry.is_dir),
      isFile: !Boolean(entry.is_dir),
      isSymlink: false,
    }));
  }

  throw new Error("no file system backend is available");
}

async function FsStatPath(path) {
  return FsBridgePluginOrCore(
    () => window.__TAURI__.fs.stat(path),
    "path_stat",
    { path }
  );
}

async function FsOpenExternalUrl(url) {
  const text = String(url || "").trim();

  if (!/^https?:\/\//.test(text)) {
    return;
  }

  if (!FsBridgeHasCore()) {
    window.open(text, "_blank", "noopener");
    return;
  }

  await window.__TAURI__.core.invoke("open_external_url", { url: text });
}