const EXPLORER_STATE = {
  base_dir: null,
  favourites: [],
  recent: [],
  expanded_folders: new Set(),
  manually_collapsed: new Set(),
  selected_path: null,
};

const EXPLORER_SECTIONS = [
  { key: "recent", label: "Recent" },
  { key: "favourites", label: "Favourites" },
  { key: "tabs", label: "Tabs" },
  { key: "autoexec", label: "Auto Execute" },
  { key: "scripts", label: "Scripts" },
];

const EXPLORER_RENDER_STATE = {
  generation: 0,
};

const EXPLORER_WATCH_STATE = {
  bound: false,
  pending: new Set(),
  timer_id: null,
};

const EXPLORER_WATCH_SETTLE_MS = 320;
const EXPLORER_WATCH_SECTIONS = {
  config: ["recent", "favourites", "tabs"],
  scripts: ["scripts"],
  autoexec: ["autoexec"],
};

const DEFAULT_EXPLORER_INI = `
[favourites]
count=0

[recent]
count=0
`;

const FILE_DRAG_STATE = {
  active: false,
  payload: null,
  highlight_el: null,
  source_el: null,
};

function GetDragBadgeEl() {
  return document.getElementById("drag-cursor-badge");
}

function SetDragBadge(mode, client_x, client_y) {
  const badge = GetDragBadgeEl();

  if (!badge) {
    return;
  }

  document.body.classList.toggle("is-file-dragging-blocked", mode === "block");
  document.body.classList.toggle("is-file-dragging-favourite", mode === "favourite");

  if (!mode) {
    badge.classList.remove("drag-cursor-badge-visible", "drag-cursor-badge-block", "drag-cursor-badge-favourite");
    badge.innerHTML = "";
    return;
  }

  badge.classList.toggle("drag-cursor-badge-block", mode === "block");
  badge.classList.toggle("drag-cursor-badge-favourite", mode === "favourite");

  if (mode === "block") {
    badge.innerHTML = IconTag("ban");
    badge.classList.add("drag-cursor-badge-visible");
  } else if (mode === "favourite") {
    badge.innerHTML = IconTag("star");
    badge.classList.add("drag-cursor-badge-visible");
  } else {
    badge.classList.remove("drag-cursor-badge-visible");
    badge.innerHTML = "";
  }

  badge.style.left = `${client_x + 12}px`;
  badge.style.top = `${client_y + 12}px`;
}

function ClearFileDragUi() {
  if (FILE_DRAG_STATE.highlight_el) {
    FILE_DRAG_STATE.highlight_el.classList.remove("explorer-drop-target", "explorer-drop-blocked");
    FILE_DRAG_STATE.highlight_el = null;
  }

  if (FILE_DRAG_STATE.source_el) {
    FILE_DRAG_STATE.source_el.classList.remove("explorer-item-dragging");
    FILE_DRAG_STATE.source_el = null;
  }

  SetDragBadge(null);
}

function EndFileDrag() {
  FILE_DRAG_STATE.active = false;
  FILE_DRAG_STATE.payload = null;
  document.body.classList.remove("is-file-dragging", "is-file-dragging-blocked", "is-file-dragging-favourite");
  ClearFileDragUi();
}

function BeginFileDrag(payload, source_el) {
  FILE_DRAG_STATE.active = true;
  FILE_DRAG_STATE.payload = payload;
  FILE_DRAG_STATE.source_el = source_el || null;
  document.body.classList.add("is-file-dragging");

  if (source_el) {
    source_el.classList.add("explorer-item-dragging");
  }
}

function ResolveDropZone(target) {
  if (!target || !target.closest) {
    return { kind: "none", el: null, path: null };
  }

  const el = target.closest("[data-drop-kind]");

  if (!el) {
    return { kind: "none", el: null, path: null };
  }

  return {
    kind: el.dataset.dropKind,
    el,
    path: el.dataset.dropPath || null,
  };
}

function ApplyDropHighlight(zone) {
  const next_el = zone.el || null;

  if (FILE_DRAG_STATE.highlight_el === next_el) {
    return;
  }

  if (FILE_DRAG_STATE.highlight_el) {
    FILE_DRAG_STATE.highlight_el.classList.remove("explorer-drop-target", "explorer-drop-blocked");
  }

  FILE_DRAG_STATE.highlight_el = next_el;

  if (!next_el) {
    return;
  }

  if (zone.kind === "blocked") {
    next_el.classList.add("explorer-drop-blocked");
  } else if (zone.kind === "folder" || zone.kind === "favourites" || zone.kind === "open-tab") {
    next_el.classList.add("explorer-drop-target");
  }
}

function HandleFileDragMove(client_x, client_y) {
  if (!FILE_DRAG_STATE.active) {
    return;
  }

  const under = document.elementFromPoint(client_x, client_y);
  const zone = ResolveDropZone(under);
  ApplyDropHighlight(zone);

  if (zone.kind === "folder") {
    SetDragBadge("move", client_x, client_y);
    return;
  }

  if (zone.kind === "open-tab") {
    const drag_payload = FILE_DRAG_STATE.payload;
    SetDragBadge(drag_payload && drag_payload.is_dir ? "block" : "move", client_x, client_y);
    return;
  }

  if (zone.kind === "favourites") {
    SetDragBadge("favourite", client_x, client_y);
    return;
  }

  if (zone.kind === "blocked") {
    SetDragBadge("block", client_x, client_y);
    return;
  }

  SetDragBadge(null, client_x, client_y);
}

async function HandleFileDragDrop(client_x, client_y) {
  const payload = FILE_DRAG_STATE.payload;
  const under = document.elementFromPoint(client_x, client_y);
  const zone = ResolveDropZone(under);

  EndFileDrag();

  if (!payload || !payload.source_path) {
    return;
  }

  if (zone.kind === "favourites") {
    const base_dir = await GetBaseDir();
    const relative_path = await GetRelativePath(base_dir, payload.source_path);
    const name = relative_path.replace(/\\/g, "/").split("/").pop();
    const already_favourite = EXPLORER_STATE.favourites.some((record) => record.path === relative_path);

    if (already_favourite) {
      return;
    }

    const confirmed = await ShowConfirmModal("Add to Favourites", `Keep "${name}" one click away?`, {
      confirm_label: "Add",
      cancel_label: "No",
      danger: false,
    });

    if (confirmed) {
      await AddFavouriteRecord({ name, path: relative_path, is_dir: Boolean(payload.is_dir) });
    }

    return;
  }

  if (zone.kind === "open-tab") {
    if (payload.is_dir) {
      return;
    }

    const name = payload.source_path.replace(/\\/g, "/").split("/").pop();
    await OpenFileTab(payload.source_path, name);
    return;
  }

  if (zone.kind === "folder" && zone.path) {
    const new_path = await MoveFileSystemEntry(payload.source_path, zone.path);

    if (new_path && new_path !== payload.source_path) {
      const file_name = new_path.replace(/\\/g, "/").split("/").pop();
      await UpdateRecordsAfterMove(payload.source_path, new_path, file_name);
      await RenderExplorerSections({ quiet: true });
    }
  }
}

function BindFileDragSource(el, payload) {
  el.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) {
      return;
    }

    const start_x = event.clientX;
    const start_y = event.clientY;
    let started = false;

    const OnMove = (move_event) => {
      const dx = move_event.clientX - start_x;
      const dy = move_event.clientY - start_y;

      if (!started) {
        if (Math.hypot(dx, dy) < 6) {
          return;
        }

        started = true;
        el.dataset.skipClick = "1";
        BeginFileDrag(payload, el);
      }

      move_event.preventDefault();
      HandleFileDragMove(move_event.clientX, move_event.clientY);
    };

    const OnUp = async (up_event) => {
      window.removeEventListener("pointermove", OnMove);
      window.removeEventListener("pointerup", OnUp);
      window.removeEventListener("pointercancel", OnUp);

      if (!started) {
        return;
      }

      await HandleFileDragDrop(up_event.clientX, up_event.clientY);
    };

    window.addEventListener("pointermove", OnMove);
    window.addEventListener("pointerup", OnUp);
    window.addEventListener("pointercancel", OnUp);
  });

  el.addEventListener(
    "click",
    (event) => {
      if (el.dataset.skipClick !== "1") {
        return;
      }

      delete el.dataset.skipClick;
      event.preventDefault();
      event.stopPropagation();
    },
    true
  );
}

function MarkBlockedChrome() {
  ["tab-bar", "tab-list", "editor-mount"].forEach((id) => {
    const el = document.getElementById(id);

    if (el) {
      MarkDropZone(el, "open-tab");
    }
  });

  const editor_area = document.querySelector(".editor-area");

  if (editor_area) {
    MarkDropZone(editor_area, "open-tab");
  }
}

function SetupFileDragController() {
  MarkBlockedChrome();
}

function ApplyExplorerSelection() {
  const selected_path = EXPLORER_STATE.selected_path;
  const rows = document.querySelectorAll("#explorer-sections .explorer-item-row");

  rows.forEach((row) => {
    row.classList.toggle("explorer-item-selected", Boolean(selected_path) && row.dataset.path === selected_path);
  });
}

function SetExplorerSelection(path) {
  EXPLORER_STATE.selected_path = path || null;
  ApplyExplorerSelection();
}

async function JoinPath(...segments) {
  try {
    return await window.__TAURI__.path.join(...segments);
  } catch (e) {
    const parts = segments.map((s) => String(s).replace(/[\\/]+$/, ""));
    return parts.join("/").replace(/\\/g, "/");
  }
}

async function GetBaseDir() {
  if (EXPLORER_STATE.base_dir) {
    return EXPLORER_STATE.base_dir;
  }
  try {
    const dir = await window.__TAURI__.core.invoke("get_base_dir");
    EXPLORER_STATE.base_dir = dir;
    return dir;
  } catch (e) {
    EXPLORER_STATE.base_dir = "";
    return "";
  }
}

async function GetRelativePath(base_dir, full_path) {
  let normalized_base = base_dir.replace(/\\/g, "/");
  let normalized_full = full_path.replace(/\\/g, "/");
  if (!normalized_base.endsWith("/")) {
    normalized_base += "/";
  }
  if (normalized_full.startsWith(normalized_base)) {
    return normalized_full.slice(normalized_base.length);
  }
  return normalized_full;
}

// Export for other modules
window.JoinPath = JoinPath;
window.GetBaseDir = GetBaseDir;
window.GetRelativePath = GetRelativePath;
window.EnsureFolder = EnsureFolder;


function GetOriginKeyFromPath(relative_path) {
  const normalized = relative_path.replace(/\\/g, "/");
  if (normalized === "scripts" || normalized.startsWith("scripts/")) {
    return "scripts";
  }
  if (normalized === "autoexec" || normalized.startsWith("autoexec/")) {
    return "autoexec";
  }
  return null;
}

async function GetUniqueFileNameInFolder(folder_path, desired_name) {
  const candidate_path = await JoinPath(folder_path, desired_name);
  let exists = false;

  try {
    exists = await FsPathExists(candidate_path);
  } catch (err) {
    exists = false;
  }

  if (!exists) {
    return desired_name;
  }

  const { base, ext } = SplitNameAndExt(desired_name);
  let suffix = 1;
  while (true) {
    const attempt_name = `${base} ${suffix}${ext}`;
    const attempt_path = await JoinPath(folder_path, attempt_name);
    let attempt_exists = false;

    try {
      attempt_exists = await FsPathExists(attempt_path);
    } catch (err) {
      attempt_exists = false;
    }

    if (!attempt_exists) {
      return attempt_name;
    }

    suffix += 1;
  }
}

async function EnsureFolder(path) {
  try {
    await FsEnsureFolder(path);
  } catch (err) {
    console.warn("could not ensure folder exists:", path, err);
  }
}

async function ReadFolderEntries(path) {
  try {
    const raw_entries = await FsReadDirEntries(path);
    const mapped = [];

    for (const entry of raw_entries) {
      const child_path = await JoinPath(path, entry.name);
      mapped.push({
        name: entry.name,
        is_dir: entry.isDirectory,
        path: child_path,
      });
    }

    mapped.sort((a, b) => {
      if (a.is_dir !== b.is_dir) {
        return a.is_dir ? -1 : 1;
      }
      return a.name.localeCompare(b.name);
    });

    return mapped;
  } catch (err) {
    console.warn("could not read folder, skipping:", path, err);
    return [];
  }
}

function EntrySignature(entries) {
  return entries.map((entry) => `${entry.is_dir ? "d" : "f"}${entry.name}`).join("|");
}

const EXPLORER_PENDING_LOADS = [];
const EXPLORER_LOAD_PASSES = 24;

async function SettleExplorerLoads() {
  let passes = 0;

  while (EXPLORER_PENDING_LOADS.length > 0 && passes < EXPLORER_LOAD_PASSES) {
    passes += 1;
    await Promise.all(EXPLORER_PENDING_LOADS.splice(0, EXPLORER_PENDING_LOADS.length));
  }

  EXPLORER_PENDING_LOADS.length = 0;
}

function TrackExplorerLoad(promise) {
  EXPLORER_PENDING_LOADS.push(promise.catch(() => {}));
}

async function CheckRecordExists(base_dir, record) {
  try {
    const full_path = await JoinPath(base_dir, record.path);
    return await FsPathExists(full_path);
  } catch (err) {
    return false;
  }
}

const ENTRY_SIZE_CACHE = new Map();

function FormatSizeBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return "0 B";
  }
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let size = bytes;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i++;
  }
  if (i === 0) {
    return `${Math.round(size)} B`;
  }
  const precision = size < 10 ? 1 : 0;
  return `${size.toFixed(precision)} ${units[i]}`;
}

function FormatEntrySize(path) {
  if (ENTRY_SIZE_CACHE.has(path)) {
    return Promise.resolve(ENTRY_SIZE_CACHE.get(path));
  }

  return FsStatPath(path).then((stat) => {
    const size_text = FormatSizeBytes(Number(stat.size) || 0);
    ENTRY_SIZE_CACHE.set(path, size_text);
    return size_text;
  }).catch(() => "");
}

function InvalidateEntrySize(path) {
  ENTRY_SIZE_CACHE.delete(path);
}

function InvalidateAllEntrySizes() {
  ENTRY_SIZE_CACHE.clear();
}

function ShowPromptModal(title, placeholder, default_value) {
  return new Promise((resolve) => {
    const modal = document.getElementById("prompt-modal");
    const title_el = document.getElementById("prompt-modal-title");
    const input_el = document.getElementById("prompt-modal-input");
    const cancel_btn = document.getElementById("prompt-modal-cancel");
    const confirm_btn = document.getElementById("prompt-modal-confirm");

    if (!modal || !title_el || !input_el || !cancel_btn || !confirm_btn) {
      resolve(null);
      return;
    }

    title_el.textContent = title;
    input_el.placeholder = placeholder || "";
    input_el.value = default_value || "";
    modal.classList.add("modal-visible");
    input_el.focus();
    input_el.select();

    const Cleanup = (result) => {
      modal.classList.remove("modal-visible");
      cancel_btn.removeEventListener("click", OnCancel);
      confirm_btn.removeEventListener("click", OnConfirm);
      input_el.removeEventListener("keydown", OnKeyDown);
      resolve(result);
    };

    const OnConfirm = () => {
      const value = input_el.value.trim();
      Cleanup(value.length > 0 ? value : null);
    };

    const OnCancel = () => Cleanup(null);
    const OnKeyDown = (event) => {
      if (event.key === "Enter") {
        OnConfirm();
      }
      if (event.key === "Escape") {
        OnCancel();
      }
    };

    cancel_btn.addEventListener("click", OnCancel);
    confirm_btn.addEventListener("click", OnConfirm);
    input_el.addEventListener("keydown", OnKeyDown);
  });
}

async function MoveFileSystemEntry(source_path, target_folder_path) {
  const normalized_source = source_path.replace(/\\/g, "/");
  const normalized_target_folder = target_folder_path.replace(/\\/g, "/");
  const file_name = normalized_source.split("/").pop();

  const source_parent = normalized_source.slice(0, normalized_source.lastIndexOf("/"));
  if (source_parent === normalized_target_folder.replace(/\/$/, "")) {
    return source_path;
  }

  if (normalized_target_folder === normalized_source || normalized_target_folder.startsWith(`${normalized_source}/`)) {
    LogWarn("a folder cannot be moved into itself");
    return null;
  }

  const unique_name = await GetUniqueFileNameInFolder(target_folder_path, file_name);
  const new_path = await JoinPath(target_folder_path, unique_name);

  try {
    await FsRenamePath(source_path, new_path);
    InvalidateEntrySize(source_path);
    InvalidateEntrySize(new_path);
    return new_path;
  } catch (err) {
    LogWarn(`could not move ${file_name}: ${err && err.message ? err.message : err}`);
    return null;
  }
}

async function BuildIniText(favourites, recent) {
  let text = "";
  text += "[favourites]\n";
  text += `count=${favourites.length}\n\n`;

  favourites.forEach((record, index) => {
    text += `[favourite.${index}]\nname=${record.name}\npath=${record.path}\nis_dir=${record.is_dir ? "true" : "false"}\n\n`;
  });

  text += "[recent]\n";
  text += `count=${recent.length}\n\n`;

  recent.forEach((record, index) => {
    text += `[recent.${index}]\nname=${record.name}\npath=${record.path}\n\n`;
  });

  return text;
}

async function WriteExplorerIniNow() {
  const base_dir = await GetBaseDir();
  const ini_path = await JoinPath(base_dir, "config", "explorer.ini");
  const ini_text = await BuildIniText(EXPLORER_STATE.favourites, EXPLORER_STATE.recent);
  try {
    await FsWriteTextFile(ini_path, ini_text);
  } catch (err) {
    LogWarn("could not save explorer.ini:", err);
  }
}

const SaveExplorerIni = Debounce(WriteExplorerIniNow, 150);

async function AddFavouriteRecord(record) {
  const already_exists = EXPLORER_STATE.favourites.some((fav) => fav.path === record.path);

  if (!already_exists) {
    EXPLORER_STATE.favourites.push(record);
    await SaveExplorerIni();
  }

  await RenderExplorerSections();
}

async function RemoveFavouriteRecord(path) {
  EXPLORER_STATE.favourites = EXPLORER_STATE.favourites.filter((record) => record.path !== path);
  await SaveExplorerIni();
  await RenderExplorerSections({ quiet: true });
}

async function AddRecentRecord(record) {
  EXPLORER_STATE.recent = EXPLORER_STATE.recent.filter((entry) => entry.path !== record.path);
  EXPLORER_STATE.recent.unshift(record);

  if (EXPLORER_STATE.recent.length > 40) {
    EXPLORER_STATE.recent.length = 40;
  }

  await SaveExplorerIni();
  await RenderExplorerSections({ quiet: true });
}

async function RemoveRecentRecord(path) {
  EXPLORER_STATE.recent = EXPLORER_STATE.recent.filter((record) => record.path !== path);
  await SaveExplorerIni();
  await RenderExplorerSections({ quiet: true });
}

function ExtractIniRecords(ini_data, list_section, item_prefix) {
  const section = ini_data[list_section];
  if (!section) {
    return [];
  }

  const count = parseInt(section.count || "0", 10);
  const records = [];

  for (let index = 0; index < count; index += 1) {
    const entry = ini_data[`${item_prefix}.${index}`];
    if (entry && entry.path) {
      records.push({
        name: entry.name || entry.path,
        path: entry.path,
        is_dir: entry.is_dir === "true",
      });
    }
  }

  return records;
}

async function LoadExplorerConfig() {
  const base_dir = await GetBaseDir();
  const config_dir = await JoinPath(base_dir, "config");
  await EnsureFolder(config_dir);

  const ini_path = await JoinPath(config_dir, "explorer.ini");
  let ini_text = DEFAULT_EXPLORER_INI;

  try {
    const ini_exists = await FsPathExists(ini_path);

    if (!ini_exists) {
      await FsWriteTextFile(ini_path, DEFAULT_EXPLORER_INI);
    }

    ini_text = await FsReadTextFile(ini_path);
  } catch (err) {
    console.warn("explorer.ini missing or unreadable, falling back to defaults:", err);
    ini_text = DEFAULT_EXPLORER_INI;
  }

  const ini_data = ParseIni(ini_text);
  EXPLORER_STATE.favourites = ExtractIniRecords(ini_data, "favourites", "favourite");
  EXPLORER_STATE.recent = ExtractIniRecords(ini_data, "recent", "recent");
}

async function UpdateRecordsAfterMove(old_full_path, new_full_path, new_name) {
  const base_dir = await GetBaseDir();
  const old_relative = await GetRelativePath(base_dir, old_full_path);
  const new_relative = await GetRelativePath(base_dir, new_full_path);

  EXPLORER_STATE.favourites.forEach((record) => {
    if (record.path === old_relative) {
      record.path = new_relative;
      record.name = new_name;
    }
  });

  EXPLORER_STATE.recent.forEach((record) => {
    if (record.path === old_relative) {
      record.path = new_relative;
      record.name = new_name;
    }
  });

  const pin_index = UI_STATE.pinned_scripts.indexOf(old_full_path);

  if (pin_index !== -1) {
    UI_STATE.pinned_scripts[pin_index] = new_full_path;
  }

  const tab_pin_index = UI_STATE.pinned_tabs.indexOf(old_full_path);

  if (tab_pin_index !== -1) {
    UI_STATE.pinned_tabs[tab_pin_index] = new_full_path;
  }

  RenameOpenTab(old_full_path, new_full_path, new_name);

  await SaveExplorerIni();
  SaveUiState();
}

async function RemoveRecordsForPath(full_path) {
  const pin_index = UI_STATE.pinned_scripts.indexOf(full_path);
  if (pin_index !== -1) {
    UI_STATE.pinned_scripts.splice(pin_index, 1);
    SaveUiState();
  }
}

function GetDefaultFileExtension() {
  const ext = UI_STATE.default_file_extension;
  return UI_STATE_ENUMS.default_file_extension.includes(ext) ? ext : UI_STATE_ENUMS.default_file_extension[0];
}

function EnsureFileExtension(raw_name, fallback_name) {
  const trimmed = String(raw_name || "").trim();

  if (trimmed.length === 0) {
    return fallback_name || "";
  }

  if (trimmed.startsWith(".")) {
    return trimmed;
  }

  return SplitNameAndExt(trimmed).ext ? trimmed : `${trimmed}.${GetDefaultFileExtension()}`;
}

async function HandleAddFile(target_path) {
  const raw_name = await ShowPromptModal("New file", `name.${GetDefaultFileExtension()}`, "");

  if (!raw_name) {
    return;
  }

  const clean_name = SanitizeFileName(EnsureFileExtension(raw_name, "New File"), "New File");
  const unique_name = await GetUniqueFileNameInFolder(target_path, clean_name);
  const file_path = await JoinPath(target_path, unique_name);

  try {
    await FsWriteTextFile(file_path, "");
    InvalidateEntrySize(file_path);
  } catch (err) {
    LogWarn(`could not create ${unique_name}: ${err && err.message ? err.message : err}`);
    return;
  }

  await RenderExplorerSections();
}

async function HandleAddFolder(target_path) {
  const raw_name = await ShowPromptModal("New folder", "folder name", "");

  if (!raw_name) {
    return;
  }

  const clean_name = SanitizeFileName(raw_name, "New Folder");
  const unique_name = await GetUniqueFileNameInFolder(target_path, clean_name);
  const folder_path = await JoinPath(target_path, unique_name);

  await EnsureFolder(folder_path);
  await RenderExplorerSections();
}

async function HandleRenameEntry(entry) {
  const raw_name = await ShowPromptModal(`Rename ${entry.name}`, "new name", entry.name);

  if (!raw_name) {
    return;
  }

  const clean_name = SanitizeFileName(raw_name, "New File");

  if (clean_name === entry.name) {
    return;
  }

  const normalized_path = entry.path.replace(/\\/g, "/");
  const parent_path = normalized_path.slice(0, normalized_path.lastIndexOf("/"));
  const unique_name = await GetUniqueFileNameInFolder(parent_path, clean_name);
  const new_path = await JoinPath(parent_path, unique_name);

  try {
    await FsRenamePath(entry.path, new_path);
    InvalidateEntrySize(entry.path);
    InvalidateEntrySize(new_path);
  } catch (err) {
    LogWarn(`could not rename ${entry.name}: ${err && err.message ? err.message : err}`);
    return;
  }

  await UpdateRecordsAfterMove(entry.path, new_path, unique_name);
  await RenderExplorerSections({ quiet: true });
}

async function HandleDeleteEntry(entry) {
  if (UI_STATE.confirm_before_delete !== false) {
    const confirmed = await ShowConfirmModal("Delete?", `"${entry.name}" will be permanently deleted.`, {
      confirm_label: "Delete",
    });

    if (!confirmed) {
      return;
    }
  }

  try {
    await FsRemovePath(entry.path);
    InvalidateEntrySize(entry.path);
  } catch (err) {
    LogWarn(`could not delete ${entry.name}: ${err && err.message ? err.message : err}`);
    return;
  }

  await RemoveRecordsForPath(entry.path);
  await RenderExplorerSections({ quiet: true });
}

async function HandleMoveEntry(entry, origin_key) {
  const base_dir = await GetBaseDir();
  const target_folder_name = origin_key === "scripts" ? "autoexec" : "scripts";
  const target_folder = await JoinPath(base_dir, target_folder_name);

  const new_path = await MoveFileSystemEntry(entry.path, target_folder);
  if (!new_path) {
    return;
  }

  const moved_name = new_path.replace(/\\/g, "/").split("/").pop();
  await UpdateRecordsAfterMove(entry.path, new_path, moved_name);
  await RenderExplorerSections({ quiet: true });
}

async function HandleTogglePinEntry(entry) {
  const index = UI_STATE.pinned_scripts.indexOf(entry.path);

  if (index === -1) {
    UI_STATE.pinned_scripts.push(entry.path);
  } else {
    UI_STATE.pinned_scripts.splice(index, 1);
  }

  SaveUiState();
  await RenderExplorerSections({ quiet: true });
}

async function HandleToggleFavouritePin(record_path) {
  const index = UI_STATE.pinned_favourites.indexOf(record_path);

  if (index === -1) {
    UI_STATE.pinned_favourites.push(record_path);
  } else {
    UI_STATE.pinned_favourites.splice(index, 1);
  }

  SaveUiState();
  await RenderExplorerSections({ quiet: true });
}

async function HandleAddEntryToFavourites(entry) {
  const base_dir = await GetBaseDir();
  const relative_path = await GetRelativePath(base_dir, entry.path);
  await AddFavouriteRecord({ name: entry.name, path: relative_path, is_dir: entry.is_dir });
}

async function HandleExplorerFileClick(entry) {
  SetExplorerSelection(entry.path);

  await OpenFileTab(entry.path, entry.name);

  const base_dir = await GetBaseDir();
  const relative_path = await GetRelativePath(base_dir, entry.path);
  await AddRecentRecord({ name: entry.name, path: relative_path });
}

async function HandleRunScript(entry) {
  let source = "";
  const open_tab = TABS_STATE.tabs.find((tab) => tab.file_path === entry.path);

  if (open_tab) {
    source = open_tab.content;
  } else if (window.__TAURI__) {
    try {
      source = await FsReadTextFile(entry.path);
    } catch (err) {
      LogWarn(`could not read ${entry.name}: ${err && err.message ? err.message : err}`);
    }
  }

  try {
    await ExecuteScript(source, entry.name);
  } catch (err) {
    LogError(`run failed: ${err && err.message ? err.message : err}`);
  }
}

function ShowExplorerEntryContextMenu(event, entry, origin_key, options) {
  const items = [];

  if (!entry.is_dir) {
    items.push({ label: "Run", icon_name: "run", on_click: () => HandleRunScript(entry) });
  }

  if (entry.is_dir) {
    items.push({ label: "New file", icon_name: "file", on_click: () => HandleAddFile(entry.path) });
    items.push({ label: "New folder", icon_name: "folder", on_click: () => HandleAddFolder(entry.path) });
    items.push({ separator: true });
  }

  items.push({ label: "Rename", icon_name: "pencil", on_click: () => HandleRenameEntry(entry) });

  if (options.is_top_level_favourite) {
    const is_pinned = UI_STATE.pinned_favourites.includes(options.record_path);
    items.push({
      label: is_pinned ? "Unpin" : "Pin",
      icon_name: "pin",
      on_click: () => HandleToggleFavouritePin(options.record_path),
    });
  } else if (origin_key === "scripts" || origin_key === "autoexec") {
    const is_pinned = UI_STATE.pinned_scripts.includes(entry.path);
    items.push({
      label: is_pinned ? "Unpin" : "Pin",
      icon_name: "pin",
      on_click: () => HandleTogglePinEntry(entry),
    });
  }

  if (options.is_top_level_favourite) {
    items.push({ label: "Remove from Favourites", icon_name: "staroff_gold", on_click: () => RemoveFavouriteRecord(options.record_path) });
  } else {
    items.push({ label: "Add to Favourites", icon_name: "star_gold", on_click: () => HandleAddEntryToFavourites(entry) });
  }

  if (origin_key === "scripts" || origin_key === "autoexec") {
    items.push({
      label: origin_key === "scripts" ? "Move to AutoExec" : "Move to Scripts",
      icon_name: "move",
      on_click: () => HandleMoveEntry(entry, origin_key),
    });
  }

  items.push({ separator: true });
  items.push({ label: "Reveal in file manager", icon_name: "folderopen", on_click: () => RevealPathInFileManager(entry.path) });
  items.push({ label: "Delete", icon_name: "trash", danger: true, on_click: () => HandleDeleteEntry(entry) });

  ShowContextMenu(event.clientX, event.clientY, items);
}

function MarkDropZone(el, kind, path) {
  el.dataset.dropKind = kind;

  if (path) {
    el.dataset.dropPath = path;
  } else {
    delete el.dataset.dropPath;
  }
}

function BuildExplorerActionBtn(icon_name, tooltip, on_click) {
  const btn = document.createElement("button");
  btn.className = "explorer-icon-btn";
  btn.dataset.tooltip = tooltip;
  btn.innerHTML = IconTag(icon_name);
  btn.addEventListener("click", (event) => {
    event.stopPropagation();
    on_click();
  });

  return btn;
}

function BuildExplorerChevron(is_hidden) {
  const chevron = document.createElement("span");
  chevron.className = "explorer-item-chevron";
  chevron.innerHTML = IconTag("chevronright");

  if (is_hidden) {
    chevron.style.visibility = "hidden";
  }

  return chevron;
}

function BuildExplorerItem(entry, origin_key, options) {
  const resolved_options = options || {};

  const depth = Number(resolved_options.depth) || 0;
  const show_details = !resolved_options.is_favourite_view;

  const item = document.createElement("div");
  item.className = "explorer-item" + (entry.is_dir ? " explorer-item-folder" : "");
  item.dataset.name = entry.name.toLowerCase();
  item.dataset.sig = entry.is_dir ? "" : `f${entry.name}`;
  item.style.setProperty("--explorer-depth", String(depth));

  const row = document.createElement("div");
  row.className = "explorer-item-row";
  row.dataset.path = entry.path;
  row.dataset.tooltip = entry.path;
  row.style.setProperty("--explorer-depth", String(depth));

  const is_pinned = resolved_options.is_top_level_favourite
    ? UI_STATE.pinned_favourites.includes(resolved_options.record_path)
    : (origin_key === "scripts" || origin_key === "autoexec") && UI_STATE.pinned_scripts.includes(entry.path);

  row.appendChild(BuildExplorerChevron(!entry.is_dir));

  if (is_pinned) {
    const pin_wrap = document.createElement("span");
    pin_wrap.className = "explorer-item-pin";
    pin_wrap.innerHTML = IconTag("pin");
    row.appendChild(pin_wrap);
  }

  const icon_wrap = document.createElement("span");
  icon_wrap.className = "explorer-item-icon";
  icon_wrap.innerHTML = entry.is_dir ? CreateFolderIconSvg() : CreateFileIconSvg(entry.name);
  row.appendChild(icon_wrap);

  const label = document.createElement("span");
  label.className = "explorer-item-label";
  label.textContent = entry.name;
  row.appendChild(label);

  if (resolved_options.is_top_level_favourite) {
    const star_wrap = document.createElement("span");
    star_wrap.className = "explorer-item-favourite";
    star_wrap.innerHTML = CreateStarIconSvg();
    row.appendChild(star_wrap);
  }

  const show_file_sizes = UI_STATE.show_explorer_file_sizes && show_details && !entry.is_dir;
  if (show_file_sizes) {
    const size_wrap = document.createElement("span");
    size_wrap.className = "explorer-item-size";
    row.appendChild(size_wrap);

    FormatEntrySize(entry.path).then((size_text) => {
      if (size_text && row.contains(size_wrap)) {
        size_wrap.textContent = size_text;
      }
    });
  }

  if (show_details) {
    const actions = document.createElement("span");
    actions.className = "explorer-item-actions";

    if (!entry.is_dir) {
      actions.appendChild(BuildExplorerActionBtn("run", "Run", () => HandleRunScript(entry)));
    }

    actions.appendChild(BuildExplorerActionBtn("star", "Favourite", () => HandleAddEntryToFavourites(entry)));

    row.appendChild(actions);
  }

  item.appendChild(row);

  BindFileDragSource(row, { source_path: entry.path, is_dir: entry.is_dir });

  row.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();
    ShowExplorerEntryContextMenu(event, entry, origin_key, resolved_options);
  });

  if (!entry.is_dir) {
    row.addEventListener("click", () => HandleExplorerFileClick(entry));

    if (show_details) {
      MarkDropZone(row, "folder", entry.path.replace(/\\/g, "/").split("/").slice(0, -1).join("/"));
    }

    return item;
  }

  const children_wrap = document.createElement("div");
  children_wrap.className = "explorer-item-children";
  item.appendChild(children_wrap);

  let is_expanded =
    EXPLORER_STATE.expanded_folders.has(entry.path) ||
    (Boolean(resolved_options.force_expanded) && !EXPLORER_STATE.manually_collapsed.has(entry.path));
  let has_loaded = false;

  async function LoadChildren() {
    const child_entries = await ReadFolderEntries(entry.path);
    item.dataset.sig = EntrySignature(child_entries);

    if (!is_expanded) {
      return;
    }

    children_wrap.innerHTML = "";

    if (child_entries.length === 0) {
      const empty_label = document.createElement("span");
      empty_label.className = "explorer-empty";
      empty_label.textContent = "Empty";
      children_wrap.appendChild(empty_label);
      return;
    }

    const child_options = {
      is_favourite_view: resolved_options.is_favourite_view,
      depth: depth + 1,
    };

    for (const child of child_entries) {
      children_wrap.appendChild(BuildExplorerItem(child, origin_key, child_options));
    }
  }

  function QueueChildrenLoad() {
    has_loaded = true;
    TrackExplorerLoad(LoadChildren());
  }

  if (is_expanded) {
    icon_wrap.innerHTML = CreateFolderOpenIconSvg();
    QueueChildrenLoad();
  } else {
    item.classList.add("explorer-item-collapsed");
  }

  row.addEventListener("click", async (event) => {
    event.stopPropagation();
    SetExplorerSelection(entry.path);
    is_expanded = !is_expanded;

    if (is_expanded) {
      EXPLORER_STATE.expanded_folders.add(entry.path);
      EXPLORER_STATE.manually_collapsed.delete(entry.path);
    } else {
      EXPLORER_STATE.expanded_folders.delete(entry.path);
      item.dataset.sig = "";
      children_wrap.innerHTML = "";
      has_loaded = false;

      if (resolved_options.force_expanded) {
        EXPLORER_STATE.manually_collapsed.add(entry.path);
      }
    }

    item.classList.toggle("explorer-item-collapsed", !is_expanded);
    icon_wrap.innerHTML = is_expanded ? CreateFolderOpenIconSvg() : CreateFolderIconSvg();

    if (is_expanded && !has_loaded) {
      QueueChildrenLoad();
      await SettleExplorerLoads();
    }
  });

  if (show_details) {
    MarkDropZone(row, "folder", entry.path);
  }

  return item;
}

function BuildMissingFavouriteItem(record, full_path) {
  const item = document.createElement("div");
  item.className = "explorer-item";
  item.dataset.name = record.name.toLowerCase();
  item.dataset.sig = `gone${record.path}`;

  const row = document.createElement("div");
  row.className = "explorer-item-row explorer-item-missing";
  row.dataset.path = full_path || record.path;
  row.dataset.tooltip = `${record.path} could not be found`;

  row.appendChild(BuildExplorerChevron(true));

  const icon_wrap = document.createElement("span");
  icon_wrap.className = "explorer-item-icon";
  icon_wrap.innerHTML = record.is_dir ? CreateFolderIconSvg() : CreateFileIconSvg(record.name);
  row.appendChild(icon_wrap);

  const label = document.createElement("span");
  label.className = "explorer-item-label";
  label.textContent = record.name;
  row.appendChild(label);

  const star_wrap = document.createElement("span");
  star_wrap.className = "explorer-item-favourite";
  star_wrap.innerHTML = CreateStarIconSvg();
  row.appendChild(star_wrap);

  item.appendChild(row);

  row.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();

    ShowContextMenu(event.clientX, event.clientY, [
      { label: "Remove from Favourites", icon_name: "staroff_gold", on_click: () => RemoveFavouriteRecord(record.path) },
    ]);
  });

  return item;
}

function BuildMissingRecentItem(record, full_path) {
  const item = document.createElement("div");
  item.className = "explorer-item";
  item.dataset.name = record.name.toLowerCase();
  item.dataset.sig = `gone${record.path}`;

  const row = document.createElement("div");
  row.className = "explorer-item-row explorer-item-missing";
  row.dataset.path = full_path || record.path;
  row.dataset.tooltip = `${record.path} could not be found`;

  row.appendChild(BuildExplorerChevron(true));

  const icon_wrap = document.createElement("span");
  icon_wrap.className = "explorer-item-icon";
  icon_wrap.innerHTML = CreateFileIconSvg(record.name);
  row.appendChild(icon_wrap);

  const label = document.createElement("span");
  label.className = "explorer-item-label";
  label.textContent = record.name;
  row.appendChild(label);

  item.appendChild(row);

  row.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();

    ShowContextMenu(event.clientX, event.clientY, [
      { label: "Remove from Recent", icon_name: "history", on_click: () => RemoveRecentRecord(record.path) },
    ]);
  });

  return item;
}

function BuildRecentItem(record, full_path) {
  const item = document.createElement("div");
  item.className = "explorer-item";
  item.dataset.name = record.name.toLowerCase();
  item.dataset.sig = `r${record.path}`;

  const row = document.createElement("div");
  row.className = "explorer-item-row";
  row.dataset.path = full_path;
  row.dataset.tooltip = record.path;

  row.appendChild(BuildExplorerChevron(true));

  const icon_wrap = document.createElement("span");
  icon_wrap.className = "explorer-item-icon";
  icon_wrap.innerHTML = CreateFileIconSvg(record.name);
  row.appendChild(icon_wrap);

  const label = document.createElement("span");
  label.className = "explorer-item-label";
  label.textContent = record.name;
  row.appendChild(label);

  item.appendChild(row);

  BindFileDragSource(row, { source_path: full_path, is_dir: false });

  row.addEventListener("click", async () => {
    const base_dir = await GetBaseDir();
    const resolved_path = await JoinPath(base_dir, record.path);
    await HandleExplorerFileClick({ name: record.name, path: resolved_path });
  });

  row.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();

    ShowContextMenu(event.clientX, event.clientY, [
      { label: "Run", icon_name: "run", on_click: () => HandleRunScript({ name: record.name, path: full_path, is_dir: false }) },
      { label: "Pin", icon_name: "pin", on_click: () => HandleTogglePinEntry({ name: record.name, path: full_path, is_dir: false }) },
      { separator: true },
      { label: "Remove from Recent", icon_name: "history", on_click: () => RemoveRecentRecord(record.path) },
    ]);
  });

  return item;
}

function BuildSectionHeader(key, label, section_el, target_path, options) {
  const resolved_options = options || {};
  const extra_actions = resolved_options.extra_actions || [];

  const header = document.createElement("div");
  header.className = "explorer-section-header";

  const chevron = document.createElement("span");
  chevron.className = "explorer-chevron";
  chevron.innerHTML = IconTag("chevronright");
  header.appendChild(chevron);

  const label_el = document.createElement("span");
  label_el.className = "explorer-section-label";
  label_el.textContent = label;
  header.appendChild(label_el);

  if (extra_actions.length > 0) {
    const actions = document.createElement("span");
    actions.className = "explorer-section-actions";

    for (const action of extra_actions) {
      actions.appendChild(BuildExplorerActionBtn(action.icon_name, action.tooltip, action.on_click));
    }

    header.appendChild(actions);
  }

  header.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();

    const items = [];

    if (target_path) {
      items.push({ label: "New file", icon_name: "file", on_click: () => HandleAddFile(target_path) });
      items.push({ label: "New folder", icon_name: "folder", on_click: () => HandleAddFolder(target_path) });
      items.push({ separator: true });
    }

    if (resolved_options.context_menu_items && resolved_options.context_menu_items.length > 0) {
      items.push(...resolved_options.context_menu_items);
      items.push({ separator: true });
    }

    items.push({ label: "Hide section", icon_name: "eyeoff", on_click: () => SetSectionHidden(key, true) });

    ShowContextMenu(event.clientX, event.clientY, items);
  });

  header.addEventListener("click", () => {
    UI_STATE.collapsed_sections[key] = !UI_STATE.collapsed_sections[key];
    section_el.classList.toggle("explorer-section-collapsed", UI_STATE.collapsed_sections[key]);
    SaveUiState();
  });

  return header;
}

async function SetSectionHidden(key, hidden) {
  UI_STATE.hidden_sections[key] = hidden;
  SaveUiState();
  await RenderExplorerSections({ quiet: true });
}

function BuildExplorerSectionMenuItems() {
  const items = EXPLORER_SECTIONS.map((section) => {
    const is_hidden = Boolean(UI_STATE.hidden_sections[section.key]);

    return {
      label: section.label,
      checkbox: true,
      checked: !is_hidden,
      on_click: () => SetSectionHidden(section.key, !is_hidden),
    };
  });

  items.push({ separator: true });
  items.push({ label: "Reload from disk", icon_name: "refresh", on_click: () => RefreshExplorerFromDisk() });

  return items;
}

function ShowExplorerSectionMenu(event) {
  event.preventDefault();
  event.stopPropagation();
  ShowContextMenu(event.clientX, event.clientY, BuildExplorerSectionMenuItems());
}

async function HandleClearAllHistory() {
  if (EXPLORER_STATE.recent.length === 0) {
    return;
  }

  const confirmed = await ShowConfirmModal(
    "Clear all history?",
    "This will remove every entry from Recent. This can't be undone.",
    { confirm_label: "Clear All", cancel_label: "Cancel", danger: true }
  );

  if (!confirmed) {
    return;
  }

  EXPLORER_STATE.recent = [];
  await SaveExplorerIni();
  await RenderExplorerSections({ quiet: true });
}

function SortPinnedEntries(entries, pinned_paths) {
  if (pinned_paths.length === 0) {
    return entries;
  }

  return [...entries].sort((a, b) => {
    const a_pinned = pinned_paths.includes(a.path);
    const b_pinned = pinned_paths.includes(b.path);

    if (a_pinned !== b_pinned) {
      return a_pinned ? -1 : 1;
    }

    if (a.is_dir !== b.is_dir) {
      return a.is_dir ? -1 : 1;
    }

    return a.name.localeCompare(b.name);
  });
}

function BuildSectionShell(key, drop_kind, drop_path) {
  const section = document.createElement("div");
  section.className = "explorer-section";
  MarkDropZone(section, drop_kind, drop_path);

  if (UI_STATE.collapsed_sections[key]) {
    section.classList.add("explorer-section-collapsed");
  }

  return section;
}

function BuildSectionBody(drop_kind, drop_path) {
  const body = document.createElement("div");
  body.className = "explorer-section-body";
  MarkDropZone(body, drop_kind, drop_path);
  return body;
}

function BuildSectionEmptyLabel(text) {
  const empty_label = document.createElement("span");
  empty_label.className = "explorer-empty";
  empty_label.textContent = text;
  return empty_label;
}

async function BuildFolderSection(key, label, folder_name) {
  const base_dir = await GetBaseDir();
  const folder_path = await JoinPath(base_dir, folder_name);
  await EnsureFolder(folder_path);
  const raw_entries = await ReadFolderEntries(folder_path);
  const entries = SortPinnedEntries(raw_entries, UI_STATE.pinned_scripts);

  const section = BuildSectionShell(key, "folder", folder_path);
  section.appendChild(BuildSectionHeader(key, label, section, folder_path, {}));

  const body = BuildSectionBody("folder", folder_path);

  if (entries.length === 0) {
    body.appendChild(BuildSectionEmptyLabel("Drop a file here or make one"));
  } else {
    for (const entry of entries) {
      body.appendChild(BuildExplorerItem(entry, key, {}));
    }
  }

  section.appendChild(body);
  return section;
}

async function BuildFavouritesSection() {
  const base_dir = await GetBaseDir();

  const section = BuildSectionShell("favourites", "favourites", null);
  section.appendChild(
    BuildSectionHeader("favourites", "Favourites", section, null, {
      context_menu_items:
        EXPLORER_STATE.favourites.length > 0
          ? [{ label: "Remove every favourite", icon_name: "trash", danger: true, on_click: () => ClearAllFavourites() }]
          : [],
    })
  );

  const body = BuildSectionBody("favourites", null);

  if (EXPLORER_STATE.favourites.length === 0) {
    body.appendChild(BuildSectionEmptyLabel("Star anything to keep it here"));
  }

  const ordered_favourites = SortPinnedEntries(EXPLORER_STATE.favourites, UI_STATE.pinned_favourites);

  for (const record of ordered_favourites) {
    const exists = await CheckRecordExists(base_dir, record);
    const full_path = await JoinPath(base_dir, record.path);

    if (!exists) {
      body.appendChild(BuildMissingFavouriteItem(record, full_path));
      continue;
    }

    const origin_key = GetOriginKeyFromPath(record.path);
    const entry = { name: record.name, is_dir: record.is_dir, path: full_path };
    const options = {
      is_favourite_view: true,
      is_top_level_favourite: true,
      force_expanded: record.is_dir,
      record_path: record.path,
    };

    body.appendChild(BuildExplorerItem(entry, origin_key, options));
  }

  section.appendChild(body);
  return section;
}

async function ClearAllFavourites() {
  if (EXPLORER_STATE.favourites.length === 0) {
    return;
  }

  const confirmed = await ShowConfirmModal(
    "Remove every favourite?",
    "The files stay on disk, only the list is cleared.",
    { confirm_label: "Remove All", cancel_label: "Cancel", danger: true }
  );

  if (!confirmed) {
    return;
  }

  EXPLORER_STATE.favourites = [];
  UI_STATE.pinned_favourites = [];
  SaveUiState();
  await SaveExplorerIni();
  await RenderExplorerSections({ quiet: true });
}

async function BuildRecentSection() {
  const base_dir = await GetBaseDir();
  const has_history = EXPLORER_STATE.recent.length > 0;

  const section = BuildSectionShell("recent", "blocked", null);
  section.appendChild(
    BuildSectionHeader("recent", "Recent", section, null, {
      extra_actions: has_history
        ? [{ icon_name: "trash", tooltip: "Clear all history", on_click: () => HandleClearAllHistory() }]
        : [],
      context_menu_items: has_history
        ? [{ label: "Clear all history", icon_name: "trash", danger: true, on_click: () => HandleClearAllHistory() }]
        : [],
    })
  );

  const body = BuildSectionBody("blocked", null);

  if (!has_history) {
    body.appendChild(BuildSectionEmptyLabel("Files you open show up here"));
  }

  for (const record of EXPLORER_STATE.recent) {
    const exists = await CheckRecordExists(base_dir, record);
    const full_path = await JoinPath(base_dir, record.path);
    body.appendChild(exists ? BuildRecentItem(record, full_path) : BuildMissingRecentItem(record, full_path));
  }

  section.appendChild(body);
  return section;
}

function BuildTabExplorerItem(tab) {
  const is_active = tab.id === TABS_STATE.active_id;
  const item = document.createElement("div");
  item.className = "explorer-item";
  item.dataset.name = tab.name.toLowerCase();
  item.dataset.sig = `t${tab.file_path || ""}|${tab.name}|${tab.dirty ? 1 : 0}|${tab.is_pinned ? 1 : 0}|${is_active ? 1 : 0}`;

  const row = document.createElement("div");
  row.className = "explorer-item-row" + (is_active ? " explorer-item-tab-active" : "");
  row.dataset.path = tab.file_path;
  row.dataset.tooltip = tab.file_path;

  row.appendChild(BuildExplorerChevron(true));

  if (tab.is_pinned) {
    const pin_wrap = document.createElement("span");
    pin_wrap.className = "explorer-item-pin";
    pin_wrap.innerHTML = IconTag("pin");
    row.appendChild(pin_wrap);
  }

  const icon_wrap = document.createElement("span");
  icon_wrap.className = "explorer-item-icon";
  icon_wrap.innerHTML = CreateFileIconSvg(tab.name);
  row.appendChild(icon_wrap);

  const label = document.createElement("span");
  label.className = "explorer-item-label";
  label.textContent = tab.dirty ? `${tab.name} *` : tab.name;
  row.appendChild(label);

  const actions = document.createElement("span");
  actions.className = "explorer-item-actions";
  actions.appendChild(BuildExplorerActionBtn("run", "Run tab", () => HandleRunTab(tab)));
  actions.appendChild(BuildExplorerActionBtn("close", "Close tab", () => RemoveTab(tab.id, false)));
  row.appendChild(actions);

  item.appendChild(row);

  row.addEventListener("click", () => {
    SetExplorerSelection(tab.file_path);
    SetActiveTab(tab.id);
  });

  row.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();

    const items = BuildTabContextMenuItems(tab, () => HandleTabContextRename(tab));
    ShowContextMenu(event.clientX, event.clientY, items);
  });

  return item;
}

async function RefreshTabsSection() {
  await RenderExplorerSections({ quiet: true, keys: ["tabs"] });
}

async function BuildTabsSection() {
  const open_tabs = typeof TABS_STATE !== "undefined" ? TABS_STATE.tabs : [];
  const section = BuildSectionShell("tabs", "blocked", null);
  section.appendChild(BuildSectionHeader("tabs", "Tabs", section, null, {}));

  const body = BuildSectionBody("blocked", null);

  if (!open_tabs || open_tabs.length === 0) {
    body.appendChild(BuildSectionEmptyLabel("No tabs open"));
  } else {
    for (const tab of open_tabs) {
      body.appendChild(BuildTabExplorerItem(tab));
    }
  }

  section.appendChild(body);
  return section;
}

function FilterExplorerTree(root_el, query, keep_set) {
  let any_match = false;

  for (const child of Array.from(root_el.children)) {
    if (!child.classList || !child.classList.contains("explorer-item")) {
      const nested_match = FilterExplorerTree(child, query, keep_set);

      if (nested_match) {
        keep_set.add(child);
        any_match = true;
      }

      continue;
    }

    const self_match = (child.dataset.name || "").includes(query);
    const child_match = FilterExplorerTree(child, query, keep_set);

    if (self_match || child_match) {
      keep_set.add(child);
      any_match = true;
    }
  }

  return any_match;
}

function GetExplorerRenderedSections() {
  const container = document.getElementById("explorer-sections");

  if (!container) {
    return [];
  }

  return Array.from(container.querySelectorAll(':scope > [data-section-key]'));
}

function ApplySearchFilter() {
  const input = document.getElementById("explorer-search-input");
  const container = document.getElementById("explorer-sections");

  if (!input || !container) {
    return;
  }

  const all_items = Array.from(container.querySelectorAll(".explorer-item"));
  const all_sections = GetExplorerRenderedSections();
  const query = input.value.trim().toLowerCase();

  container.classList.toggle("explorer-sections-filtering", query.length > 0);

  if (query.length === 0) {
    for (const item of all_items) {
      item.style.display = "";
    }

    for (const section of all_sections) {
      section.style.display = "";
    }

    return;
  }

  const keep_set = new Set();
  FilterExplorerTree(container, query, keep_set);

  for (const item of all_items) {
    item.style.display = keep_set.has(item) ? "" : "none";
  }

  for (const section of all_sections) {
    section.style.display = keep_set.has(section) ? "" : "none";
  }
}

function ExplorerTreeSignature(root) {
  const parts = [];

  for (const child of root.children) {
    if (!child.classList || !child.classList.contains("explorer-item")) {
      continue;
    }

    const is_collapsed = child.classList.contains("explorer-item-collapsed");
    parts.push(`${child.dataset.sig || ""}${is_collapsed ? "-" : "+"}`);

    if (is_collapsed) {
      continue;
    }

    const children_wrap = child.querySelector(":scope > .explorer-item-children");

    if (children_wrap) {
      parts.push(ExplorerTreeSignature(children_wrap));
    }
  }

  return parts.join(",");
}

function ExplorerSectionSignature(section_el) {
  const body = section_el.querySelector(":scope > .explorer-section-body");
  const collapsed = section_el.classList.contains("explorer-section-collapsed") ? "c" : "o";
  return `${collapsed}~${body ? ExplorerTreeSignature(body) : ""}`;
}

const EXPLORER_SECTION_BUILDERS = {
  recent: BuildRecentSection,
  favourites: BuildFavouritesSection,
  tabs: BuildTabsSection,
  autoexec: () => BuildFolderSection("autoexec", "Auto Execute", "autoexec"),
  scripts: () => BuildFolderSection("scripts", "Scripts", "scripts"),
};

async function RenderExplorerSections(options) {
  const container = document.getElementById("explorer-sections");

  if (!container) {
    return;
  }

  const resolved_options = options || {};
  const quiet = Boolean(resolved_options.quiet);
  const keys = Array.isArray(resolved_options.keys) && resolved_options.keys.length > 0
    ? new Set(resolved_options.keys)
    : null;
  const generation = ++EXPLORER_RENDER_STATE.generation;
  const ordered = [];

  for (const section of EXPLORER_SECTIONS) {
    const key = section.key;
    const existing = container.querySelector(`:scope > [data-section-key="${key}"]`);

    if (UI_STATE.hidden_sections[key]) {
      continue;
    }

    if (keys && !keys.has(key)) {
      if (existing) {
        ordered.push(existing);
      }
      continue;
    }

    const built = await EXPLORER_SECTION_BUILDERS[key]();
    await SettleExplorerLoads();

    if (generation !== EXPLORER_RENDER_STATE.generation) {
      return;
    }

    built.dataset.sectionKey = key;

    if (existing && ExplorerSectionSignature(existing) === ExplorerSectionSignature(built)) {
      ordered.push(existing);
      continue;
    }

    if (quiet) {
      built.querySelectorAll(".explorer-item").forEach((el) => {
        el.style.animation = "none";
      });
    }

    ordered.push(built);
  }

  const wanted = new Set(ordered);
  const stale = Array.from(container.children).filter((child) => child.dataset.sectionKey && !wanted.has(child));

  for (const child of stale) {
    child.remove();
  }

  const existing_hint = container.querySelector(":scope > .explorer-empty-hint");

  if (existing_hint) {
    existing_hint.remove();
  }

  let cursor = container.firstChild;

  for (const el of ordered) {
    if (el === cursor) {
      cursor = cursor.nextSibling;
      continue;
    }

    container.insertBefore(el, cursor);
  }

  if (ordered.length === 0) {
    const hint = document.createElement("span");
    hint.className = "explorer-empty explorer-empty-hint";
    hint.textContent = "Right click here to switch a section back on";
    container.appendChild(hint);
  }

  ApplySearchFilter();
  ApplyExplorerSelection();
}

async function RefreshExplorerFromDisk() {
  await LoadExplorerConfig();
  await RenderExplorerSections();
}

function SetupExplorerEmptySpaceMenu() {
  const explorer_el = document.querySelector(".explorer");

  if (!explorer_el) {
    return;
  }

  explorer_el.addEventListener("contextmenu", (event) => {
    if (event.target.closest(".explorer-search")) {
      return;
    }

    ShowExplorerSectionMenu(event);
  });

  const sections_btn = document.getElementById("explorer-sections-btn");

  if (sections_btn) {
    sections_btn.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      ShowExplorerSectionMenu(event);
    });

    sections_btn.addEventListener("click", (event) => {
      const rect = sections_btn.getBoundingClientRect();
      ShowContextMenu(
        rect.right,
        rect.bottom + 4,
        BuildExplorerSectionMenuItems()
      );
    });
  }
}

function SetupExplorerSearch() {
  const input = document.getElementById("explorer-search-input");

  if (input) {
    input.addEventListener("input", () => ApplySearchFilter());
    input.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && input.value.length > 0) {
        event.stopPropagation();
        input.value = "";
        ApplySearchFilter();
      }
    });
  }

  const refresh_btn = document.getElementById("explorer-refresh-btn");

  if (refresh_btn) {
    refresh_btn.addEventListener("click", () => RefreshExplorerFromDisk());
  }
}

async function FlushExplorerWatchQueue() {
  EXPLORER_WATCH_STATE.timer_id = null;

  const changed_folders = Array.from(EXPLORER_WATCH_STATE.pending);
  EXPLORER_WATCH_STATE.pending.clear();

  if (changed_folders.includes("config")) {
    await LoadExplorerConfig();
  }

  const keys = new Set();

  for (const folder of changed_folders) {
    const mapped = EXPLORER_WATCH_SECTIONS[folder];

    if (!mapped) {
      keys.clear();
      break;
    }

    for (const key of mapped) {
      keys.add(key);
    }
  }

  await RenderExplorerSections(keys.size > 0 ? { quiet: true, keys: Array.from(keys) } : { quiet: true });
}

function QueueExplorerRefresh(folder) {
  if (typeof folder === "string" && folder.length > 0) {
    EXPLORER_WATCH_STATE.pending.add(folder);
  }

  if (EXPLORER_WATCH_STATE.timer_id !== null) {
    return;
  }

  EXPLORER_WATCH_STATE.timer_id = setTimeout(() => {
    FlushExplorerWatchQueue();
  }, EXPLORER_WATCH_SETTLE_MS);
}

async function WatchExplorerFolders() {
  if (EXPLORER_WATCH_STATE.bound) {
    return;
  }

  if (!window.__TAURI__ || !window.__TAURI__.event) {
    return;
  }

  EXPLORER_WATCH_STATE.bound = true;

  try {
    await window.__TAURI__.event.listen("folder-changed", (event) => {
      QueueExplorerRefresh(event && event.payload ? event.payload.folder : null);
    });
  } catch (err) {
    EXPLORER_WATCH_STATE.bound = false;
    console.warn("could not bind folder watchdog:", err);
  }
}

async function LoadExplorerPanel() {
  await LoadExplorerConfig();
  await RenderExplorerSections();
  SetupExplorerSearch();
  SetupExplorerEmptySpaceMenu();
  SetupFileDragController();
  await WatchExplorerFolders();
}
