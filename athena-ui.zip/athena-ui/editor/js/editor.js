const EDITOR_STATE = {
  line_starts: null,
  source: null,
  active_line_index: 0,
  fonts_ready: false,
  gutter_first: 0,
  gutter_last: -1,
  gutter_active: -1,
  caret_index: -1,
  measure_start: 0,
  indent_key: null,
  highlight_first: 0,
  highlight_last: 0,
};

const EDITOR_CHUNKS = {
  els: [],
  painted: [],
  version: 0,
  line_height: 0,
};

const EDITOR_METRICS = {
  line_height: 0,
  pad_top: 0,
  pad_left: 0,
  char_width: 0,
};

const EDITOR_FRAME = {
  pending: false,
  need_highlight: false,
};

const EDITOR_ELS = {};

const EDITOR_SUGGEST_STATE = {
  visible: false,
  last_mouse_x: -1,
  last_mouse_y: -1,
  items: [],
  selected_index: 0,
  word_start: 0,
  caret: 0,
  query: "",
  total: 0,
  dismissed: false,
  dismissed_line_start: -1,
  list_key: null,
};

const EDITOR_POINTER_STATE = {
  selecting: false,
  anchor: 0,
};

const EDITOR_CARET_BLINK_RESTART_MS = 10;
const EDITOR_MIN_SUGGEST_QUERY = 2;
const EDITOR_SUGGEST_WORD_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.:";
const EDITOR_CHUNK_LINES = 400;
const EDITOR_WINDOW_OVERSCAN = 80;
const EDITOR_GUTTER_OVERSCAN = 60;
const EDITOR_SELECTION_OVERSCAN = 60;
const EDITOR_MEASURE_MAX_TEXT = 250000;
const EDITOR_DEFAULT_LINE_HEIGHT = 21;

let editor_caret_blink_timeout = null;

function CacheEditorEls() {
  EDITOR_ELS.textarea = document.getElementById("editor-input");
  EDITOR_ELS.highlight_code = document.getElementById("editor-highlight-code");
  EDITOR_ELS.highlight_pre = document.getElementById("editor-highlight-pre");
  EDITOR_ELS.measure = document.getElementById("editor-measure");
  EDITOR_ELS.canvas = document.getElementById("editor-canvas");
  EDITOR_ELS.scroll = document.getElementById("editor-scroll");
  EDITOR_ELS.code_area = document.getElementById("editor-code-area");
  EDITOR_ELS.gutter = document.getElementById("editor-gutter");
  EDITOR_ELS.gutter_lines = document.getElementById("editor-gutter-lines");
  EDITOR_ELS.active_line_box = document.getElementById("editor-active-line-box");
  EDITOR_ELS.indent_guides = document.getElementById("editor-indent-guides");
  EDITOR_ELS.caret = document.getElementById("editor-caret");
  EDITOR_ELS.selection_layer = document.getElementById("editor-selection-layer");
  EDITOR_ELS.suggest_popup = document.getElementById("editor-suggest-popup");
  EDITOR_ELS.suggest_list = document.getElementById("editor-suggest-list");
  EDITOR_ELS.suggest_doc = document.getElementById("editor-suggest-doc");
  EDITOR_ELS.suggest_head = document.getElementById("editor-suggest-head");
  return EDITOR_ELS;
}

function GetEditorEls() {
  if (EDITOR_ELS.textarea) {
    return EDITOR_ELS;
  }

  return CacheEditorEls();
}

function BuildLineStarts(raw_text) {
  const starts = [0];
  let index = raw_text.indexOf("\n");

  while (index !== -1) {
    starts.push(index + 1);
    index = raw_text.indexOf("\n", index + 1);
  }

  return starts;
}

function GetEditorLineStarts() {
  if (!EDITOR_STATE.line_starts) {
    const { textarea } = GetEditorEls();
    EDITOR_STATE.line_starts = BuildLineStarts(textarea ? textarea.value : "");
  }

  return EDITOR_STATE.line_starts;
}

function GetEditorLineCount() {
  return GetEditorLineStarts().length;
}

function GetEditorTextLength() {
  const { textarea } = GetEditorEls();
  return textarea ? textarea.value.length : 0;
}

function FindLineIndexAt(offset) {
  const starts = GetEditorLineStarts();
  let low = 0;
  let high = starts.length - 1;

  while (low < high) {
    const mid = (low + high + 1) >> 1;
    if (starts[mid] <= offset) {
      low = mid;
    } else {
      high = mid - 1;
    }
  }

  return low;
}

function GetLineStartOffset(line_index) {
  const starts = GetEditorLineStarts();
  return starts[Math.max(0, Math.min(line_index, starts.length - 1))];
}

function GetLineEndOffset(line_index) {
  const starts = GetEditorLineStarts();
  if (line_index + 1 < starts.length) {
    return starts[line_index + 1] - 1;
  }
  return GetEditorTextLength();
}

function GetVisibleLineRange() {
  const { scroll } = GetEditorEls();
  const metrics = GetEditorMetrics();
  const line_height = metrics.line_height;
  const last_line = GetEditorLineCount() - 1;

  if (!scroll || !line_height) {
    return { first: 0, last: last_line };
  }

  const first_visible = Math.floor((scroll.scrollTop - metrics.pad_top) / line_height);
  const last_visible = Math.ceil((scroll.scrollTop + scroll.clientHeight - metrics.pad_top) / line_height);
  const first = Math.min(last_line, Math.max(0, first_visible));

  return {
    first,
    last: Math.max(first, Math.min(last_line, last_visible)),
  };
}

function GetRenderWindow(overscan) {
  const last_line = GetEditorLineCount() - 1;
  const visible = GetVisibleLineRange();

  return {
    first: Math.max(0, visible.first - overscan),
    last: Math.min(last_line, visible.last + overscan),
  };
}

function IsRenderWindowCovered(first, last) {
  const visible = GetVisibleLineRange();
  return visible.first >= first && visible.last <= last;
}

function GetMeasureRoot() {
  const { measure, highlight_code } = GetEditorEls();
  return measure || highlight_code;
}

function SyncMeasureLayer(raw_text, starts) {
  const { measure } = GetEditorEls();
  if (!measure) {
    return;
  }

  if (raw_text.length > EDITOR_MEASURE_MAX_TEXT) {
    const metrics = GetEditorMetrics();
    const line_height = metrics.line_height || EDITOR_DEFAULT_LINE_HEIGHT;
    const pad_top = metrics.pad_top || 0;
    const window = GetRenderWindow(EDITOR_WINDOW_OVERSCAN);
    const measure_start = starts.length ? starts[window.first] : 0;
    const line_end = window.last + 1 < starts.length ? starts[window.last + 1] - 1 : raw_text.length;
    EDITOR_STATE.measure_start = measure_start;
    measure.textContent = raw_text.slice(measure_start, line_end);
    measure.style.height = `${pad_top + starts.length * line_height + pad_top}px`;
    return;
  }

  EDITOR_STATE.measure_start = 0;
  measure.style.height = "";
  const needs_pad = raw_text.length === 0 || raw_text.endsWith("\n");
  measure.textContent = needs_pad ? raw_text + " " : raw_text;
}

function PaintGutterActiveLine(active_line_index) {
  const { gutter_lines } = GetEditorEls();
  if (!gutter_lines) {
    return;
  }

  const previous = EDITOR_STATE.gutter_active;

  if (previous === active_line_index) {
    return;
  }

  EDITOR_STATE.gutter_active = active_line_index;
  const spans = gutter_lines.children;
  const offset = EDITOR_STATE.gutter_first;
  const previous_span = spans[previous - offset];
  const next_span = spans[active_line_index - offset];

  if (previous_span) {
    previous_span.classList.remove("editor-gutter-line-active");
  }

  if (next_span) {
    next_span.classList.add("editor-gutter-line-active");
  }
}

function RenderGutter(active_line_index) {
  const { gutter_lines } = GetEditorEls();
  if (!gutter_lines) {
    return;
  }

  EDITOR_STATE.active_line_index = active_line_index;
  const window = GetRenderWindow(EDITOR_GUTTER_OVERSCAN);
  const first = window.first;
  const last = window.last;
  const line_height = GetEditorMetrics().line_height;

  if (first !== EDITOR_STATE.gutter_first || last !== EDITOR_STATE.gutter_last) {
    let html_out = "";

    for (let line_index = first; line_index <= last; line_index += 1) {
      html_out += `<span class="editor-gutter-line">${line_index + 1}</span>`;
    }

    gutter_lines.innerHTML = html_out;
    EDITOR_STATE.gutter_first = first;
    EDITOR_STATE.gutter_last = last;
    EDITOR_STATE.gutter_active = -1;
  }

  if (line_height) {
    gutter_lines.style.transform = `translateY(${first * line_height}px)`;
  }

  PaintGutterActiveLine(active_line_index);
}

function SyncEditorChunkElements(chunk_count) {
  const { highlight_code } = GetEditorEls();
  const els = EDITOR_CHUNKS.els;
  const painted = EDITOR_CHUNKS.painted;

  while (els.length > chunk_count) {
    const el = els.pop();
    painted.pop();
    el.remove();
  }

  let html_out = "";

  for (let i = els.length; i < chunk_count; i += 1) {
    html_out += '<div class="editor-code-chunk"></div>';
  }

  if (!html_out) {
    return;
  }

  highlight_code.insertAdjacentHTML("beforeend", html_out);
  const children = highlight_code.children;

  for (let i = els.length; i < chunk_count; i += 1) {
    els.push(children[i]);
    painted.push(-1);
  }
}

function RenderEditorWindow(raw_text, starts) {
  const { highlight_code } = GetEditorEls();
  if (!highlight_code) {
    return;
  }

  const line_count = starts.length;
  const text_length = raw_text.length;
  const chunk_count = Math.max(1, Math.ceil(line_count / EDITOR_CHUNK_LINES));
  const line_height = GetEditorMetrics().line_height;
  const window = GetRenderWindow(EDITOR_WINDOW_OVERSCAN);
  const els = EDITOR_CHUNKS.els;
  const painted = EDITOR_CHUNKS.painted;
  const version = EDITOR_CHUNKS.version;

  if (EDITOR_CHUNKS.line_height !== line_height) {
    EDITOR_CHUNKS.line_height = line_height;
    for (let i = 0; i < painted.length; i += 1) {
      painted[i] = -1;
    }
  }

  SyncEditorChunkElements(chunk_count);

  const first_chunk = Math.floor(window.first / EDITOR_CHUNK_LINES);
  const last_chunk = Math.min(chunk_count - 1, Math.floor(window.last / EDITOR_CHUNK_LINES));

  for (let index = 0; index < chunk_count; index += 1) {
    if (painted[index] === version) {
      continue;
    }

    if (!line_height || index < first_chunk || index > last_chunk) {
      continue;
    }

    const el = els[index];

    if (!el) {
      continue;
    }

    const line_first = index * EDITOR_CHUNK_LINES;
    const line_after = Math.min(line_count, line_first + EDITOR_CHUNK_LINES);
    const offset_start = starts[line_first];
    const offset_end = line_after < line_count ? starts[line_after] : text_length;

    el.style.top = `${line_first * line_height}px`;
    el.innerHTML = HighlightLuauChunkToHtml(raw_text, offset_start, offset_end);
    painted[index] = version;
  }

  EDITOR_STATE.highlight_first = window.first;
  EDITOR_STATE.highlight_last = window.last;
}

function RenderEditorHighlight(raw_text) {
  const { highlight_code } = GetEditorEls();
  if (!highlight_code) {
    return;
  }

  if (raw_text !== EDITOR_STATE.source) {
    EDITOR_STATE.source = raw_text;
    EDITOR_STATE.line_starts = BuildLineStarts(raw_text);
    EDITOR_CHUNKS.version += 1;
    SyncMeasureLayer(raw_text, EDITOR_STATE.line_starts);
  }

  RenderEditorWindow(raw_text, EDITOR_STATE.line_starts);
  RenderGutter(EDITOR_STATE.active_line_index);
  RenderIndentGuides(raw_text);
}

function GetIndentCharWidthPx() {
  if (EDITOR_METRICS.char_width !== 0) {
    return EDITOR_METRICS.char_width;
  }

  const measure_root = GetMeasureRoot();
  const { canvas } = GetEditorEls();
  if (!measure_root || !canvas) {
    return 0;
  }

  const sample_text = measure_root.textContent || "";
  if (sample_text.length < 2) {
    return 0;
  }

  const rect = MeasureRangeRect(measure_root, 0, 2);
  if (!rect || rect.width === 0) {
    return 0;
  }

  EDITOR_METRICS.char_width = rect.width / 2;
  return EDITOR_METRICS.char_width;
}

function GetEditorIndentUnit() {
  const width = Math.max(1, Math.round(Number(UI_STATE.editor_tab_size) || 4));
  return " ".repeat(width);
}

function ScanLineIndent(line_text, unit_length) {
  const limit = line_text.length;
  let columns = 0;
  let index = 0;

  while (index < limit) {
    const ch = line_text[index];

    if (ch === " ") {
      columns += 1;
    } else if (ch === "\t") {
      columns += unit_length;
    } else {
      return { blank: false, level: Math.floor(columns / unit_length) };
    }

    index += 1;
  }

  return { blank: true, level: 0 };
}

function ResolveWindowIndentLevels(levels, blank_flags) {
  const resolved = levels.slice();
  let before_level = 0;

  for (let i = 0; i < levels.length; i += 1) {
    if (!blank_flags[i]) {
      before_level = levels[i];
      continue;
    }

    resolved[i] = before_level;
  }

  let after_level = 0;

  for (let i = levels.length - 1; i >= 0; i -= 1) {
    if (!blank_flags[i]) {
      after_level = levels[i];
      continue;
    }

    resolved[i] = Math.min(resolved[i], after_level);
  }

  return resolved;
}

function RenderIndentGuides(raw_text) {
  const { indent_guides } = GetEditorEls();
  if (!indent_guides) {
    return;
  }

  const metrics = GetEditorMetrics();
  const line_height = metrics.line_height;
  const window = GetRenderWindow(EDITOR_WINDOW_OVERSCAN);
  const first = window.first;
  const last = window.last;
  const starts = GetEditorLineStarts();
  const line_count = starts.length;
  const unit_length = Math.max(1, Math.round(Number(UI_STATE.editor_tab_size) || 4));
  const span = last - first + 1;
  const levels = new Array(span);
  const blank_flags = new Array(span);
  let max_level = 0;

  for (let i = 0; i < span; i += 1) {
    const line_index = first + i;
    const line_end = line_index + 1 < line_count ? starts[line_index + 1] - 1 : raw_text.length;
    const scanned = ScanLineIndent(raw_text.slice(starts[line_index], line_end), unit_length);

    levels[i] = scanned.level;
    blank_flags[i] = scanned.blank;

    if (!scanned.blank && scanned.level > max_level) {
      max_level = scanned.level;
    }
  }

  const resolved = ResolveWindowIndentLevels(levels, blank_flags);
  const indent_key = `${first}:${line_height}:${resolved.join(",")}`;

  if (max_level === 0 || !line_height) {
    if (EDITOR_STATE.indent_key !== indent_key) {
      EDITOR_STATE.indent_key = indent_key;
      indent_guides.innerHTML = "";
    }
    return;
  }

  const char_width = GetIndentCharWidthPx();

  if (char_width === 0) {
    if (EDITOR_STATE.indent_key !== indent_key) {
      EDITOR_STATE.indent_key = indent_key;
      indent_guides.innerHTML = "";
    }
    return;
  }

  if (EDITOR_STATE.indent_key === indent_key && indent_guides.childElementCount > 0) {
    return;
  }

  EDITOR_STATE.indent_key = indent_key;
  const indent_px = char_width * unit_length;
  let html_out = "";

  for (let level = 1; level <= max_level; level += 1) {
    let run_start = -1;

    for (let i = 0; i <= span; i += 1) {
      const has_level = i < span && resolved[i] >= level;

      if (has_level && run_start === -1) {
        run_start = i;
        continue;
      }

      if (!has_level && run_start !== -1) {
        const top = metrics.pad_top + (first + run_start) * line_height;
        const height = (i - run_start) * line_height;
        const left = metrics.pad_left + (level - 1) * indent_px;

        html_out += `<div class="editor-indent-guide-line" style="left:${left}px;top:${top}px;height:${height}px;"></div>`;
        run_start = -1;
      }
    }
  }

  indent_guides.innerHTML = html_out;
}

function LocateTextPosition(root, target_index) {
  const single_node = root.firstChild;

  if (
    single_node
    && single_node.nodeType === Node.TEXT_NODE
    && single_node.nextSibling === null
  ) {
    const char_count = single_node.textContent.length;
    const index = Math.max(0, Math.min(target_index, char_count));
    return { node: single_node, offset: index };
  }

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let remaining = target_index;
  let node = walker.nextNode();
  let last_node = null;

  while (node) {
    const len = node.textContent.length;

    if (remaining < len) {
      return { node, offset: remaining };
    }

    if (remaining === len) {
      const peek_walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      peek_walker.currentNode = node;
      const next_node = peek_walker.nextNode();

      if (next_node && next_node.textContent.length > 0) {
        return { node: next_node, offset: 0 };
      }

      return { node, offset: len };
    }

    remaining -= len;
    last_node = node;
    node = walker.nextNode();
  }

  if (last_node) {
    return { node: last_node, offset: last_node.textContent.length };
  }
  return null;
}

function GetLineHeightPx(textarea) {
  const computed = window.getComputedStyle(textarea);
  const parsed = parseFloat(computed.lineHeight);
  if (!Number.isNaN(parsed)) {
    return parsed;
  }
  return parseFloat(computed.fontSize) * GetUiStateRangedNumber("editor_line_height");
}

function InvalidateEditorMetrics() {
  EDITOR_METRICS.line_height = 0;
  EDITOR_METRICS.pad_top = 0;
  EDITOR_METRICS.pad_left = 0;
  EDITOR_METRICS.char_width = 0;
}

function GetEditorMetrics() {
  if (EDITOR_METRICS.line_height === 0) {
    const { textarea } = GetEditorEls();

    if (textarea) {
      const computed = window.getComputedStyle(textarea);
      EDITOR_METRICS.pad_top = parseFloat(computed.paddingTop) || 0;
      EDITOR_METRICS.pad_left = parseFloat(computed.paddingLeft) || 0;
      EDITOR_METRICS.line_height = GetLineHeightPx(textarea);
    }
  }

  return EDITOR_METRICS;
}

function MeasureRangeRect(root, start_index, end_index) {
  const measure_start = EDITOR_STATE.measure_start || 0;
  const local_start = start_index - measure_start;
  const local_end = end_index - measure_start;
  const char_count = root.textContent.length;

  if (local_start < 0 || local_start > char_count) {
    return null;
  }

  const start = LocateTextPosition(root, local_start);
  const end = LocateTextPosition(root, Math.max(0, Math.min(local_end, char_count)));
  if (!start || !end) {
    return null;
  }

  const range = document.createRange();
  range.setStart(start.node, start.offset);
  range.setEnd(end.node, end.offset);
  return range.getBoundingClientRect();
}

function GetCaretPixelPosition(textarea, caret_index) {
  const measure_root = GetMeasureRoot();
  const { canvas } = GetEditorEls();
  const metrics = GetEditorMetrics();
  const pad_top = metrics.pad_top;
  const pad_left = metrics.pad_left;
  const line_height = metrics.line_height;

  const line_index = FindLineIndexAt(caret_index);
  const line_start = GetLineStartOffset(line_index);

  const fallback = {
    left: pad_left,
    top: pad_top + line_index * line_height,
  };

  if (!measure_root || !canvas) {
    return fallback;
  }

  const canvas_rect = canvas.getBoundingClientRect();

  if (caret_index === line_start) {
    return fallback;
  }

  const span_rect = MeasureRangeRect(measure_root, line_start, caret_index);
  if (!span_rect || span_rect.width === 0) {
    return fallback;
  }

  return {
    left: span_rect.right - canvas_rect.left,
    top: fallback.top,
  };
}

function GetLineRange(value, line_index) {
  const safe_index = Math.max(0, Math.min(line_index, GetEditorLineCount() - 1));
  const start = GetLineStartOffset(safe_index);
  const end = GetLineEndOffset(safe_index);

  return { start, end, text: value.slice(start, end) };
}

function GetCharIndexFromClientPoint(client_x, client_y) {
  const { textarea, canvas } = GetEditorEls();
  if (!textarea || !canvas) {
    return 0;
  }

  const metrics = GetEditorMetrics();
  const pad_top = metrics.pad_top;
  const pad_left = metrics.pad_left;
  const line_height = metrics.line_height;
  const canvas_rect = canvas.getBoundingClientRect();
  const line_count = GetEditorLineCount();

  let line_index = Math.floor((client_y - canvas_rect.top - pad_top) / line_height);
  if (line_index < 0) {
    line_index = 0;
  }
  if (line_index > line_count - 1) {
    line_index = line_count - 1;
  }

  const { start, end } = GetLineRange(textarea.value, line_index);
  if (end === start) {
    return start;
  }

  let lo = start;
  let hi = end;

  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    const mid_x = canvas_rect.left + GetCaretPixelPosition(textarea, mid).left;
    if (mid_x < client_x) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }

  const prev = Math.max(start, lo - 1);
  const prev_x = canvas_rect.left + GetCaretPixelPosition(textarea, prev).left;
  const lo_x = canvas_rect.left + GetCaretPixelPosition(textarea, lo).left;

  if (Math.abs(client_x - prev_x) <= Math.abs(client_x - lo_x)) {
    return prev;
  }
  return lo;
}

function GetWordBounds(text, index) {
  const IsWordChar = (ch) => /[A-Za-z0-9_]/.test(ch);
  let start = index;
  let end = index;

  if (index < text.length && text[index] === "\n") {
    return { start: index, end: index };
  }

  while (start > 0 && IsWordChar(text[start - 1])) {
    start -= 1;
  }
  while (end < text.length && IsWordChar(text[end])) {
    end += 1;
  }

  if (start === end && end < text.length && text[end] !== "\n") {
    end += 1;
  }

  return { start, end };
}

function GetCaretLineIndex(textarea) {
  return FindLineIndexAt(textarea.selectionStart);
}

function RestartCaretBlink(caret_el) {
  if (editor_caret_blink_timeout !== null) {
    clearTimeout(editor_caret_blink_timeout);
  }

  const bar = caret_el.querySelector(".editor-caret-bar") || caret_el;
  caret_el.classList.remove("editor-caret-blink");
  bar.offsetHeight;

  if (UI_STATE.editor_caret_blink !== false) {
    caret_el.classList.add("editor-caret-blink");
  }

  editor_caret_blink_timeout = setTimeout(() => {
    editor_caret_blink_timeout = null;
  }, EDITOR_CARET_BLINK_RESTART_MS);
}

function UpdateCustomCaret() {
  const { textarea, caret } = GetEditorEls();
  if (!textarea || !caret) {
    return;
  }

  const has_selection = textarea.selectionStart !== textarea.selectionEnd;
  const is_focused = document.activeElement === textarea;
  const caret_index = textarea.selectionStart;
  const is_visible = caret.classList.contains("editor-caret-visible");

  if (has_selection || !is_focused) {
    EDITOR_STATE.caret_index = -1;
    caret.classList.remove("editor-caret-visible");
    caret.classList.remove("editor-caret-blink");
    return;
  }

  if (caret_index === EDITOR_STATE.caret_index && is_visible) {
    return;
  }

  const line_height = GetEditorMetrics().line_height;
  const pos = GetCaretPixelPosition(textarea, caret_index);
  const next_transform = `translate(${Math.round(pos.left)}px, ${Math.round(pos.top)}px)`;
  const moved = caret.style.transform !== next_transform;
  EDITOR_STATE.caret_index = caret_index;

  if (!is_visible) {
    caret.classList.add("editor-caret-instant");
    caret.style.height = `${line_height}px`;
    caret.style.transform = next_transform;
    caret.classList.add("editor-caret-visible");
    caret.offsetHeight;
    caret.classList.remove("editor-caret-instant");
    RestartCaretBlink(caret);
    return;
  }

  caret.style.height = `${line_height}px`;
  caret.style.transform = next_transform;

  if (moved) {
    RestartCaretBlink(caret);
  }
}

function UpdateSelectionAndCaret() {
  UpdateCustomCaret();
  RenderSelectionOverlay();
}

function GetSelectionLineRects(textarea, selection_start, selection_end) {
  const measure_root = GetMeasureRoot();
  const { canvas } = GetEditorEls();
  if (!measure_root || !canvas) {
    return [];
  }

  const canvas_rect = canvas.getBoundingClientRect();
  const value = textarea.value;
  const metrics = GetEditorMetrics();
  const line_height = metrics.line_height;
  const pad_top = metrics.pad_top;
  const pad_left = metrics.pad_left;

  const starts = GetEditorLineStarts();
  const window = GetRenderWindow(EDITOR_SELECTION_OVERSCAN);
  const first_line = Math.max(FindLineIndexAt(selection_start), window.first);
  const last_line = Math.min(FindLineIndexAt(selection_end), window.last);
  const rects = [];

  for (let line_index = first_line; line_index <= last_line; line_index += 1) {
    const line_text = value.slice(starts[line_index], GetLineEndOffset(line_index));

    const overlap_start = Math.max(starts[line_index], selection_start);
    const overlap_end = Math.min(GetLineEndOffset(line_index), selection_end);

    if (overlap_start >= overlap_end) {
      continue;
    }

    let left;
    let width;

    if (line_text.length === 0) {
      left = pad_left;
      width = 0;
    } else {
      const range_rect = MeasureRangeRect(measure_root, overlap_start, overlap_end);
      if (!range_rect) {
        continue;
      }
      left = range_rect.left - canvas_rect.left;
      width = range_rect.width;
    }

    rects.push({
      left,
      width,
      top: pad_top + line_index * line_height,
      height: line_height,
    });
  }

  return rects;
}

function RenderSelectionOverlay() {
  const { textarea, canvas, selection_layer } = GetEditorEls();
  if (!textarea || !canvas || !selection_layer) {
    return;
  }

  const selection_start = textarea.selectionStart;
  const selection_end = textarea.selectionEnd;

  if (selection_start === selection_end) {
    selection_layer.innerHTML = "";
    return;
  }

  const rects = GetSelectionLineRects(textarea, selection_start, selection_end);
  let html_out = "";

  for (const rect of rects) {
    const box_width = Math.max(2, rect.width);
    html_out += `<div class="editor-selection-box" style="left:${rect.left}px;top:${rect.top}px;width:${box_width}px;height:${rect.height}px;"></div>`;
  }

  selection_layer.innerHTML = html_out;
}

function UpdateActiveLineBox() {
  const { textarea, scroll, active_line_box } = GetEditorEls();
  if (!textarea || !scroll || !active_line_box) {
    return;
  }

  const computed_line_index = GetCaretLineIndex(textarea);
  EDITOR_STATE.active_line_index = computed_line_index;
  PaintGutterActiveLine(computed_line_index);

  UpdateCustomCaret();

  const metrics = GetEditorMetrics();
  const pad_top = metrics.pad_top;
  const line_height = metrics.line_height;

  const top_in_content = pad_top + computed_line_index * line_height;
  const top_in_viewport = top_in_content - scroll.scrollTop;

  if (top_in_viewport + line_height <= 0 || top_in_viewport >= scroll.clientHeight) {
    active_line_box.style.display = "none";
    return;
  }

  if (UI_STATE.show_active_line === false) {
    active_line_box.style.display = "none";
    return;
  }

  active_line_box.style.display = "block";
  active_line_box.style.top = `${top_in_content}px`;
  active_line_box.style.height = `${line_height}px`;
}

function SyncEditorScroll() {
  const { scroll } = GetEditorEls();
  if (!scroll) {
    return;
  }

  if (!IsRenderWindowCovered(EDITOR_STATE.highlight_first, EDITOR_STATE.highlight_last)) {
    ScheduleEditorFrame(true);
  }

  UpdateActiveLineBox();
  RenderSelectionOverlay();
  if (EDITOR_SUGGEST_STATE.visible) {
    PositionSuggestPopup();
  }
}

function ScheduleEditorFrame(needs_highlight = false) {
  if (needs_highlight) {
    EDITOR_FRAME.need_highlight = true;
  }

  if (EDITOR_FRAME.pending) {
    return;
  }

  EDITOR_FRAME.pending = true;
  window.requestAnimationFrame(FlushEditorFrame);
}

function FlushEditorFrame() {
  EDITOR_FRAME.pending = false;

  const { textarea } = GetEditorEls();
  if (!textarea) {
    EDITOR_FRAME.need_highlight = false;
    return;
  }

  if (EDITOR_FRAME.need_highlight) {
    EDITOR_FRAME.need_highlight = false;
    RenderEditorHighlight(textarea.value);
  }

  UpdateActiveLineBox();
  UpdateSelectionAndCaret();
  UpdateStatusBarCaret();
  UpdateSuggestPopup();

  if (typeof UpdateDiscordPresenceDebounced === "function") {
    UpdateDiscordPresenceDebounced();
  }
}

function HideSuggestPopup() {
  const { suggest_popup } = GetEditorEls();
  EDITOR_SUGGEST_STATE.visible = false;
  EDITOR_SUGGEST_STATE.items = [];
  EDITOR_SUGGEST_STATE.list_key = null;

  if (suggest_popup) {
    suggest_popup.classList.remove("editor-suggest-popup-visible");
  }
}

function DismissSuggestPopup(textarea) {
  HideSuggestPopup();
  EDITOR_SUGGEST_STATE.dismissed = true;

  const el = textarea || GetEditorEls().textarea;
  if (el) {
    const caret = el.selectionStart;
    EDITOR_SUGGEST_STATE.dismissed_line_start = GetLineStart(el.value, caret);
  } else {
    EDITOR_SUGGEST_STATE.dismissed_line_start = -1;
  }
}

function HighlightSuggestMatch(text, query) {
  const raw = String(text || "");
  const q = String(query || "");

  if (!q) {
    return EscapeHtmlForEditor(raw);
  }

  const lower = raw.toLowerCase();
  const marks = [];
  let cursor = 0;
  let at = lower.indexOf(q.toLowerCase(), cursor);

  while (at !== -1) {
    marks.push({ start: at, end: at + q.length });
    cursor = at + q.length;
    at = cursor >= lower.length ? -1 : lower.indexOf(q.toLowerCase(), cursor);
  }

  if (marks.length === 0) {
    let fallback = 0;
    for (const character of lower) {
      if (q.toLowerCase().includes(character)) {
        marks.push({ start: fallback, end: fallback + 1 });
      }
      fallback += 1;
    }
  }

  if (marks.length === 0) {
    return EscapeHtmlForEditor(raw);
  }

  let html_out = "";
  let last = 0;

  for (const mark of marks) {
    html_out += EscapeHtmlForEditor(raw.slice(last, mark.start));
    html_out += `<span class="editor-suggest-mark">${EscapeHtmlForEditor(raw.slice(mark.start, mark.end))}</span>`;
    last = mark.end;
  }

  return html_out + EscapeHtmlForEditor(raw.slice(last));
}

function ScrollSuggestRowIntoView() {
  const { suggest_list } = GetEditorEls();
  if (!suggest_list) {
    return;
  }

  const row = suggest_list.querySelector(".editor-suggest-row-active");
  if (!row || typeof row.scrollIntoView !== "function") {
    return;
  }

  row.scrollIntoView({ block: "nearest" });
}

function FillSuggestDoc() {
  const { suggest_doc } = GetEditorEls();
  if (!suggest_doc) {
    return;
  }

  const active_snippet = EDITOR_SUGGEST_STATE.items[EDITOR_SUGGEST_STATE.selected_index];
  const doc_key = active_snippet ? `${active_snippet.prefix}\u0000${active_snippet.documentation}` : "";
  if (suggest_doc.dataset.docKey === doc_key) {
    return;
  }

  suggest_doc.dataset.docKey = doc_key;
  const doc_html = active_snippet ? RenderSnippetDocumentationHtml(active_snippet) : "";

  if (doc_html) {
    suggest_doc.innerHTML = doc_html;
    suggest_doc.classList.add("editor-suggest-doc-visible");
  } else {
    suggest_doc.innerHTML = "";
    suggest_doc.classList.remove("editor-suggest-doc-visible");
  }
}

function PaintSuggestSelection(should_scroll = true) {
  const { suggest_list } = GetEditorEls();
  if (!suggest_list) {
    return;
  }

  const rows = suggest_list.querySelectorAll(".editor-suggest-row");
  rows.forEach((row, index) => {
    row.classList.toggle("editor-suggest-row-active", index === EDITOR_SUGGEST_STATE.selected_index);
  });

  FillSuggestDoc();
  if (should_scroll) {
    ScrollSuggestRowIntoView();
  }
}

function BuildSuggestListKey() {
  return EDITOR_SUGGEST_STATE.items
    .map((snippet) => `${snippet.prefix}:${snippet.kind}:${snippet.value_type}:${snippet.body}:${snippet.origin}:${snippet.match_field}`)
    .join("|") + `\u0000${EDITOR_SUGGEST_STATE.total}`;
}

function RenderSuggestList() {
  const { suggest_list, suggest_head } = GetEditorEls();
  if (!suggest_list) {
    return;
  }

  const list_key = `${EDITOR_SUGGEST_STATE.query}\u0000${EDITOR_SUGGEST_STATE.selected_index}\u0000${BuildSuggestListKey()}`;
  if (EDITOR_SUGGEST_STATE.list_key === list_key) {
    return;
  }

  EDITOR_SUGGEST_STATE.list_key = list_key;

  if (suggest_head) {
    const shown = EDITOR_SUGGEST_STATE.items.length;
    const total = Math.max(EDITOR_SUGGEST_STATE.total, shown);
    const count_label = total === 1 ? "1 result" : `${total} results`;
    suggest_head.textContent = shown < total ? `${count_label} · showing ${shown}` : count_label;
  }

  suggest_list.innerHTML = "";

  const items = EDITOR_SUGGEST_STATE.items;
  if (items.length === 0) {
    const empty_el = document.createElement("div");
    empty_el.className = "editor-suggest-empty";
    empty_el.textContent = EDITOR_SUGGEST_STATE.query
      ? `no matches for "${EDITOR_SUGGEST_STATE.query}"`
      : "no snippets loaded";
    suggest_list.appendChild(empty_el);
    FillSuggestDoc();
    return;
  }

  let last_origin = null;

  items.forEach((snippet, index) => {
    if (snippet.origin !== last_origin) {
      last_origin = snippet.origin;
      const section_el = document.createElement("div");
      section_el.className = "editor-suggest-section";
      section_el.textContent = snippet.origin === "buffer" ? "This file" : "Snippets";
      suggest_list.appendChild(section_el);
    }

    const row = document.createElement("div");
    row.className = "editor-suggest-row" + (index === EDITOR_SUGGEST_STATE.selected_index ? " editor-suggest-row-active" : "");

    const text_el = document.createElement("div");
    text_el.className = "editor-suggest-row-text";

    const top_el = document.createElement("div");
    top_el.className = "editor-suggest-row-top";

    const prefix_el = document.createElement("span");
    prefix_el.className = "editor-suggest-row-prefix";
    prefix_el.innerHTML = HighlightSuggestMatch(snippet.prefix, EDITOR_SUGGEST_STATE.query);
    top_el.appendChild(prefix_el);

    if (snippet.description) {
      const desc_el = document.createElement("span");
      desc_el.className = "editor-suggest-row-desc";
      desc_el.textContent = snippet.description;
      top_el.appendChild(desc_el);
    }

    text_el.appendChild(top_el);

    const body_el = document.createElement("div");
    body_el.className = "editor-suggest-row-body";
    body_el.innerHTML = HighlightSnippetBodyRichHtml(snippet.body);
    text_el.appendChild(body_el);

    row.appendChild(text_el);

    row.addEventListener("mousedown", (event) => {
      event.preventDefault();
      EDITOR_SUGGEST_STATE.selected_index = index;

      const { textarea } = GetEditorEls();
      if (textarea) {
        ConfirmSuggestSelection(textarea);
      }
    });

    row.addEventListener("mousemove", (event) => {
      const moved = event.screenX !== EDITOR_SUGGEST_STATE.last_mouse_x || event.screenY !== EDITOR_SUGGEST_STATE.last_mouse_y;
      EDITOR_SUGGEST_STATE.last_mouse_x = event.screenX;
      EDITOR_SUGGEST_STATE.last_mouse_y = event.screenY;

      if (!moved || EDITOR_SUGGEST_STATE.selected_index === index) {
        return;
      }

      EDITOR_SUGGEST_STATE.selected_index = index;
      PaintSuggestSelection(false);
    });

    suggest_list.appendChild(row);
  });

  FillSuggestDoc();
  ScrollSuggestRowIntoView();
}

function PositionSuggestPopup() {
  const { textarea, suggest_popup, canvas } = GetEditorEls();
  if (!textarea || !suggest_popup || !canvas) {
    return;
  }

  const caret = EDITOR_SUGGEST_STATE.caret;
  const line_height = GetEditorMetrics().line_height;
  const caret_pos = GetCaretPixelPosition(textarea, caret);
  const canvas_rect = canvas.getBoundingClientRect();
  const caret_top = canvas_rect.top + caret_pos.top;
  const space_below = Math.max(160, window.innerHeight - caret_top - line_height - 10);
  const space_above = Math.max(160, caret_top - 10);
  const flip = space_above > space_below;

  suggest_popup.style.maxHeight = `${flip ? space_above : space_below}px`;

  const popup_left = canvas_rect.left + caret_pos.left;
  const popup_width = suggest_popup.offsetWidth;
  const popup_height = suggest_popup.offsetHeight;

  suggest_popup.style.left = `${Math.max(6, Math.min(popup_left, window.innerWidth - popup_width - 6))}px`;
  suggest_popup.style.top = flip
    ? `${Math.max(6, caret_top - popup_height - 3)}px`
    : `${caret_top + line_height + 3}px`;
}

function ShowSuggestPopup(items, word_start, caret, query, total) {
  const { suggest_popup } = GetEditorEls();
  if (!suggest_popup) {
    return;
  }

  const prev_prefix = (EDITOR_SUGGEST_STATE.items[EDITOR_SUGGEST_STATE.selected_index] || {}).prefix;
  EDITOR_SUGGEST_STATE.visible = true;
  EDITOR_SUGGEST_STATE.items = items;
  EDITOR_SUGGEST_STATE.word_start = word_start;
  EDITOR_SUGGEST_STATE.caret = caret;
  EDITOR_SUGGEST_STATE.query = query || "";
  EDITOR_SUGGEST_STATE.total = total || items.length;

  const keep = items.findIndex((snippet) => snippet.prefix === prev_prefix);
  EDITOR_SUGGEST_STATE.selected_index = keep >= 0 ? keep : 0;

  suggest_popup.classList.add("editor-suggest-popup-visible");
  RenderSuggestList();
  PositionSuggestPopup();
}

function ReadSuggestWordAt(text, caret) {
  let start = caret;

  while (start > 0 && EDITOR_SUGGEST_WORD_CHARS.indexOf(text[start - 1]) !== -1) {
    start -= 1;
  }

  while (start < caret && !/[A-Za-z_]/.test(text[start])) {
    start += 1;
  }

  return text.slice(start, caret);
}

function UpdateSuggestPopup(textarea_target, force) {
  const { textarea } = GetEditorEls();
  if (!textarea) {
    return;
  }

  if (UI_STATE.disable_snippets) {
    HideSuggestPopup();
    return;
  }

  if (IsSnippetSessionActive(textarea)) {
    HideSuggestPopup();
    return;
  }

  if (textarea.selectionStart !== textarea.selectionEnd) {
    return;
  }

  const caret = textarea.selectionStart;
  const current_line_start = GetLineStartOffset(FindLineIndexAt(caret));

  if (EDITOR_SUGGEST_STATE.dismissed) {
    if (current_line_start === EDITOR_SUGGEST_STATE.dismissed_line_start) {
      return;
    }
    EDITOR_SUGGEST_STATE.dismissed = false;
  }

  const query = ReadSuggestWordAt(textarea.value, caret);
  const word_start = caret - query.length;

  if (query.length < EDITOR_MIN_SUGGEST_QUERY && !force) {
    HideSuggestPopup();
    return;
  }

  const matches = GetSnippetSuggestions(query, textarea.value.slice(0, current_line_start));
  const items = matches.items.map((entry) => {
    const snippet = entry.snippet;
    return {
      prefix: snippet.prefix,
      name: snippet.name,
      kind: snippet.kind,
      value_type: snippet.value_type,
      description: snippet.description,
      documentation: snippet.documentation,
      body: snippet.body,
      origin: entry.origin,
      match_field: entry.match.field,
    };
  });

  const only_echoes_typed_word = items.length > 0 && items.every(
    (item) => item.prefix === query && item.body === query && !item.documentation && !item.description
  );

  if (only_echoes_typed_word && !force) {
    HideSuggestPopup();
    return;
  }

  if (items.length === 0 && !force) {
    HideSuggestPopup();
    return;
  }

  ShowSuggestPopup(items, word_start, caret, query, matches.total);
}

function SetSuggestSelection(index) {
  const count = EDITOR_SUGGEST_STATE.items.length;
  if (count === 0) {
    return;
  }

  EDITOR_SUGGEST_STATE.selected_index = Math.min(Math.max(index, 0), count - 1);
  PaintSuggestSelection();
}

function HandleSuggestNavKey(key) {
  const count = EDITOR_SUGGEST_STATE.items.length;
  if (count === 0) {
    return false;
  }

  if (key === "ArrowDown" || key === "PageDown") {
    SetSuggestSelection(EDITOR_SUGGEST_STATE.selected_index + 1);
    return true;
  }

  if (key === "ArrowUp" || key === "PageUp") {
    SetSuggestSelection(EDITOR_SUGGEST_STATE.selected_index - 1);
    return true;
  }

  if (key === "Home") {
    SetSuggestSelection(0);
    return true;
  }

  if (key === "End") {
    SetSuggestSelection(count - 1);
    return true;
  }

  return false;
}

function ConfirmSuggestSelection(textarea) {
  const snippet = EDITOR_SUGGEST_STATE.items[EDITOR_SUGGEST_STATE.selected_index];
  if (!snippet) {
    HideSuggestPopup();
    return;
  }

  EndSnippetSession();
  ExpandSnippetInTextarea(textarea, snippet, EDITOR_SUGGEST_STATE.word_start, EDITOR_SUGGEST_STATE.caret);
  HideSuggestPopup();
  textarea.dispatchEvent(new Event("input"));
}

function GetLineStart(text, index) {
  const newline_index = text.lastIndexOf("\n", index - 1);
  return newline_index + 1;
}

function GetLineEnd(text, index) {
  const newline_index = text.indexOf("\n", index);
  return newline_index === -1 ? text.length : newline_index;
}

function ReplaceTextareaRange(textarea, range_start, range_end, new_text) {
  textarea.focus();
  textarea.selectionStart = range_start;
  textarea.selectionEnd = range_end;

  const supported = typeof document.execCommand === "function"
    && document.queryCommandSupported
    && document.queryCommandSupported("insertText");

  if (supported) {
    document.execCommand("insertText", false, new_text);
    return;
  }

  const value = textarea.value;
  textarea.value = value.slice(0, range_start) + new_text + value.slice(range_end);
  textarea.selectionStart = textarea.selectionEnd = range_start + new_text.length;
}

function HandleEditorTabKey(event, textarea) {
  event.preventDefault();

  if (StepSnippetSession(textarea, event.shiftKey ? -1 : 1)) {
    return;
  }

  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const value = textarea.value;

  const spans_multiple_lines = value.slice(start, end).includes("\n");
  const indent_unit = GetEditorIndentUnit();

  if (event.shiftKey) {
    const block_start = GetLineStart(value, start);
    const block_end = end > start ? GetLineEnd(value, Math.max(start, end - 1)) : GetLineEnd(value, start);
    const block_text = value.slice(block_start, block_end);
    const lines = block_text.split("\n");

    const RemovedForLine = (line) => {
      if (line.startsWith(indent_unit)) {
        return indent_unit.length;
      }
      const leading_ws_match = line.match(/^[ \t]+/);
      return leading_ws_match ? leading_ws_match[0].length : 0;
    };

    const first_line_removed = RemovedForLine(lines[0]);
    const last_line_removed = RemovedForLine(lines[lines.length - 1]);
    const new_lines = lines.map((line) => line.slice(RemovedForLine(line)));

    ReplaceTextareaRange(textarea, block_start, block_end, new_lines.join("\n"));
    textarea.selectionStart = Math.max(block_start, start - first_line_removed);
    textarea.selectionEnd = Math.max(textarea.selectionStart, end - first_line_removed - last_line_removed);
    textarea.dispatchEvent(new Event("input"));
    return;
  }

  if (start === end) {
    const expanded = TryExpandSnippetAtCaret(textarea);

    if (!expanded) {
      ReplaceTextareaRange(textarea, start, end, indent_unit);
    }

    textarea.dispatchEvent(new Event("input"));
    return;
  }

  if (!spans_multiple_lines) {
    ReplaceTextareaRange(textarea, start, end, indent_unit);
    textarea.dispatchEvent(new Event("input"));
    return;
  }

  const block_start = GetLineStart(value, start);
  const block_end = GetLineEnd(value, Math.max(start, end - 1));
  const block_text = value.slice(block_start, block_end);
  const new_text = block_text
    .split("\n")
    .map((line) => indent_unit + line)
    .join("\n");

  ReplaceTextareaRange(textarea, block_start, block_end, new_text);
  textarea.selectionStart = start + indent_unit.length;
  textarea.selectionEnd = end + indent_unit.length * (new_text.split("\n").length);
  textarea.dispatchEvent(new Event("input"));
}

function LinePrefixesCloser(text) {
  return /^[ \t]*(end\b|until\b|else\b|elseif\b|\})/.test(text.trim());
}

function FirstNonBlankLineBelow(value, from_index) {
  let search_start = from_index;

  while (search_start < value.length) {
    const line_end_index = value.indexOf("\n", search_start);
    const end = line_end_index === -1 ? value.length : line_end_index;
    const line = value.slice(search_start, end);

    if (line.trim().length > 0) {
      return line;
    }

    search_start = end + 1;
  }

  return null;
}

function CloserFollowsCaret(value, caret_index) {
  const line_end = GetLineEnd(value, caret_index);
  const line_remainder = value.slice(caret_index, line_end);

  if (LinePrefixesCloser(line_remainder)) {
    return true;
  }

  const next_line = FirstNonBlankLineBelow(value, line_end);
  return next_line !== null && LinePrefixesCloser(next_line);
}

function HandleEditorEnterKey(event, textarea) {
  const start = textarea.selectionStart;
  const value = textarea.value;
  const line_start = GetLineStart(value, start);
  const current_line = value.slice(line_start, start);
  const indent_match = current_line.match(/^[ \t]*/);
  const base_indent = indent_match ? indent_match[0] : "";
  let indent = base_indent;

  const trimmed_line = current_line.trim();
  const opens_block = /(?:^|[^A-Za-z0-9_])(then|do|repeat)$/.test(trimmed_line)
    || /\bfunction\b.*\)$/.test(trimmed_line);

  const closer_match = current_line.match(/^([ \t]*)(end\b|until\b|else\b|elseif\b|\})/);

  if (closer_match) {
    indent = closer_match[1];
  }

  const has_closer_after = CloserFollowsCaret(value, start);

  if (!opens_block || has_closer_after) {
    event.preventDefault();
    const end = textarea.selectionEnd;
    ReplaceTextareaRange(textarea, start, end, "\n" + indent);
    textarea.dispatchEvent(new Event("input"));
    return;
  }

  const end_sel = textarea.selectionEnd;
  const closer = trimmed_line.endsWith("repeat") ? "until true" : "end";

  event.preventDefault();

  const inserted = `\n${indent}\n${base_indent}${closer}`;
  ReplaceTextareaRange(textarea, start, end_sel, inserted);
  const cursor_pos = start + 1 + indent.length;
  textarea.selectionStart = textarea.selectionEnd = cursor_pos;

  textarea.dispatchEvent(new Event("input"));
}

const EDITOR_AUTO_CLOSE_PAIRS = {
  "(": ")",
  "[": "]",
  "{": "}",
  '"': '"',
  "'": "'",
};

const EDITOR_AUTO_CLOSE_CLOSERS = new Set(Object.values(EDITOR_AUTO_CLOSE_PAIRS));

function HandleEditorAutoCloseKey(event, textarea) {
  const key = event.key;
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const value = textarea.value;

  if (start !== end && Object.prototype.hasOwnProperty.call(EDITOR_AUTO_CLOSE_PAIRS, key)) {
    event.preventDefault();
    const closer = EDITOR_AUTO_CLOSE_PAIRS[key];
    const selected = value.slice(start, end);
    ReplaceTextareaRange(textarea, start, end, key + selected + closer);
    textarea.selectionStart = start + 1;
    textarea.selectionEnd = start + 1 + selected.length;
    textarea.dispatchEvent(new Event("input"));
    return true;
  }

  if (start !== end) {
    return false;
  }

  if (Object.prototype.hasOwnProperty.call(EDITOR_AUTO_CLOSE_PAIRS, key)) {
    const next_char = value[start] || "";
    const is_quote = key === '"' || key === "'";

    if (is_quote && next_char === key) {
      event.preventDefault();
      textarea.selectionStart = textarea.selectionEnd = start + 1;
      UpdateSelectionAndCaret();
      return true;
    }

    const should_skip_typed_char = is_quote && /[A-Za-z0-9_]$/.test(value.slice(0, start));

    if (should_skip_typed_char) {
      return false;
    }

    event.preventDefault();
    const closer = EDITOR_AUTO_CLOSE_PAIRS[key];
    ReplaceTextareaRange(textarea, start, start, key + closer);
    textarea.selectionStart = textarea.selectionEnd = start + 1;
    textarea.dispatchEvent(new Event("input"));
    return true;
  }

  if (EDITOR_AUTO_CLOSE_CLOSERS.has(key) && value[start] === key) {
    event.preventDefault();
    textarea.selectionStart = textarea.selectionEnd = start + 1;
    UpdateSelectionAndCaret();
    return true;
  }

  return false;
}

function HandleEditorPairBackspace(event, textarea) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;

  if (start !== end || start === 0) {
    return false;
  }

  const value = textarea.value;
  const prev_char = value[start - 1];
  const next_char = value[start];

  if (EDITOR_AUTO_CLOSE_PAIRS[prev_char] !== next_char) {
    return false;
  }

  event.preventDefault();
  ReplaceTextareaRange(textarea, start - 1, start + 1, "");
  textarea.dispatchEvent(new Event("input"));
  return true;
}

function HandleEditorKeydown(event) {
  const textarea = event.target;

  if (EDITOR_SUGGEST_STATE.visible) {
    if (HandleSuggestNavKey(event.key)) {
      event.preventDefault();
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      DismissSuggestPopup(textarea);
      EndSnippetSession();
      return;
    }

    const accepts_snippet = event.key === "Enter" || (event.key === "Tab" && !event.shiftKey);

    if (accepts_snippet && EDITOR_SUGGEST_STATE.items.length > 0) {
      event.preventDefault();
      ConfirmSuggestSelection(textarea);
      return;
    }

    HideSuggestPopup();
  }

  if (event.key === "Escape" && IsSnippetSessionActive(textarea)) {
    event.preventDefault();
    EndSnippetSession();
    return;
  }

  if (event.key === "Tab") {
    HandleEditorTabKey(event, textarea);
    return;
  }

  if (event.key === "Enter") {
    HandleEditorEnterKey(event, textarea);
    return;
  }

  if (!event.ctrlKey && !event.metaKey && !event.altKey && HandleEditorAutoCloseKey(event, textarea)) {
    return;
  }

  if (event.key === "Backspace" && HandleEditorPairBackspace(event, textarea)) {
    return;
  }

  if (event.ctrlKey && event.code === "Space") {
    event.preventDefault();
    EDITOR_SUGGEST_STATE.dismissed = false;
    UpdateSuggestPopup(textarea, true);
    return;
  }

  const is_mod = event.ctrlKey || event.metaKey;

  if (is_mod && !event.shiftKey && !event.altKey && event.key === "/") {
    event.preventDefault();
    ToggleEditorLineComment();
    return;
  }

  if (is_mod && !event.shiftKey && !event.altKey && event.key.toLowerCase() === "d") {
    event.preventDefault();
    DuplicateEditorLine();
    return;
  }

  if (is_mod && !event.shiftKey && !event.altKey && event.key.toLowerCase() === "x") {
    if (!EditorHasSelection(textarea)) {
      event.preventDefault();
    }
    return;
  }

  if (event.altKey && event.shiftKey && event.key.toLowerCase() === "f") {
    event.preventDefault();
    FormatActiveEditor();
  }
}

function SetEditorSelection(textarea, start, end) {
  textarea.selectionStart = Math.min(start, end);
  textarea.selectionEnd = Math.max(start, end);
}

function HandleEditorMouseDown(event) {
  if (event.button !== 0) {
    return;
  }

  const textarea = event.currentTarget;
  const index = GetCharIndexFromClientPoint(event.clientX, event.clientY);

  event.preventDefault();
  textarea.focus();

  if (event.detail >= 3) {
    const value = textarea.value;
    const line_index = value.slice(0, index).split("\n").length - 1;
    const range = GetLineRange(value, line_index);
    const include_break = range.end < value.length ? 1 : 0;
    SetEditorSelection(textarea, range.start, range.end + include_break);
    EDITOR_POINTER_STATE.selecting = false;
    EDITOR_POINTER_STATE.anchor = range.start;
    UpdateActiveLineBox();
    UpdateSelectionAndCaret();
    HideSuggestPopup();
    return;
  }

  if (event.detail === 2) {
    const bounds = GetWordBounds(textarea.value, index);
    SetEditorSelection(textarea, bounds.start, bounds.end);
    EDITOR_POINTER_STATE.selecting = true;
    EDITOR_POINTER_STATE.anchor = bounds.start;
    UpdateActiveLineBox();
    UpdateSelectionAndCaret();
    return;
  }

  if (event.shiftKey) {
    SetEditorSelection(textarea, EDITOR_POINTER_STATE.anchor, index);
  } else {
    EDITOR_POINTER_STATE.anchor = index;
    SetEditorSelection(textarea, index, index);
  }

  EDITOR_POINTER_STATE.selecting = true;
  UpdateActiveLineBox();
  UpdateSelectionAndCaret();
}

function HandleEditorMouseMove(event) {
  if (!EDITOR_POINTER_STATE.selecting || event.buttons !== 1) {
    return;
  }

  const { textarea } = GetEditorEls();
  if (!textarea) {
    return;
  }

  const index = GetCharIndexFromClientPoint(event.clientX, event.clientY);
  SetEditorSelection(textarea, EDITOR_POINTER_STATE.anchor, index);
  UpdateActiveLineBox();
  UpdateSelectionAndCaret();
}

function HandleEditorMouseUp() {
  EDITOR_POINTER_STATE.selecting = false;
}

const EDITOR_FONT_SIZE_KEY = "editor_font_size_px";

function ClampEditorFontSize(font_size_px) {
  const next_size = Math.round(Number(font_size_px) || GetUiStateDefault(EDITOR_FONT_SIZE_KEY));
  return ClampUiStateNumber(EDITOR_FONT_SIZE_KEY, next_size);
}

function ApplyEditorFontSize(font_size_px) {
  const { textarea } = GetEditorEls();
  if (!textarea) {
    return;
  }

  const surface = document.querySelector(".editor-surface");
  if (surface) {
    const line_height_ratio = GetUiStateRangedNumber("editor_line_height");
    const line_height_px = Math.round(font_size_px * line_height_ratio);
    surface.style.setProperty("--ed-font-size", `${font_size_px}px`);
    surface.style.setProperty("--ed-line-height", `${line_height_px}px`);
  }

  InvalidateEditorMetrics();
  EDITOR_STATE.indent_key = null;
  RenderIndentGuides(textarea.value);
  SyncEditorScroll();
  UpdateActiveLineBox();
}

function ApplyEditorIndent() {
  const { textarea } = GetEditorEls();
  const surface = document.querySelector(".editor-surface");

  if (surface) {
    surface.style.setProperty("--ed-indent-width", String(Math.max(1, Math.round(Number(UI_STATE.editor_tab_size) || 4))));
  }

  if (!textarea) {
    return;
  }

  EDITOR_STATE.indent_key = null;
  InvalidateEditorMetrics();
  RenderIndentGuides(textarea.value);
  SyncEditorScroll();
  UpdateActiveLineBox();
}

const EDITOR_CARET_WIDTHS = {
  bar: "2px",
  block: "0.5em",
  underline: "1ch",
};

function ApplyEditorCaretStyle() {
  const { caret } = GetEditorEls();
  const surface = document.querySelector(".editor-surface");
  const style_name = UI_STATE.editor_caret_style || "bar";

  if (surface) {
    surface.style.setProperty("--ed-caret-width", EDITOR_CARET_WIDTHS[style_name] || EDITOR_CARET_WIDTHS.bar);
  }

  if (!caret) {
    return;
  }

  caret.classList.toggle("editor-caret-underline", style_name === "underline");

  if (style_name === "block") {
    caret.classList.remove("editor-caret-blink");
    return;
  }

  RestartCaretBlink(caret);
}

function ApplyEditorSelectionStyle() {
  if (UI_STATE.editor_selection_style === "rounded") {
    document.documentElement.dataset.selection = "rounded";
    return;
  }

  document.documentElement.removeAttribute("data-selection");
}

function SetEditorFontSize(font_size_px) {
  const next_size = ClampEditorFontSize(font_size_px);
  UI_STATE.editor_font_size_px = next_size;
  ApplyEditorFontSize(next_size);
  RefreshEditorMetrics();
  SaveUiState();
}

function SetEditorGutterVisible(is_visible) {
  const { gutter } = GetEditorEls();

  if (!gutter) {
    return;
  }

  gutter.style.display = is_visible ? "" : "none";
  RefreshEditorMetrics();
}

function SetEditorIndentGuidesVisible(is_visible) {
  const { indent_guides } = GetEditorEls();

  if (!indent_guides) {
    return;
  }

  indent_guides.style.display = is_visible ? "" : "none";
}

function SetEditorActiveLineVisible(is_visible) {
  if (!is_visible) {
    const { active_line_box } = GetEditorEls();

    if (active_line_box) {
      active_line_box.style.display = "none";
    }

    return;
  }

  UpdateActiveLineBox();
}

function IsPointerOverEditorSurface(client_x, client_y) {
  const surface = document.querySelector(".editor-surface");

  if (!surface) {
    return false;
  }

  const target_el = document.elementFromPoint(client_x, client_y);
  return Boolean(target_el && surface.contains(target_el));
}

function ShouldEditorOwnZoomShortcut() {
  if (IsPointerOverConsolePanel()) {
    return false;
  }

  return true;
}

function SetupEditorZoom() {
  window.addEventListener(
    "wheel",
    (event) => {
      if (!(event.ctrlKey || event.metaKey)) {
        return;
      }

      if (!IsPointerOverEditorSurface(event.clientX, event.clientY)) {
        return;
      }

      event.preventDefault();
      const current_size = GetUiStateRangedNumber(EDITOR_FONT_SIZE_KEY);
      const step = event.deltaY < 0 ? 1 : -1;
      SetEditorFontSize(current_size + step);
    },
    { passive: false, capture: true }
  );

  window.addEventListener("keydown", (event) => {
    if (!(event.ctrlKey || event.metaKey) || event.altKey) {
      return;
    }

    if (!ShouldEditorOwnZoomShortcut()) {
      return;
    }

    const key = event.key;
    const current_size = GetUiStateRangedNumber(EDITOR_FONT_SIZE_KEY);

    if (key === "=" || key === "+") {
      event.preventDefault();
      SetEditorFontSize(current_size + 1);
      return;
    }

    if (key === "-" || key === "_") {
      event.preventDefault();
      SetEditorFontSize(current_size - 1);
      return;
    }

    if (key === "0") {
      event.preventDefault();
      SetEditorFontSize(GetUiStateDefault(EDITOR_FONT_SIZE_KEY));
    }
  });
}

function GetLuaCodeForIndent(line) {
  let out = "";
  let quote = null;

  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];

    if (quote) {
      if (ch === "\\") {
        i += 1;
        continue;
      }

      if (ch === quote) {
        quote = null;
      }

      continue;
    }

    if (ch === "-" && line[i + 1] === "-") {
      break;
    }

    if (ch === '"' || ch === "'") {
      quote = ch;
      continue;
    }

    out += ch;
  }

  return out;
}

function CountLuaWord(code, word) {
  const re = new RegExp(`(?:^|[^A-Za-z0-9_])${word}(?=$|[^A-Za-z0-9_])`, "g");
  return (code.match(re) || []).length;
}

function FormatLuauSource(source) {
  const lines = source.replace(/\r\n/g, "\n").split("\n");
  let level = 0;
  const formatted = [];

  for (const line of lines) {
    const trimmed = line.trim();

    if (trimmed.length === 0) {
      formatted.push("");
      continue;
    }

    const code = GetLuaCodeForIndent(trimmed);
    const starts_dedent = /^(end|until|else|elseif)\b/.test(code) || code.startsWith("}");

    if (starts_dedent) {
      level = Math.max(0, level - 1);
    }

    formatted.push(GetEditorIndentUnit().repeat(level) + trimmed);

    const opens =
      CountLuaWord(code, "then") +
      CountLuaWord(code, "do") +
      CountLuaWord(code, "repeat") +
      CountLuaWord(code, "function") +
      (code.match(/\{/g) || []).length;
    const closes =
      CountLuaWord(code, "end") +
      CountLuaWord(code, "until") +
      (code.match(/\}/g) || []).length;

    level = Math.max(0, level + opens - closes + (starts_dedent ? 1 : 0));

    if (/^else\b/.test(code) && !/^elseif\b/.test(code)) {
      level += 1;
    }
  }

  return formatted.join("\n");
}

function FormatActiveEditor() {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  const formatted = FormatLuauSource(textarea.value);

  if (formatted === textarea.value) {
    return;
  }

  const caret = textarea.selectionStart;
  ReplaceTextareaRange(textarea, 0, textarea.value.length, formatted);
  const next_caret = Math.min(caret, formatted.length);
  textarea.selectionStart = textarea.selectionEnd = next_caret;
  textarea.dispatchEvent(new Event("input"));
}

function EditorHasSelection(textarea) {
  return textarea.selectionStart !== textarea.selectionEnd;
}

function RunEditorCommand(command_name) {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  textarea.focus();
  document.execCommand(command_name);
  textarea.dispatchEvent(new Event("input"));
}

async function ReadClipboardText() {
  if (window.__TAURI__ && window.__TAURI__.clipboardManager && window.__TAURI__.clipboardManager.readText) {
    return window.__TAURI__.clipboardManager.readText();
  }

  return window.__TAURI__.core.invoke("plugin:clipboard-manager|read_text");
}

async function PasteIntoEditor() {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  textarea.focus();

  try {
    const text = await ReadClipboardText();
    ReplaceTextareaRange(textarea, textarea.selectionStart, textarea.selectionEnd, text || "");
    textarea.dispatchEvent(new Event("input"));
  } catch (err) {
    console.warn("could not paste from clipboard:", err);
  }
}

function ToggleEditorLineComment() {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const value = textarea.value;
  const block_start = GetLineStart(value, start);
  const block_end = end > start ? GetLineEnd(value, Math.max(start, end - 1)) : GetLineEnd(value, start);
  const block_text = value.slice(block_start, block_end);
  const lines = block_text.split("\n");
  const code_lines = lines.filter((line) => line.trim().length > 0);
  const all_commented = code_lines.length > 0 && code_lines.every((line) => line.trimStart().startsWith("--"));

  const next_lines = lines.map((line) => {
    if (line.trim().length === 0) {
      return line;
    }

    if (all_commented) {
      return line.replace(/^(\s*)--\s?/, "$1");
    }

    const match = line.match(/^(\s*)/);
    const prefix = match ? match[1] : "";
    return `${prefix}-- ${line.slice(prefix.length)}`;
  });

  const new_text = next_lines.join("\n");
  ReplaceTextareaRange(textarea, block_start, block_end, new_text);
  textarea.selectionStart = block_start;
  textarea.selectionEnd = block_start + new_text.length;
  textarea.dispatchEvent(new Event("input"));
}

function DuplicateEditorLine() {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const value = textarea.value;

  if (start !== end) {
    ReplaceTextareaRange(textarea, end, end, value.slice(start, end));
    textarea.dispatchEvent(new Event("input"));
    return;
  }

  const line_start = GetLineStart(value, start);
  const line_end = GetLineEnd(value, start);
  const line_text = value.slice(line_start, line_end);
  ReplaceTextareaRange(textarea, line_end, line_end, "\n" + line_text);
  textarea.dispatchEvent(new Event("input"));
}

function ShowEditorContextMenu(event) {
  const { textarea } = GetEditorEls();

  if (!textarea || textarea.disabled) {
    return;
  }

  const has_selection = EditorHasSelection(textarea);

  ShowContextMenu(event.clientX, event.clientY, [
    { label: "Undo", icon_name: "undo", shortcut: "Ctrl+Z", on_click: () => RunEditorCommand("undo") },
    { label: "Redo", icon_name: "redo", shortcut: "Ctrl+Y", on_click: () => RunEditorCommand("redo") },
    { separator: true },
    { label: "Cut", icon_name: "cut", shortcut: "Ctrl+X", disabled: !has_selection, on_click: () => RunEditorCommand("cut") },
    { label: "Copy", icon_name: "copy", shortcut: "Ctrl+C", disabled: !has_selection, on_click: () => RunEditorCommand("copy") },
    { label: "Paste", icon_name: "paste", shortcut: "Ctrl+V", on_click: () => PasteIntoEditor() },
    { label: "Delete", icon_name: "trash", disabled: !has_selection, on_click: () => RunEditorCommand("delete") },
    { separator: true },
    { label: "Select All", icon_name: "selectall", shortcut: "Ctrl+A", on_click: () => RunEditorCommand("selectAll") },
    { label: "Duplicate", icon_name: "duplicate", shortcut: "Ctrl+D", on_click: () => DuplicateEditorLine() },
    { separator: true },
    { label: "Toggle Comment", icon_name: "comment", shortcut: "Ctrl+/", on_click: () => ToggleEditorLineComment() },
    { label: "Indent", icon_name: "indentin", shortcut: "Tab", on_click: () => HandleEditorTabKey({ preventDefault() {}, shiftKey: false }, textarea) },
    { label: "Outdent", icon_name: "indentout", shortcut: "Shift+Tab", on_click: () => HandleEditorTabKey({ preventDefault() {}, shiftKey: true }, textarea) },
    { separator: true },
    { label: "Format Document", icon_name: "align", shortcut: "Shift+Alt+F", on_click: () => FormatActiveEditor() },
    { separator: true },
    { label: "Zoom In", icon_name: "zoomin", shortcut: "Ctrl+=", on_click: () => SetEditorFontSize(GetUiStateRangedNumber(EDITOR_FONT_SIZE_KEY) + 1) },
    { label: "Zoom Out", icon_name: "zoomout", shortcut: "Ctrl+-", on_click: () => SetEditorFontSize(GetUiStateRangedNumber(EDITOR_FONT_SIZE_KEY) - 1) },
    { label: "Reset Zoom", icon_name: "resetzoom", shortcut: "Ctrl+0", on_click: () => SetEditorFontSize(GetUiStateDefault(EDITOR_FONT_SIZE_KEY)) },
  ]);
}

function SetupEditorContextMenu() {
  const { textarea } = GetEditorEls();
  const surface = document.querySelector(".editor-surface");

  const OnContextMenu = (event) => {
    event.preventDefault();
    event.stopPropagation();
    ShowEditorContextMenu(event);
  };

  if (textarea) {
    textarea.addEventListener("contextmenu", OnContextMenu);
  }

  if (surface) {
    surface.addEventListener("contextmenu", OnContextMenu);
  }
}

function RefreshEditorMetrics() {
  const { textarea } = GetEditorEls();
  if (!textarea) {
    return;
  }

  InvalidateEditorMetrics();
  EDITOR_STATE.indent_key = null;
  RenderEditorHighlight(textarea.value);
  SyncEditorScroll();
  UpdateActiveLineBox();
}

function SetupEditorSurface() {
  const { textarea, scroll, suggest_popup } = GetEditorEls();
  if (!textarea || !scroll) {
    return;
  }

  if (suggest_popup && suggest_popup.parentElement !== document.body) {
    document.body.appendChild(suggest_popup);
  }

  textarea.addEventListener("input", () => {
    ScheduleLinter();
    ScheduleEditorFrame(true);
  });

  textarea.addEventListener("keydown", HandleEditorKeydown);
  textarea.addEventListener("keyup", () => {
    ScheduleEditorFrame();
  });

  textarea.addEventListener("mousedown", HandleEditorMouseDown);
  window.addEventListener("mousemove", HandleEditorMouseMove);
  window.addEventListener("mouseup", HandleEditorMouseUp);

  textarea.addEventListener("blur", () => {
    UpdateCustomCaret();
    RenderSelectionOverlay();
  });

  textarea.addEventListener("focus", UpdateSelectionAndCaret);
  document.addEventListener("selectionchange", () => {
    if (document.activeElement !== textarea) {
      return;
    }
    if (!EDITOR_POINTER_STATE.selecting && textarea.selectionStart === textarea.selectionEnd) {
      EDITOR_POINTER_STATE.anchor = textarea.selectionStart;
    }
    ScheduleEditorFrame();
  });

  scroll.addEventListener("scroll", SyncEditorScroll);
  window.addEventListener("resize", RefreshEditorMetrics);

  const saved_size = ClampEditorFontSize(GetUiStateRangedNumber(EDITOR_FONT_SIZE_KEY));
  UI_STATE.editor_font_size_px = saved_size;
  ApplyEditorFontSize(saved_size);
  SetupEditorZoom();
  SetupEditorContextMenu();
  RefreshEditorMetrics();
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => {
      EDITOR_STATE.fonts_ready = true;
      RefreshEditorMetrics();
    });
  }
}

function RefreshEditorAfterTabSwitch() {
  const { textarea, scroll } = GetEditorEls();
  if (!textarea || !scroll) {
    return;
  }

  EDITOR_STATE.indent_key = null;
  EDITOR_STATE.caret_index = -1;
  RenderEditorHighlight(textarea.value);
  scroll.scrollTop = 0;
  scroll.scrollLeft = 0;
  HideSuggestPopup();
  LINTER_STATE.source = null;
  RunLinter();
  SyncEditorScroll();
  UpdateActiveLineBox();
  RenderSelectionOverlay();
}
