const LINTER_MAX_DIAGNOSTICS = 60;
const LINTER_DEBOUNCE_MS = 320;
const LINTER_MAX_SOURCE_CHARS = 400000;

const LINTER_STATE = {
  timer_id: null,
  diagnostics: [],
  source: null,
  open: false,
};

function IsWordChar(ch) {
  return Boolean(ch) && /[A-Za-z0-9_]/.test(ch);
}

function LinterPush(list, line, message) {
  if (list.length >= LINTER_MAX_DIAGNOSTICS) {
    return;
  }

  list.push({ line: line, message: message });
}

function LinterOpenLevelAt(text, bracket_index) {
  if (text[bracket_index] !== "[") {
    return null;
  }

  let level = 0;
  let i = bracket_index + 1;

  while (text[i] === "=") {
    level += 1;
    i += 1;
  }

  if (text[i] !== "[") {
    return null;
  }

  return level;
}

function LinterCloseLevelAt(text, bracket_index) {
  if (text[bracket_index] !== "]") {
    return null;
  }

  let level = 0;
  let i = bracket_index + 1;

  while (text[i] === "=") {
    level += 1;
    i += 1;
  }

  if (text[i] !== "]") {
    return null;
  }

  return level;
}

function LinterLongBodyStart(text, open_bracket_index, level) {
  return open_bracket_index + level + 2;
}

function LinterFindLongEnd(text, from, level) {
  const length = text.length;
  let i = from;

  while (i < length) {
    if (text[i] === "]" && LinterCloseLevelAt(text, i) === level) {
      return i;
    }

    i += 1;
  }

  return -1;
}

function LinterFindLoopDo(text, from) {
  let i = from;
  let depth = 0;
  const length = text.length;

  while (i < length) {
    const ch = text[i];

    if (ch === "(" || ch === "[" || ch === "{") {
      depth += 1;
      i += 1;
      continue;
    }

    if (ch === ")" || ch === "]" || ch === "}") {
      depth -= 1;
      i += 1;
      continue;
    }

    if (ch === "-" && text[i + 1] === "-") {
      while (i < length && text[i] !== "\n") {
        i += 1;
      }

      continue;
    }

    if (depth === 0 && IsWordChar(ch) && !IsWordChar(text[i - 1]) && text[i - 1] !== "." && text[i - 1] !== ":") {
      let end = i;

      while (end < length && IsWordChar(text[end])) {
        end += 1;
      }

      const word = text.slice(i, end);

      if (word === "do") {
        return end;
      }

      if (word === "end" || word === "until" || word === "repeat" || word === "function" || word === "if" || word === "for" || word === "while") {
        return -1;
      }

      i = end;
      continue;
    }

    i += 1;
  }

  return -1;
}

function LintLuau(source) {
  const raw = String(source == null ? "" : source);
  const out = [];
  const brackets = [];
  const blocks = [];
  const length = raw.length;
  let line = 1;
  let i = 0;
  let long_kind = "";
  let long_level = 0;
  let long_line = 0;
  let skip_to = -1;

  const CountLines = (text) => {
    let n = 0;
    let k = 0;

    while (k < text.length) {
      if (text[k] === "\n") {
        n += 1;
      }

      k += 1;
    }

    return n;
  };

  const PushBlock = (kind, at_line, needs_then) => {
    blocks.push({ kind: kind, line: at_line, needs_then: Boolean(needs_then) });
  };

  const PopBlock = () => {
    if (blocks.length === 0) {
      return null;
    }

    return blocks.pop();
  };

  while (i < length) {
    const ch = raw[i];

    if (skip_to > i) {
      if (ch === "\n") {
        line += 1;
      }

      i += 1;
      continue;
    }

    if (long_kind) {
      if (ch === "]" && LinterCloseLevelAt(raw, i) === long_level) {
        i += long_level + 2;
        long_kind = "";
        long_level = 0;
        continue;
      }

      if (ch === "\n") {
        line += 1;
      }

      i += 1;
      continue;
    }

    if (ch === "\n") {
      line += 1;
      i += 1;
      continue;
    }

    if (ch === " " || ch === "\t" || ch === "\r") {
      i += 1;
      continue;
    }

    if (ch === "-" && raw[i + 1] === "-") {
      if (raw[i + 2] === "[") {
        const level = LinterOpenLevelAt(raw, i + 2);

        if (level !== null) {
          long_kind = "comment";
          long_level = level;
          long_line = line;
          i = LinterLongBodyStart(raw, i + 2, level);
          continue;
        }
      }

      while (i < length && raw[i] !== "\n") {
        i += 1;
      }

      continue;
    }

    if (ch === "\"" || ch === "'" || ch === "`") {
      let k = i + 1;
      let closed = false;

      while (k < length) {
        const c = raw[k];

        if (c === "\\") {
          k += 2;
          continue;
        }

        if (c === "\n") {
          break;
        }

        if (c === ch) {
          closed = true;
          k += 1;
          break;
        }

        k += 1;
      }

      if (!closed) {
        LinterPush(out, line, "this string is never closed");
      }

      i = k;
      continue;
    }

    if (ch === "[" && (raw[i + 1] === "[" || raw[i + 1] === "=")) {
      const level = LinterOpenLevelAt(raw, i);

      if (level !== null) {
        const body = LinterLongBodyStart(raw, i, level);
        const at = LinterFindLongEnd(raw, body, level);

        if (at < 0) {
          LinterPush(out, line, "this long string is never closed");
          i = length;
          continue;
        }

        line += CountLines(raw.slice(i, at));
        i = at + level + 2;
        continue;
      }
    }

    if (ch === "(" || ch === "[" || ch === "{") {
      brackets.push({ ch: ch, line: line });
      i += 1;
      continue;
    }

    if (ch === ")" || ch === "]" || ch === "}") {
      const top = brackets[brackets.length - 1];
      const want = ch === ")" ? "(" : ch === "]" ? "[" : "{";

      if (!top || top.ch !== want) {
        LinterPush(out, line, "unexpected " + ch);
      } else {
        brackets.pop();
      }

      i += 1;
      continue;
    }

    if (IsWordChar(ch) && !IsWordChar(raw[i - 1]) && raw[i - 1] !== "." && raw[i - 1] !== ":") {
      let end = i;

      while (end < length && IsWordChar(raw[end])) {
        end += 1;
      }

      const lower = raw.slice(i, end).toLowerCase();

      if (lower === "end") {
        const frame = PopBlock();

        if (!frame) {
          LinterPush(out, line, "end without a matching block");
        } else if (frame.kind === "repeat") {
          LinterPush(out, line, "this repeat is closed with end, it needs until");
          LinterPush(out, frame.line, "this repeat is never closed with until");
        } else if (frame.needs_then) {
          LinterPush(out, frame.line, "this if is missing a then");
        }
      } else if (lower === "until") {
        const frame = PopBlock();

        if (!frame) {
          LinterPush(out, line, "until without a matching repeat");
        } else if (frame.kind !== "repeat") {
          LinterPush(out, line, "this " + frame.kind + " is closed with until, it needs end");
          LinterPush(out, frame.line, "this " + frame.kind + " is never closed with end");
        }
      } else if (lower === "then") {
        for (let k = blocks.length - 1; k >= 0; k -= 1) {
          if (blocks[k].needs_then) {
            blocks[k].needs_then = false;
            break;
          }
        }
      } else if (lower === "else" || lower === "elseif") {
        for (let k = blocks.length - 1; k >= 0; k -= 1) {
          if (blocks[k].kind === "if") {
            blocks[k].needs_then = lower === "elseif";
            break;
          }
        }
      } else if (lower === "for" || lower === "while") {
        const do_end = LinterFindLoopDo(raw, end);

        if (do_end > 0) {
          skip_to = do_end;
        } else {
          LinterPush(out, line, "this " + lower + " is missing a do");
        }

        PushBlock(lower, line, false);
      } else if (lower === "function") {
        PushBlock("function", line, false);
      } else if (lower === "if") {
        PushBlock("if", line, true);
      } else if (lower === "do") {
        PushBlock("do", line, false);
      } else if (lower === "repeat") {
        PushBlock("repeat", line, false);
      }

      i = end;
      continue;
    }

    i += 1;
  }

  if (long_kind === "comment") {
    LinterPush(out, long_line, "this comment is never closed");
  } else if (long_kind) {
    LinterPush(out, long_line, "this long string is never closed");
  }

  for (let k = brackets.length - 1; k >= 0; k -= 1) {
    LinterPush(out, brackets[k].line, "this " + brackets[k].ch + " is never closed");
  }

  for (let k = blocks.length - 1; k >= 0; k -= 1) {
    const frame = blocks[k];

    if (frame.kind === "repeat") {
      LinterPush(out, frame.line, "this repeat is never closed with until");
      continue;
    }

    if (frame.needs_then) {
      LinterPush(out, frame.line, "this if is missing a then");
      continue;
    }

    LinterPush(out, frame.line, "this " + frame.kind + " is never closed with end");
  }

  out.sort((a, b) => a.line - b.line);
  return out;
}

function GetLinterEls() {
  return {
    strip: document.getElementById("editor-problems"),
    summary: document.getElementById("editor-problems-summary"),
    count: document.getElementById("editor-problems-count"),
    list: document.getElementById("editor-problems-list"),
    chevron: document.getElementById("editor-problems-chevron"),
  };
}

function RenderLinter() {
  const { strip, count, list, chevron } = GetLinterEls();

  if (!strip || !count || !list) {
    return;
  }

  const diagnostics = LINTER_STATE.diagnostics;

  if (chevron) {
    chevron.textContent = LINTER_STATE.open ? "\u25be" : "\u25b8";
  }

  if (diagnostics.length === 0) {
    strip.classList.add("editor-problems-hidden");
    list.innerHTML = "";
    return;
  }

  strip.classList.remove("editor-problems-hidden");
  count.textContent = String(diagnostics.length);

  const fragment = document.createDocumentFragment();

  for (const item of diagnostics) {
    const row = document.createElement("button");
    row.className = "editor-problem-row";
    row.type = "button";

    const icon = document.createElement("span");
    icon.className = "editor-problem-icon";
    icon.textContent = "x";
    row.appendChild(icon);

    const where = document.createElement("span");
    where.className = "editor-problem-where";
    where.textContent = "line " + item.line;
    row.appendChild(where);

    const text = document.createElement("span");
    text.className = "editor-problem-text";
    text.textContent = item.message;
    row.appendChild(text);

    row.addEventListener("click", () => JumpToLinterLine(item.line));

    fragment.appendChild(row);
  }

  list.innerHTML = "";
  list.appendChild(fragment);
}

function JumpToLinterLine(target_line) {
  const { textarea } = GetEditorEls();

  if (!textarea) {
    return;
  }

  const lines = textarea.value.split("\n");
  const index = Math.min(Math.max(target_line - 1, 0), Math.max(0, lines.length - 1));
  let offset = 0;

  for (let k = 0; k < index; k += 1) {
    offset += lines[k].length + 1;
  }

  textarea.focus();
  textarea.selectionStart = offset;
  textarea.selectionEnd = offset + lines[index].length;
  UpdateSelectionAndCaret();
}

function IsLinterEnabled() {
  return UI_STATE.show_problems !== false;
}

function SetEditorProblemsVisible(is_visible) {
  const { strip } = GetLinterEls();

  if (strip) {
    strip.style.display = is_visible ? "" : "none";
  }

  if (!is_visible) {
    LINTER_STATE.source = null;
    return;
  }

  RunLinter();
}

function RunLinter() {
  const { textarea } = GetEditorEls();

  if (!textarea || !IsLinterEnabled()) {
    return;
  }

  const source = textarea.value;

  if (source === LINTER_STATE.source) {
    return;
  }

  LINTER_STATE.source = source;

  if (source.length > LINTER_MAX_SOURCE_CHARS) {
    if (LINTER_STATE.diagnostics.length > 0) {
      LINTER_STATE.diagnostics = [];
      RenderLinter();
    }
    return;
  }

  LINTER_STATE.diagnostics = LintLuau(source);
  RenderLinter();
}

function ScheduleLinter() {
  if (LINTER_STATE.timer_id !== null) {
    clearTimeout(LINTER_STATE.timer_id);
  }

  LINTER_STATE.timer_id = setTimeout(() => {
    LINTER_STATE.timer_id = null;
    RunLinter();
  }, LINTER_DEBOUNCE_MS);
}

function ToggleLinterList() {
  const { strip } = GetLinterEls();

  if (!strip) {
    return;
  }

  LINTER_STATE.open = !LINTER_STATE.open;
  strip.classList.toggle("editor-problems-open", LINTER_STATE.open);
  RenderLinter();
}

function SetupLinter() {
  const { strip, summary } = GetLinterEls();

  if (!strip) {
    return;
  }

  if (summary) {
    summary.addEventListener("click", ToggleLinterList);
  }

  RunLinter();
}
