const LUA_KEYWORDS = new Set([
  "and", "break", "do", "else", "elseif", "end", "for", "function", "goto",
  "if", "in", "local", "not", "or", "repeat", "return", "then", "until", "while",
]);

const LUA_BUILTINS = new Set([
  "assert", "collectgarbage", "dofile", "error", "getmetatable", "ipairs",
  "load", "loadfile", "next", "pairs", "pcall", "print", "rawequal", "rawget",
  "rawlen", "rawset", "require", "select", "setmetatable", "tonumber",
  "tostring", "type", "xpcall", "unpack",
  "coroutine", "debug", "io", "math", "os", "package", "string", "table", "utf8",
  "_G", "_ENV", "_VERSION",
]);

const LUA_TOKEN_RULES = [
  { class_name: "tok-comment", regex: /^--\[(=*)\[[\s\S]*?\]\1\]/ },
  { class_name: "tok-comment", regex: /^--[^\n]*/ },
  { class_name: "tok-string", regex: /^\[(=*)\[[\s\S]*?\]\1\]/ },
  { class_name: "tok-string", regex: /^"(?:\\[\s\S]|[^"\\\n])*"?/ },
  { class_name: "tok-string", regex: /^'(?:\\[\s\S]|[^'\\\n])*'?/ },
  { class_name: "tok-number", regex: /^0[xX][0-9a-fA-F]*\.?[0-9a-fA-F]*(?:[pP][+-]?\d+)?/ },
  { class_name: "tok-number", regex: /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/ },
  { class_name: "tok-word", regex: /^[A-Za-z_][A-Za-z0-9_]*/ },
  { class_name: "tok-vararg", regex: /^\.\.\./ },
  { class_name: "tok-operator", regex: /^(?:==|~=|<=|>=|\.\.|::|\/\/|<<|>>|[+\-*\/%^#<>=&|~])/ },
  { class_name: "tok-punctuation", regex: /^[(){}\[\],;.:]/ },
  { class_name: "tok-plain", regex: /^\s+/ },
];

const LUA_TOKEN_MATCHERS = LUA_TOKEN_RULES.map((rule) => ({
  class_name: rule.class_name,
  regex: new RegExp(rule.regex.source.replace(/^\^/, ""), "y"),
}));

function ClassifyLuaWord(word) {
  if (word === "true" || word === "false") {
    return "tok-boolean";
  }
  if (word === "nil") {
    return "tok-nil";
  }
  if (word === "self") {
    return "tok-self";
  }
  if (LUA_KEYWORDS.has(word)) {
    return "tok-keyword";
  }
  if (LUA_BUILTINS.has(word)) {
    return "tok-builtin";
  }
  return "tok-ident";
}

function TokenizeLuaRange(source_text, start_index, end_index) {
  const tokens = [];
  let cursor = start_index;

  while (cursor < end_index) {
    let matched_text = null;
    let class_name = null;

    for (const rule of LUA_TOKEN_MATCHERS) {
      rule.regex.lastIndex = cursor;
      const match = rule.regex.exec(source_text);

      if (match && match[0].length > 0) {
        matched_text = match[0];
        class_name = rule.class_name;
        break;
      }
    }

    if (matched_text === null) {
      matched_text = source_text[cursor];
      class_name = "tok-plain";
    }

    if (class_name === "tok-word") {
      class_name = ClassifyLuaWord(matched_text);
    }

    tokens.push({ text: matched_text, class_name });
    cursor += matched_text.length;
  }

  return tokens;
}

function EscapeHtmlForEditor(raw_text) {
  if (raw_text.indexOf("&") === -1 && raw_text.indexOf("<") === -1 && raw_text.indexOf(">") === -1) {
    return raw_text;
  }

  return raw_text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function HighlightLuauRangeToHtml(source_text) {
  let html_out = "";

  for (const token of TokenizeLuaRange(source_text, 0, source_text.length)) {
    const escaped = EscapeHtmlForEditor(token.text);

    if (token.class_name === "tok-plain") {
      html_out += escaped;
    } else {
      html_out += `<span class="${token.class_name}">${escaped}</span>`;
    }
  }

  return html_out;
}

function HighlightLuauChunkToHtml(source_text, start_offset, end_offset) {
  let slice = source_text.slice(start_offset, end_offset);

  if (slice.endsWith("\n")) {
    slice = slice.slice(0, -1);
  }

  return HighlightLuauRangeToHtml(slice);
}

function HighlightLuauToHtml(source_text, window_start, window_end) {
  const length = source_text.length;
  const from = window_start > 0 ? Math.min(window_start, length) : 0;
  const to = window_end > 0 && window_end < length ? window_end : length;

  let html_out = "";

  if (from > 0) {
    html_out += EscapeHtmlForEditor(source_text.slice(0, from));
  }

  html_out += HighlightLuauRangeToHtml(source_text.slice(from, to));

  if (to < length) {
    html_out += EscapeHtmlForEditor(source_text.slice(to));
  }

  if (length === 0 || source_text.endsWith("\n")) {
    html_out += " ";
  }

  return html_out;
}
