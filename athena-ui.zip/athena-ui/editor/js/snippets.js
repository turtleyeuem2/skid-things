const SNIPPETS_STATE = {
  by_prefix: new Map(),
  all: [],
  loaded: false,
};

const BUFFER_SYMBOL_STATE = {
  key: null,
  symbols: [],
};

const SNIPPET_SESSION = {
  active: false,
  base: 0,
  text: "",
  stops: [],
  index: 0,
};

const DEFAULT_SNIPPETS_URL = "editor/json/snippets.json";

const FALLBACK_SNIPPETS_JSON = {
  snippets: [
    { prefix: "print", name: "print", description: "print a value to the output", documentation: "Prints a value to the output window.", body: "print(${0})" },
    { prefix: "fn", name: "local function", description: "declare a local named function", documentation: "A function scoped to the current file/block.", body: "local function ${1:FunctionName}(${2:})\n\t${0}\nend" },
    { prefix: "if", name: "if", description: "basic if block", documentation: "Runs the body only when the condition is truthy.", body: "if ${1:condition} then\n\t${0}\nend" },
    { prefix: "ife", name: "if else", description: "if with an else branch", documentation: "Runs the second body when the condition is falsy.", body: "if ${1:condition} then\n\t${2}\nelse\n\t${0}\nend" },
    { prefix: "fori", name: "numeric for", description: "counted loop from a to b", documentation: "Counts from a to b, stepping by 1 unless a step is given.", body: "for ${1:i} = ${2:1}, ${3:10} do\n\t${0}\nend" },
    { prefix: "forp", name: "pairs loop", description: "walk a table key by key", documentation: "Iterates over every key in a table.", body: "for ${1:key}, ${2:value} in pairs(${3:table}) do\n\t${0}\nend" },
    { prefix: "forip", name: "ipairs loop", description: "walk the array part of a table", documentation: "Iterates an array in order from 1 to the last value.", body: "for ${1:index}, ${2:value} in ipairs(${3:array}) do\n\t${0}\nend" },
    { prefix: "while", name: "while", description: "while loop", documentation: "Keeps running while the condition holds.", body: "while ${1:condition} do\n\t${0}\nend" },
    { prefix: "repeat", name: "repeat", description: "repeat until loop", documentation: "Runs at least once, then keeps going until the condition holds.", body: "repeat\n\t${0}\nuntil ${1:condition}" },
    { prefix: "try", name: "pcall", description: "call something safely", documentation: "Returns the success flag first, then the results or the error.", body: "local ${1:ok}, ${2:result} = pcall(${3:target})" },
    { prefix: "spawn", name: "task.spawn", description: "run a function on a new thread", documentation: "Starts the function and carries on immediately.", body: "task.spawn(function()\n\t${0}\nend)" },
    { prefix: "delay", name: "task.delay", description: "run a function after a wait", documentation: "Waits, then runs the function on its own thread.", body: "task.delay(${1:1}, function()\n\t${0}\nend)" },
    { prefix: "connect", name: "connect", description: "connect to a signal", documentation: "Holds the connection so you can disconnect it later.", body: "local ${1:connection} = ${2:signal}:Connect(function(${3:...})\n\t${0}\nend)" },
    { prefix: "get", name: "chained find", description: "wait for a nested child", documentation: "Walks a chain of children, waiting for each one.", body: "${1:game}:WaitForChild(\"${2:Service}\"):WaitForChild(\"${3:Name}\")" },
    { prefix: "hook", name: "hookmetamethod", description: "hook a metamethod and keep the original", documentation: "Holds the original so you can undo the hook later.", body: "local ${1:old} = hookmetamethod(${2:object}, \"${3:metamethod}\", function(${4:...})\n\t${0}\n\treturn ${1:old}(...)\nend)" },
  ],
};

function LanguageSnippet(prefix, name, description, documentation, body, kind = "keyword") {
  return { prefix, name, kind, description, documentation, body };
}

const LUAU_LANGUAGE_SNIPPETS = [
  LanguageSnippet("local", "local", "declare a local variable.", `local <name> = <value>
Declares a name scoped to the current block.
args:
- name: the variable being declared.
- value: what it starts out as.
note:
The name is dropped at the end of the block, so it cannot leak into other files.
example:
local Players = game:GetService("Players")`, "local ${1:name} = ${0}"),

  LanguageSnippet("localt", "typed local", "declare a local with an explicit Luau type.", `local <name>: <type> = <value>
Declares a local with an explicit Luau type.
args:
- name: the variable being declared.
- type: the Luau type, such as number, Part or { x: number }.
- value: what it starts out as.
note:
Annotate anything the type checker should check for you, so mistakes show up before you run.
example:
local target: Instance = workspace:WaitForChild("Target")`, "local ${1:name}: ${2:any} = ${0}"),

  LanguageSnippet("localf", "local function", "declare a local named function.", `local function <name>(<args>)
Declares a function only this file can see.
args:
- name: the function name.
- args: the parameters, comma separated.
note:
Prefer this over a global function so two files can use the same name safely.
example:
local function greet(player)
	print("hi " .. player.Name)
end`, "local function ${1:name}(${2})\n\t${0}\nend"),

  LanguageSnippet("locals", "one line local function", "declare a short local function on one line.", `local function <name>(<args>) ... end
Keeps a tiny function on one line.
args:
- name: the function name.
- args: the parameters, comma separated.
note:
Good for one line wrappers, bad for anything you will grow later.
example:
local function double(n) return n * 2 end`, "local function ${1:name}(${2}) ${0} end"),

  LanguageSnippet("function", "function", "declare a named function.", `function <name>(<args>)
Declares a function with its own name.
args:
- name: the function name.
- args: the parameters, comma separated.
note:
A function can call itself by name, which is what makes plain recursion work.
example:
function add(a, b)
	return a + b
end`, "function ${1:name}(${2})\n\t${0}\nend"),

  LanguageSnippet("method", "method", "declare a method on a class.", `function <Class>:<method>(<args>)
Declares a method that takes self as its first argument.
args:
- Class: the class the method hangs off.
- method: the method name.
- args: the parameters after self.
note:
Inside a method, self is the instance it was called on.
example:
function Sword:Equip(player)
	self.owner = player
end`, "function ${1:ClassName}:${2:MethodName}(${3})\n\t${0}\nend"),

  LanguageSnippet("return", "return", "hand a value back to the caller.", `return <value>
Ends the function and hands values back to whoever called it.
args:
- value: what to hand back. A bare return gives nil.
note:
Lua allows several return values, so a function can hand back more than one.
example:
function split(text)
	return text:match("^(.-)"), text:match("(.+)$")
end`, "return ${0}"),

  LanguageSnippet("returnf", "return function", "return an inline function.", `return function(<args>)
Ends the function by handing back another one.
args:
- args: the parameters of the returned function.
note:
The inner function is built fresh every time the outer one runs.
example:
local function adder(n)
	return function(x)
		return x + n
	end
end`, "return function(${1})\n\t${0}\nend"),

  LanguageSnippet("if", "if", "run a block when a condition holds.", `if <condition> then ... end
Runs the block only when the condition is truthy.
args:
- condition: anything except nil or false is true.
note:
Anything falsy falls through to the else, so a nil field quietly lands in the wrong branch.
example:
if player then
	print(player.Name)
end`, "if ${1:condition} then\n\t${0}\nend"),

  LanguageSnippet("ife", "if else", "branch on a condition.", `if <condition> then ... else ... end
Runs the second block when the condition is falsy.
args:
- condition: what to test.
note:
Luau has no ternary, so this is the usual way to pick one of two values.
example:
if won then
	celebrate()
else
	keep_going()
end`, "if ${1:condition} then\n\t${2}\nelse\n\t${0}\nend"),

  LanguageSnippet("ifel", "if elseif else", "chain several conditions together.", `if ... elseif ... else ... end
Walks a chain of conditions and runs the first that holds.
args:
- each elseif needs a condition of its own.
note:
Only the first matching branch runs, so order the chain from narrow to broad.
example:
if hp <= 0 then
	-- dead
elseif hp < 30 then
	-- hurt
else
	-- fine
end`, "if ${1:condition} then\n\t${2}\nelseif ${3:condition} then\n\t${4}\nelse\n\t${0}\nend"),

  LanguageSnippet("elseif", "elseif", "add another branch to a chain.", `elseif <condition> then
Adds a second branch to an if chain.
args:
- condition: what to test when the branch above did not run.
example:
if a then
elseif b then
end`, "elseif ${1:condition} then\n\t${0}"),

  LanguageSnippet("else", "else", "fallback branch of an if.", `else
Runs when no earlier branch in the chain matched.
note:
There can only be one else, and it has no condition of its own.
example:
if found then
	use(found)
else
	warn("nothing found")
end`, "else\n\t${0}"),

  LanguageSnippet("then", "then", "close the condition and open the body.", `then
Separates the condition of an if or elseif from its body.
note:
Required after every if and elseif condition.
example:
if ready then
	start()
end`, "then\n\t${0}"),

  LanguageSnippet("end", "end", "close a block.", `end
Closes a block opened by function, if, for, while, do or a type.
note:
Every opener needs a matching end, or the file stops parsing right there.
example:
for i = 1, 3 do
	print(i)
end`, "end"),

  LanguageSnippet("do", "do", "open a bare block.", `do ... end
Opens a plain block with no condition.
note:
Good for giving a name a short life, or for bailing out early from the middle of a function.
example:
do
	local temp = compute()
	use(temp)
end`, "do\n\t${0}\nend"),

  LanguageSnippet("for", "for", "count from one value up to another.", `for <name> = <start>, <stop>[, <step>] do ... end
Counts through a range of numbers.
args:
- name: the counter, which is local to the loop.
- start: where counting begins.
- stop: where counting ends, inclusive.
- step: optional increment, negative to count down.
example:
for i = 10, 1, -1 do
	print(i)
end`, "for ${1:i} = ${2:1}, ${3:10} do\n\t${0}\nend"),

  LanguageSnippet("fori", "numeric for", "count through a range of numbers.", `for <name> = <start>, <stop>[, <step>] do ... end
Counts from a to b, stepping by 1 unless a step is given.
args:
- name: the counter, which is local to the loop.
- start: where counting begins.
- stop: where counting ends, inclusive.
example:
for i = 1, 10 do
	print(i)
end`, "for ${1:i} = ${2:1}, ${3:10} do\n\t${0}\nend"),

  LanguageSnippet("forin", "generic for", "loop over an iterator.", `for <key>, <value> in <iterator> do ... end
Loops over whatever an iterator yields.
args:
- key: what the iterator yields first.
- value: what it yields second.
- iterator: usually pairs, ipairs, or one of your own.
note:
A plain loop over an array only needs the value, so the key can be left out.
example:
for _, child in ipairs(parts) do
	print(child.Name)
end`, "for ${1:key}, ${2:value} in ${3:iterable} do\n\t${0}\nend"),

  LanguageSnippet("forp", "pairs loop", "walk every key in a table.", `for key, value in pairs(t) do ... end
Iterates over every key in a table.
args:
- key: the current key.
- value: the value stored under it.
note:
pairs walks the whole table, so the order is not something you can rely on.
example:
for name, fn in pairs(handlers) do
	print(name, fn())
end`, "for ${1:key}, ${2:value} in pairs(${3:table}) do\n\t${0}\nend"),

  LanguageSnippet("forip", "ipairs loop", "walk the array part of a table.", `for index, value in ipairs(t) do ... end
Iterates an array in order from 1 to the last value.
args:
- index: the position, counting from 1.
- value: the value at that position.
note:
Stops at the first nil, which is why it is the right choice for lists.
example:
for i, item in ipairs(list) do
	print(i, item)
end`, "for ${1:index}, ${2:value} in ipairs(${3:array}) do\n\t${0}\nend"),

  LanguageSnippet("in", "in", "introduce the iterator of a for loop.", `in <iterator>
Separates the loop names from what they iterate over.
args:
- iterator: usually pairs or ipairs, or a function of your own.
example:
for i, v in ipairs(list) do
end`, "in ${0}"),

  LanguageSnippet("while", "while", "loop while a condition holds.", `while <condition> do ... end
Keeps running while the condition holds.
args:
- condition: tested before every pass.
note:
If the condition never turns false the loop never ends, so make sure something inside changes it.
example:
while conn.Connected do
	task.wait(1)
end`, "while ${1:condition} do\n\t${0}\nend"),

  LanguageSnippet("repeat", "repeat until", "loop until a condition holds.", `repeat ... until <condition>
Runs the body at least once, then keeps going until the condition holds.
args:
- condition: tested after every pass, at the bottom of the loop.
note:
The body can see the locals it declares, which a while condition could not.
example:
repeat
	line = file:read()
until line == nil`, "repeat\n\t${0}\nuntil ${1:condition}"),

  LanguageSnippet("until", "until", "close a repeat loop.", `until <condition>
Closes a repeat block and says when to stop.
args:
- condition: when the loop should finish.
example:
repeat
	task.wait()
until done`, "until ${1:condition}"),

  LanguageSnippet("break", "break", "leave the innermost loop.", `break
Leaves the innermost loop immediately.
note:
Only valid inside a loop, and nothing after it on that line runs.
example:
for i = 1, 10 do
	if done then break end
end`, "break"),

  LanguageSnippet("continue", "continue", "skip to the next loop iteration.", `continue
Jumps to the next pass of the innermost loop.
note:
Everything below it in the loop body is skipped for this pass.
example:
for _, part in pairs(list) do
	if not part then continue end
	use(part)
end`, "continue"),

  LanguageSnippet("breakif", "break if", "leave a loop when a condition holds.", `if <condition> then break end
Breaks out of the loop as soon as the condition holds.
args:
- condition: what to test each pass.
note:
Saves repeating the test and the break in the body.
example:
while true do
	if not conn.Connected then break end
end`, "if ${1:condition} then\n\tbreak\nend"),

  LanguageSnippet("continueif", "continue if", "skip an iteration when a condition holds.", `if <condition> then continue end
Skips the rest of the pass when the condition holds.
args:
- condition: what to test each pass.
note:
Flattens the body when the skip applies to most cases.
example:
for _, item in ipairs(list) do
	if not item.enabled then continue end
	send(item)
end`, "if ${1:condition} then\n\tcontinue\nend"),

  LanguageSnippet("and", "and", "both sides must hold.", `a and b
True only when both sides are true, and hands back whichever side decided it.
note:
Short circuits, so a and a.field is safe even when a is nil.
example:
if player and player.Parent then
	print("still here")
end`, "and"),

  LanguageSnippet("or", "or", "either side will do.", `a or b
True when either side is true, and hands back whichever side decided it.
note:
This is also how you write a default, since a or b only falls back when a is falsy.
example:
local name = given or "unnamed"`, "or"),

  LanguageSnippet("not", "not", "flip a value.", `not <value>
True when the value is falsy, false when it is truthy.
note:
Only nil and false are falsy, so not 0 is false.
example:
if not finished then
	return
end`, "not ${0}"),

  LanguageSnippet("goto", "goto", "jump to a label.", `goto <label>
Jumps to a label later on in the same function.
args:
- label: the name of the label to jump to.
note:
The target is written as ::label::. Jumping backwards is how Luau loops without while.
example:
goto continue
::continue::`, "goto ${1:label}"),

  LanguageSnippet("nil", "nil", "the absence of a value.", `nil
The value that means nothing is there.
note:
A table lookup that misses gives nil, and reading a field of nil is an error. So nil is neither false nor 0.`, "nil"),

  LanguageSnippet("true", "true", "the true value.", `true
One of the two boolean values.
note:
Only nil and false are falsy, so 0 and the empty string are both true.
example:
if enabled == true then
end`, "true"),

  LanguageSnippet("false", "false", "the false value.", `false
One of the two boolean values.
note:
The only falsy value besides nil, which is what makes if x then a safe test.
example:
if connected == false then
	reconnect()
end`, "false"),

  LanguageSnippet("self", "self", "the instance a method was called on.", `self
Inside a method, the instance it was called on, handed in as the first argument.
note:
Declared with a colon, not a dot, so the caller does not pass it by hand.
example:
function Sword:Equip(player)
	self.owner = player
end`, "self"),

  LanguageSnippet("typedef", "type alias", "give a name to a type.", `type <Name> = <type>
Gives a name to a type so you can reuse it.
args:
- Name: the name the type gets.
- type: the type it stands for.
note:
Types vanish at runtime, so a type alias costs nothing beyond the annotation.
example:
type Damage = { amount: number, source: Instance? }`, "type ${1:Name} = ${2}"),

  LanguageSnippet("export", "export type", "share a type with anything that requires this file.", `export type <Name> = <type>
Makes a type alias visible to other files.
args:
- Name: the name the type gets.
- type: the type it stands for.
note:
Without export the alias stays private to the file it is written in.
example:
export type Config = { retries: number }`, "export type ${1:Name} = ${2}"),

  LanguageSnippet("pairs", "pairs", "iterate every key in a table.", `function pairs(t): (function, t, nil)
Returns an iterator over every key in a table.
args:
- t: the table to walk.
note:
Gives you the keys too, which is how you reach a table's entries when the order does not matter.
example:
for key, value in pairs(t) do
	print(key, value)
end`, "pairs(${1:table})"),

  LanguageSnippet("ipairs", "ipairs", "iterate the array part of a table.", `function ipairs(t): (function, t, 0)
Returns an iterator over the array part, from 1 upwards.
args:
- t: the table to walk.
note:
Stops at the first nil, so do not leave holes in a list you walk with this.
example:
for index, value in ipairs(list) do
	print(index, value)
end`, "ipairs(${1:array})"),

  LanguageSnippet("require", "require", "load another module.", `function require(module: ModuleScript): any
Runs another module once and hands back what it returned.
args:
- module: a ModuleScript, or a path to a Lua file in this one.
note:
The result is cached, so asking twice gives the same table back. Require at the top of the file, not inside a loop.
example:
local Config = require(script.Parent.Config)`, "require(${1:script.Parent.Module})"),

  LanguageSnippet("Instance", "Instance", "the base class of everything in the data model.", `class Instance
The base class every object in the data model inherits from.
args:
- Name: the class you want, such as Part or RemoteEvent.
note:
Instance.new refuses to make an Instance itself, so pick a concrete class.
example:
local part = Instance.new("Part")`, "Instance", "class"),

  LanguageSnippet("tween", "tween", "tween a property over time.", `TweenService:Create(target, info, goals): Tween
Animates properties of an instance.
args:
- target: the instance to move.
- info: how long it takes and how it eases.
- goals: the properties to end at.
note:
The tween does not start until you call Play, and you can Pause or Cancel it afterwards.
example:
TweenService:Create(part, TweenInfo.new(0.5), { Position = goal }):Play()`, "TweenService:Create(${1:target}, ${2:TweenInfo.new(${3:0.5})}, { ${4:Position} = ${5:goal} }):Play()"),

  LanguageSnippet("remotefn", "remote pair", "create a RemoteEvent and move it into ReplicatedStorage.", `Create a remote and put it where both sides can see it.
args:
- name: the remote's name under ReplicatedStorage.
note:
Only strings, numbers, booleans, tables of those, and instances cross the boundary.
example:
local remote = Instance.new("RemoteEvent")
remote.Name = "Ping"
remote.Parent = game.ReplicatedStorage`, "local ${1:remote} = Instance.new(\"${2:RemoteEvent}\")\n${1:remote}.Name = \"${3:Ping}\"\n${1:remote}.Parent = ${4:ReplicatedStorage}"),

  LanguageSnippet("debounce", "debounce", "wrap a function so it runs at most once per window.", `Wrap a function so rapid calls collapse into one.
args:
- fn: the function to protect.
- delay: the quiet period that has to pass, in seconds.
note:
Calls inside the window are dropped rather than queued, so only the last one runs.
example:
local save = debounce(function()
	writefile("data.json", json)
end, 1)`, "local function ${1:debounced}(fn, delay)\n\tlocal last = 0\n\treturn function(...)\n\t\tlocal now = os.clock()\n\t\tif now - last < (delay or 0.1) then\n\t\t\treturn\n\t\tend\n\t\tlast = now\n\t\treturn fn(...)\n\tend\nend\n\nlocal ${2:guarded} = ${1:debounced}(${3:function()\n\t${0}\nend}, ${4:delay})"),
];

const LUAU_EXTRA_SNIPPETS = [
  LanguageSnippet("getservice", "GetService", "grab a Roblox service by name.", `local <service> = game:GetService("<ServiceName>")
Everything you need lives on a service: Players, Workspace, ReplicatedStorage, TweenService and friends.
args:
- service: the binding, usually the ShortName.
example:
local Players = game:GetService("Players")`, "local ${1:service} = game:GetService(\"${2:Players}\")"),

  LanguageSnippet("waitforchild", "WaitForChild", "find a child, waiting until it exists.", `local <child> = <parent>:WaitForChild("<name>")
Blocks until the child appears, which makes scripts that run before the tree finishes loading reliable.
args:
- child: the local that receives the child.
- parent: the instance to search.
- name: the exact child name.
example:
local target = workspace:WaitForChild("Target")`, "local ${1:child} = ${2:parent}:WaitForChild(\"${3:name}\")"),

  LanguageSnippet("waitforchildtimeout", "WaitForChild timeout", "WaitForChild with a timeout floor.", `local <child> = <parent>:WaitForChild("<name>", <seconds>)
Same as WaitForChild, but gives up after a set number of seconds instead of waiting forever.
args:
- child: the local that receives the child.
- parent: the instance to search.
- name: the exact child name.
- seconds: how long to wait before giving up.
example:
local humanoid = character:WaitForChild("Humanoid", 5)`, "local ${1:child} = ${2:parent}:WaitForChild(\"${3:name}\", ${4:5})"),

  LanguageSnippet("fire", "FireServer", "send an event from the client to the server.", `<RemoteEvent>:FireServer(<args>)
Ships the arguments over the network to the replicated remote's OnServerEvent handler.
args:
- RemoteEvent: the replicated signal.
- args: anything serializable, or nothing.
note:
The server sees the player who fired, even if you do not pass one.
example:
remote:FireServer("hello")`, "${1:remote}:FireServer(${2})"),

  LanguageSnippet("fireclient", "FireClient", "send an event from the server to one player.", `<RemoteEvent>:FireClient(<player>, <args>)
Ships arguments to a single player's client.
args:
- RemoteEvent: the replicated signal.
- player: who receives it.
- args: anything serializable.
example:
remote:FireClient(player, 42)`, "${1:remote}:FireClient(${2:player}, ${3})"),

  LanguageSnippet("fireallclients", "FireAllClients", "broadcast an event to every client.", `<RemoteEvent>:FireAllClients(<args>)
Ships arguments to every connected client at once.
args:
- RemoteEvent: the replicated signal.
- args: anything serializable.
example:
remote:FireAllClients("round started")`, "${1:remote}:FireAllClients(${2})"),

  LanguageSnippet("invokeserver", "InvokeServer", "call a RemoteFunction and wait for its answer.", `local <result> = <RemoteFunction>:InvokeServer(<args>)
Blocks until the server's matching OnServerInvoke returns, then yields that as result.
args:
- result: what the server handed back.
- RemoteFunction: the replicated callback.
- args: sent to the function.
example:
local lap = finishLine:InvokeServer()`, "local ${1:result} = ${2:remote}:InvokeServer(${3})"),

  LanguageSnippet("invokeclient", "InvokeClient", "call one player's RemoteFunction handler.", `local <result> = <RemoteFunction>:InvokeClient(<player>, <args>)
Server side: waits for the named player's OnClientInvoke to return.
args:
- result: what the client handed back.
- RemoteFunction: the replicated callback.
- player: who must answer.
- args: sent to the handler.
example:
local ok = remote:InvokeClient(player, "ready")`, "local ${1:result} = ${2:remote}:InvokeClient(${3:player}, ${4})"),

  LanguageSnippet("onserverevent", "OnServerEvent", "listen for client->server events.", `<RemoteEvent>.OnServerEvent:Connect(function(<player>, <args>)
Runs when a client fires the remote. player is always the firing client.
args:
- RemoteEvent: the replicated signal.
- player: the client who fired this time.
- args: whatever they sent.
note:
Put this in a normal server Script.
example:
remote.OnServerEvent:Connect(function(player, text)
	print(player.Name, text)
end)`, "${1:remote}.OnServerEvent:Connect(function(${2:player}${3:, ${4:arg}})\n\t${0}\nend)"),

  LanguageSnippet("onclientevent", "OnClientEvent", "listen for server->client events.", `<RemoteEvent>.OnClientEvent:Connect(function(<args>)
Runs when the server fires this remote to you.
args:
- RemoteEvent: the replicated signal.
- args: whatever the server sent.
note:
Put this in a LocalScript.
example:
remote.OnClientEvent:Connect(function(text)
	print(text)
end)`, "${1:remote}.OnClientEvent:Connect(function(${2:arg})\n\t${0}\nend)"),

  LanguageSnippet("onserverinvoke", "OnServerInvoke", "answer RemoteFunction calls on the server.", `<RemoteFunction>.OnServerInvoke = function(<player>, <args>)
Returning a value sends it back to the InvokeServer caller.
args:
- RemoteFunction: the replicated callback.
- player: who invoked.
- args: what they sent.
example:
remote.OnServerInvoke = function(player, amount)
	return amount * 2
end`, "${1:remote}.OnServerInvoke = function(${2:player}${3:, ${4:arg}})\n\t${0}\nend"),

  LanguageSnippet("getattr", "GetAttribute", "read one attribute off an instance.", `local <value> = <instance>:GetAttribute("<name>")
Attributes are cheap named values glued to any instance.
args:
- value: what comes back.
- instance: the target.
- name: the attribute key.
example:
local health = part:GetAttribute("Health")`, "local ${1:value} = ${2:instance}:GetAttribute(\"${3:name}\")"),

  LanguageSnippet("setattr", "SetAttribute", "write one attribute on an instance.", `<instance>:SetAttribute("<name>", <value>)
Stores a value so other scripts can read it back with GetAttribute.
args:
- instance: the target.
- name: the attribute key.
- value: a number, string, bool or vec3.
example:
part:SetAttribute("Health", 100)`, "${1:instance}:SetAttribute(\"${2:name}\", ${3:value})"),

  LanguageSnippet("tween", "TweenService", "animate an instance property over time.", `local <tween> = game:GetService("TweenService"):Create(<instance>, TweenInfo.new(<time>), { <Property> = <value> })
<tween>:Play()
args:
- tween: the object to play.
- instance: what animates.
- time: seconds the tween takes.
- Property: the tweened property, e.g. Position or Rotation.
- value: where it lands.
example:
local spin = TweenService:Create(part, TweenInfo.new(1), { Rotation = Vector3.new(0, 90, 0) })
spin:Play()`, "local ${1:tween} = game:GetService(\"TweenService\"):Create(${2:instance}, TweenInfo.new(${3:1}), { ${4:Property} = ${5:Value} })\n${1:tween}:Play()"),

  LanguageSnippet("raycast", "Raycast", "shoot a ray and see what it hits.", `local <result> = workspace:Raycast(<origin>, <direction>)
if <result> then
	...
end
Returns nil when nothing is hit, otherwise an instance plus the impact normal and position.
args:
- result: the hit or nil.
- origin: where the ray starts.
- direction: where it goes.
example:
local wall = workspace:Raycast(origin, Vector3.new(0, -50, 0))`, "local ${1:result} = workspace:Raycast(${2:origin}, ${3:direction}${4:, ${5:params}})\nif ${1:result} then\n\t${0}\nend"),

  LanguageSnippet("newpart", "Instance.new Part", "create a Part and parent it.", `local <part> = Instance.new("Part")
<part>.Parent = <parent>
args:
- part: the new instance.
- parent: usually workspace or a model.
example:
local brick = Instance.new("Part")
brick.Size = Vector3.new(4, 1, 4)
brick.Parent = workspace`, "local ${1:part} = Instance.new(\"Part\")\n${1:part}.Parent = ${2:workspace}"),

  LanguageSnippet("newmodel", "Instance.new Model", "create a Model to hold other parts.", `local <model> = Instance.new("Model")
<model>.Parent = <parent>
args:
- model: the new container.
- parent: usually workspace.
example:
local ship = Instance.new("Model")
ship.Parent = workspace`, "local ${1:model} = Instance.new(\"Model\")\n${1:model}.Parent = ${2:workspace}"),

  LanguageSnippet("newvalue", "Instance.new value", "create a typed holder value.", `local <value> = Instance.new("<Kind>Value")
<value>.Parent = <parent>
Kind is IntValue, NumberValue, StringValue, BoolValue or ObjectValue.
args:
- value: the new instance.
- Kind: the value kind.
- parent: where it lives.
example:
local gold = Instance.new("IntValue")
gold.Parent = workspace`, "local ${1:value} = Instance.new(\"${2:IntValue}\")\n${1:value}.Parent = ${3:parent}"),

  LanguageSnippet("newfolder", "Instance.new Folder", "create an organising Folder.", `local <folder> = Instance.new("Folder")
<folder>.Parent = <parent>
A Folder groups children without existing in the 3D world.
args:
- folder: the new container.
- parent: usually workspace.
example:
local props = Instance.new("Folder")
props.Parent = workspace`, "local ${1:folder} = Instance.new(\"Folder\")\n${1:folder}.Parent = ${2:workspace}"),

  LanguageSnippet("clone", "clone", "duplicate an instance tree.", `local <clone> = <instance>:Clone()
<clone>.Parent = <parent>
Copies the instance and everything under it.
args:
- clone: the new tree.
- instance: the source.
- parent: where the copy goes.
example:
local copy = part:Clone()
copy.Position = part.Position + Vector3.new(5, 0, 0)
copy.Parent = workspace`, "local ${1:clone} = ${2:instance}:Clone()\n${1:clone}.Parent = ${3:parent}"),

  LanguageSnippet("connect", "Connect", "subscribe to a signal.", `<signal>:Connect(function(<args>)
	...
end)
Runs the function every time the signal fires.
args:
- signal: any RBXScriptSignal.
- args: what the signal passes.
example:
button.MouseButton1Click:Connect(function()
	print("clicked")
end)`, "${1:signal}:Connect(function(${2:arg})\n\t${0}\nend)"),

  LanguageSnippet("connectonce", "Connect once", "subscribe to exactly one fire.", `<signal>:Once(function(<args>)
	...
end)
Disconnects automatically after the first fire.
args:
- signal: any RBXScriptSignal.
- args: what the signal passes.
example:
endpoint:Once(function()
	print("arrived")
end)`, "${1:signal}:Once(function(${2:arg})\n\t${0}\nend)"),

  LanguageSnippet("taskspawn", "task.spawn", "run a function on the next scheduler tick.", `task.spawn(function()
	...
end)
Like coroutine.create + resume, but safer: spawned code keeps running even if the script dies.
args:
- fn: the function to run.
example:
task.spawn(function()
	print("soon")
end)`, "task.spawn(function()\n\t${0}\nend)"),

  LanguageSnippet("taskdelay", "task.delay", "run a function after a delay.", `task.delay(<seconds>, function()
	...
end)
Yields-independent timer that does not block the caller.
args:
- seconds: how long to wait.
- fn: the function to run.
example:
task.delay(2, function()
	print("2s later")
end)`, "task.delay(${1:1}, function()\n\t${0}\nend)"),

  LanguageSnippet("collectiontag", "AddTag", "tag an instance with CollectionService.", `game:GetService("CollectionService"):AddTag(<instance>, "<tag>")
Lets other scripts find tagged instances with GetTagged.
args:
- instance: what to tag.
- tag: the tag name.
example:
CollectionService:AddTag(part, "Breakable")`, "game:GetService(\"CollectionService\"):AddTag(${1:instance}, \"${2:tag}\")"),

  LanguageSnippet("collectiontags", "GetTagged", "list every instance carrying a tag.", `for _, <instance> in ipairs(game:GetService("CollectionService"):GetTagged("<tag>")) do
	...
end
args:
- instance: each tagged instance.
- tag: the tag to look for.
example:
for _, brick in ipairs(CollectionService:GetTagged("Breakable")) do
	brick:Destroy()
end`, "for _, ${1:instance} in ipairs(game:GetService(\"CollectionService\"):GetTagged(\"${2:tag}\")) do\n\t${0}\nend"),

  LanguageSnippet("localplayer", "LocalPlayer", "grab the local player.", `local <player> = game:GetService("Players").LocalPlayer
Only exists in LocalScripts: it is the player this client belongs to.
args:
- player: the local player.
example:
local me = game:GetService("Players").LocalPlayer`, "local ${1:player} = game:GetService(\"Players\").LocalPlayer"),

  LanguageSnippet("sortasc", "table.sort ascending", "sort a table in ascending order.", `table.sort(<list>, function(a, b)
	return a < b
end)
args:
- list: the array to sort in place.
example:
table.sort(scores, function(a, b)
	return a < b
end)`, "table.sort(${1:list}, function(${2:a}, ${3:b})\n\treturn ${2:a} < ${3:b}\nend)"),

  LanguageSnippet("sortdesc", "table.sort descending", "sort a table in descending order.", `table.sort(<list>, function(a, b)
	return a > b
end)
args:
- list: the array to sort in place.
example:
table.sort(scores, function(a, b)
	return a > b
end)`, "table.sort(${1:list}, function(${2:a}, ${3:b})\n\treturn ${2:a} > ${3:b}\nend)"),

  LanguageSnippet("findchildclass", "FindFirstChildOfClass", "find a child by its class.", `local <child> = <parent>:FindFirstChildOfClass("<ClassName>")
Returns nil instead of yielding when the child is missing.
args:
- child: the found instance.
- parent: what to search.
- ClassName: e.g. Humanoid or Sound.
example:
local humanoid = character:FindFirstChildOfClass("Humanoid")`, "local ${1:child} = ${2:parent}:FindFirstChildOfClass(\"${3:ClassName}\")"),

  LanguageSnippet("foreachchild", "iterate children", "loop over every child of an instance.", `for _, <child> in ipairs(<parent>:GetChildren()) do
	...
end
args:
- child: each direct child, in tree order.
- parent: the container.
example:
for _, tool in ipairs(backpack:GetChildren()) do
	print(tool.Name)
end`, "for _, ${1:child} in ipairs(${2:parent}:GetChildren()) do\n\t${0}\nend"),

  LanguageSnippet("cframenew", "CFrame.new", "build a CFrame from position and rotation.", `local <cf> = CFrame.new(<position>) * CFrame.Angles(<rx>, <ry>, <rz>)
Position first, rotation second. Angles are in radians.
args:
- cf: the resulting CFrame.
- position: a Vector3.
- rx/ry/rz: pitch, yaw, roll.
example:
local head = CFrame.new(Vector3.new(0, 5, 0)) * CFrame.Angles(0, math.pi, 0)`, "local ${1:cf} = CFrame.new(${2:Vector3.new(0, 0, 0)}) * CFrame.Angles(${3:0}, ${4:0}, ${5:0})"),
];

async function FetchDefaultSnippetsJson() {
  try {
    const response = await fetch(DEFAULT_SNIPPETS_URL);

    if (!response.ok) {
      throw new Error(`status ${response.status}`);
    }

    return await response.json();
  } catch (err) {
    console.warn("could not fetch editor/json/snippets.json, using built-in fallback:", err);
    return FALLBACK_SNIPPETS_JSON;
  }
}

async function GetSnippetsPath() {
  const base_dir = await GetBaseDir();
  const config_dir = await JoinPath(base_dir, "config");

  await EnsureFolder(config_dir);
  return JoinPath(config_dir, "snippets.json");
}

function NormalizeSnippetList(list) {
  return Array.isArray(list)
    ? list.filter((snippet) => snippet && typeof snippet.prefix === "string" && typeof snippet.body === "string")
    : [];
}

function MergeSnippetLists(...layers) {
  const by_prefix = new Map();

  for (const layer of layers) {
    for (const snippet of NormalizeSnippetList(layer)) {
      by_prefix.set(snippet.prefix, snippet);
    }
  }

  return [...by_prefix.values()];
}

function IndexSnippets(snippet_list) {
  SNIPPETS_STATE.by_prefix.clear();
  SNIPPET_FIELD_CACHE.clear();
  BROWSE_CACHE.reset();

  const list = NormalizeSnippetList(snippet_list);
  SNIPPETS_STATE.all = list;

  for (const snippet of list) {
    SNIPPETS_STATE.by_prefix.set(snippet.prefix, snippet);
  }
}

async function LoadSnippets() {
  const default_json = await FetchDefaultSnippetsJson();
  const bundled_list = default_json && default_json.snippets;
  const with_language = MergeSnippetLists(bundled_list, LUAU_LANGUAGE_SNIPPETS, LUAU_EXTRA_SNIPPETS);

  if (!window.__TAURI__) {
    IndexSnippets(with_language);
    SNIPPETS_STATE.loaded = true;
    return;
  }

  const snippets_path = await GetSnippetsPath();
  try {
    const already_exists = await FsPathExists(snippets_path);
    if (!already_exists) {
      await FsWriteTextFile(snippets_path, JSON.stringify(default_json, null, 2));
      IndexSnippets(with_language);
      SNIPPETS_STATE.loaded = true;
      return;
    }

    const parsed = JSON.parse(await FsReadTextFile(snippets_path));
    IndexSnippets(MergeSnippetLists(with_language, parsed && parsed.snippets));
  } catch (err) {
    console.warn("could not load snippets.json, using defaults:", err);
    IndexSnippets(with_language);
  }
  SNIPPETS_STATE.loaded = true;
}

function ParseSnippetBody(raw_body) {
  const indent_unit = GetEditorIndentUnit();
  const with_tabs = raw_body.replace(/\t/g, indent_unit).replace(/\\t/g, indent_unit);
  const stop_pattern = /\$\{(\d+)(?::([^}]*))?\}|\$(\d+)/g;

  let final_text = "";
  let last_index = 0;
  const stops = [];
  let match;

  while ((match = stop_pattern.exec(with_tabs)) !== null) {
    final_text += with_tabs.slice(last_index, match.index);
    const stop_number = Number(match[1] !== undefined ? match[1] : match[3]);
    const default_text = match[2] || "";

    stops.push({ stop_number, start: final_text.length, length: default_text.length });
    final_text += default_text;
    last_index = stop_pattern.lastIndex;
  }
  final_text += with_tabs.slice(last_index);

  stops.sort((a, b) => a.stop_number - b.stop_number);

  const seen = new Set();
  const tab_stops = [];
  let cursor_stop = null;

  for (const stop of stops) {
    if (stop.stop_number === 0) {
      if (!cursor_stop) {
        cursor_stop = stop;
      }
      continue;
    }

    if (seen.has(stop.stop_number)) {
      continue;
    }

    seen.add(stop.stop_number);
    tab_stops.push(stop);
  }

  return { final_text, stops, tab_stops, cursor_stop };
}

function HighlightSnippetBodyRichHtml(raw_body) {
  const with_tabs = String(raw_body || "").replace(/\t/g, "  ").replace(/\\t/g, "  ");
  const stop_pattern = /\$\{(\d+)(?::([^}]*))?\}|\$(\d+)/g;
  const placeholders = [];

  const marked = with_tabs.replace(stop_pattern, (_full, _n1, default_text) => {
    const text = default_text || "";
    if (text.length === 0) {
      return "";
    }

    const marker = `__SNIPPH${placeholders.length}__`;
    placeholders.push(text);
    return marker;
  });

  let html_out = HighlightLuauToHtml(marked);

  placeholders.forEach((text, index) => {
    const marker = `__SNIPPH${index}__`;
    const highlighted = HighlightLuauToHtml(text);
    const replacement = `<span class="editor-suggest-placeholder">${highlighted}</span>`;
    html_out = html_out.split(EscapeHtmlForEditor(marker)).join(replacement);
    html_out = html_out.split(marker).join(replacement);
  });

  return html_out;
}

function ParseSnippetDocumentation(raw_text) {
  const text = String(raw_text || "").replace(/\r\n/g, "\n").trim();
  if (!text) {
    return { signature: "", description: "", args: [], note: "", example: "" };
  }

  const lines = text.split("\n");
  let cursor = 0;
  let signature = "";

  const first_line = lines[0] || "";
  const looks_like_signature = lines.length > 1 && first_line.length < 220 && !/[.!?]$/.test(first_line);

  if (looks_like_signature || /^function\s/.test(first_line)) {
    signature = first_line;
    cursor = 1;
  }

  const description_lines = [];
  const args = [];
  const note_lines = [];
  const example_lines = [];
  let mode = "description";

  for (; cursor < lines.length; cursor += 1) {
    const line = lines[cursor];

    if (line === "args:") {
      mode = "args";
      continue;
    }
    if (line === "note:") {
      mode = "note";
      continue;
    }
    if (line === "example:") {
      mode = "example";
      continue;
    }

    if (mode === "args") {
      const arg_match = line.match(/^- ([^:]+):\s*(.*)$/);
      if (arg_match) {
        args.push({ name: arg_match[1].trim(), text: arg_match[2].trim() });
      } else if (line.trim()) {
        args.push({ name: "", text: line.trim() });
      }
      continue;
    }

    if (mode === "note") {
      note_lines.push(line);
      continue;
    }

    if (mode === "example") {
      example_lines.push(line);
      continue;
    }

    description_lines.push(line);
  }

  return {
    signature,
    description: description_lines.join("\n").trim(),
    args,
    note: note_lines.join("\n").trim(),
    example: example_lines.join("\n").replace(/^\n+|\n+$/g, ""),
  };
}

function HighlightSnippetCodeHtml(source_text) {
  if (!source_text) {
    return "";
  }

  return HighlightLuauToHtml(source_text);
}

function RenderSnippetDocumentationHtml(snippet) {
  const raw_text = (snippet && (snippet.documentation || snippet.description)) || "";
  const parsed = ParseSnippetDocumentation(raw_text);
  let html_out = "";

  if (snippet && snippet.body) {
    html_out += `<pre class="editor-suggest-code editor-suggest-code-body"><code>${HighlightSnippetBodyRichHtml(snippet.body)}</code></pre>`;
  }

  if (parsed.signature) {
    html_out += `<div class="editor-suggest-code editor-suggest-code-sig"><code>${HighlightSnippetCodeHtml(parsed.signature)}</code></div>`;
  }

  if (parsed.description) {
    html_out += `<p class="editor-suggest-doc-text">${EscapeHtmlForEditor(parsed.description)}</p>`;
  }

  if (parsed.args.length > 0) {
    html_out += `<div class="editor-suggest-doc-section">args</div><ul class="editor-suggest-doc-args">`;
    for (const arg of parsed.args) {
      html_out += "<li>";
      if (arg.name) {
        html_out += `<code class="editor-suggest-doc-arg-name">${EscapeHtmlForEditor(arg.name)}</code>`;
      }
      html_out += `<span>${EscapeHtmlForEditor(arg.text)}</span></li>`;
    }
    html_out += "</ul>";
  }

  if (parsed.note) {
    html_out += `<div class="editor-suggest-doc-section">note</div>`;
    html_out += parsed.note
      .split("\n")
      .map((line) => `<p class="editor-suggest-doc-note">${EscapeHtmlForEditor(line)}</p>`)
      .join("");
  }

  if (parsed.example) {
    html_out += `<div class="editor-suggest-doc-section">example</div><pre class="editor-suggest-code"><code>${HighlightSnippetCodeHtml(parsed.example)}</code></pre>`;
  }

  if (!html_out && raw_text) {
    html_out = `<p class="editor-suggest-doc-text">${EscapeHtmlForEditor(raw_text)}</p>`;
  }

  return html_out;
}

function ScoreFuzzyMatch(query, target) {
  const lower_query = query.toLowerCase();
  const lower_target = String(target || "").toLowerCase();

  if (!lower_query) {
    return -1;
  }

  if (lower_target === lower_query) {
    return 0;
  }

  const at = lower_target.indexOf(lower_query);
  const boundary = at === 0 || lower_target[at - 1] === "." || lower_target[at - 1] === "_" || lower_target[at - 1] === ":";

  if (at === 0) {
    return 1;
  }

  if (at > 0) {
    return boundary ? 2 : 3;
  }

  let cursor = 0;
  let gaps = 0;
  let previous = -1;

  for (const character of lower_target) {
    if (character === lower_query[cursor]) {
      if (previous >= 0) {
        gaps += cursor - previous - 1;
      }
      previous = cursor;
      cursor += 1;

      if (cursor === lower_query.length) {
        return 4 + Math.min(gaps, 12);
      }
    }
  }

  return -1;
}

function GetSnippetHaystack(snippet) {
  return [snippet.prefix, snippet.name, snippet.documentation, snippet.description]
    .filter(Boolean)
    .join(" ");
}

const SNIPPET_FIELD_CACHE = new Map();

function GetSnippetSearchCached(snippet) {
  let cached = SNIPPET_FIELD_CACHE.get(snippet);

  if (!cached) {
    cached = {
      prefix_lc: String(snippet.prefix || "").toLowerCase(),
      name_lc: String(snippet.name || "").toLowerCase(),
      body_lc: String(snippet.body || "").toLowerCase(),
      haystack_lc: String(GetSnippetHaystack(snippet)).toLowerCase(),
    };
    SNIPPET_FIELD_CACHE.set(snippet, cached);
  }

  return cached;
}

function ScoreSnippetQuery(query, snippet) {
  const lower_query = String(query || "").toLowerCase();

  if (!lower_query) {
    return null;
  }

  const cached = GetSnippetSearchCached(snippet);
  const prefix_score = ScoreFuzzyMatch(lower_query, cached.prefix_lc);
  const name_score = ScoreFuzzyMatch(lower_query, cached.name_lc);
  const body_score = ScoreFuzzyMatch(lower_query, cached.body_lc);
  const doc_score = ScoreFuzzyMatch(lower_query, cached.haystack_lc);
  const candidates = [prefix_score, name_score, body_score, doc_score].filter((score) => score >= 0);

  if (candidates.length === 0) {
    return null;
  }

  const best = Math.min(...candidates);

  if (best > 8) {
    return null;
  }

  if (lower_query.length <= 2 && prefix_score > 1) {
    return null;
  }

  let field = "prefix";
  if (best === prefix_score) {
    field = "prefix";
  } else if (best === name_score) {
    field = "name";
  } else if (best === body_score) {
    field = "body";
  } else {
    field = "docs";
  }

  const field_rank = field === "prefix" ? 0 : field === "name" ? 1 : field === "body" ? 2 : 3;

  return { score: best, field, field_rank };
}

function StripLuaNoise(source) {
  return String(source || "")
    .replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "")
    .replace(/--[^\n]*/g, "")
    .replace(/\[(=*)\[[\s\S]*?\]\1\]/g, '""')
    .replace(/"(?:\\.|[^"\\\n])*"/g, '""')
    .replace(/'(?:\\.|[^'\\\n])*'/g, "''");
}

function GuessLuaType(raw_value) {
  const value = String(raw_value || "").trim();

  if (!value) {
    return "any";
  }
  if (value === "nil") {
    return "nil";
  }
  if (value === "true" || value === "false") {
    return "boolean";
  }
  if (value[0] === '"' || value[0] === "'" || value.startsWith("[[")) {
    return "string";
  }
  if (value[0] === "{") {
    return "table";
  }
  if (/^function\b/.test(value)) {
    return "function";
  }
  if (/^-?(?:0x[\da-fA-F]+|\d+(?:\.\d*)?|\.\d+)/.test(value)) {
    return "number";
  }

  const instance_new = value.match(/^Instance\.new\s*\(\s*["']([^"']+)/);
  if (instance_new) {
    return instance_new[1];
  }

  const roblox_type = value.match(/^(Vector3|Vector2|CFrame|Color3|UDim2|UDim|BrickColor|TweenInfo)\b/);
  if (roblox_type) {
    return roblox_type[1];
  }

  if (/^(game|workspace|script)\b/.test(value) || /:(WaitForChild|FindFirstChild|FindFirstChildOfClass)\s*\(/.test(value)) {
    return "Instance";
  }

  return "any";
}

function SplitLuaParams(raw_params) {
  return String(raw_params || "")
    .split(",")
    .map((part) => part.trim().replace(/\s*=.*$/, ""))
    .filter((part) => part && part !== "..." && /^[A-Za-z_][A-Za-z0-9_]*$/.test(part));
}

function BuildCallBody(name, params) {
  if (!params || params.length === 0) {
    return `${name}(\${0})`;
  }

  const inner = params.map((param, index) => `\${${index + 1}:${param}}`).join(", ");
  return `${name}(${inner})`;
}

function IsLuaKeywordName(name) {
  return LUA_KEYWORDS.has(name);
}

function PutBufferSymbol(by_name, entry) {
  const existing = by_name.get(entry.prefix);

  if (!existing) {
    by_name.set(entry.prefix, entry);
    return;
  }

  if (existing.kind === "variable" && entry.kind === "function") {
    by_name.set(entry.prefix, entry);
    return;
  }

  if (existing.value_type === "any" && entry.value_type && entry.value_type !== "any") {
    existing.value_type = entry.value_type;
    existing.documentation = entry.documentation;
  }
}

function CollectBufferSymbols(source) {
  const by_name = new Map();
  const plain = StripLuaNoise(source);

  const TakeFn = (name, raw_params) => {
    if (!name || IsLuaKeywordName(name)) {
      return;
    }

    const params = SplitLuaParams(raw_params);
    const sig = `function ${name}(${params.join(", ")})`;
    PutBufferSymbol(by_name, {
      prefix: name,
      name,
      kind: "function",
      value_type: "function",
      body: BuildCallBody(name, params),
      description: sig,
      documentation: `${sig}\nPicked up from the current file.`,
    });

    for (const param of params) {
      PutBufferSymbol(by_name, {
        prefix: param,
        name: param,
        kind: "variable",
        value_type: "any",
        body: param,
        description: `arg ${param}`,
        documentation: `${param}\nParameter on ${name}.`,
      });
    }
  };

  const fn_pattern = /(?:local\s+)?function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)/g;
  let match;
  while ((match = fn_pattern.exec(plain)) !== null) {
    TakeFn(match[1], match[2]);
  }

  const assigned_fn = /([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\s*\(([^)]*)\)/g;
  while ((match = assigned_fn.exec(plain)) !== null) {
    TakeFn(match[1], match[2]);
  }

  const local_pattern = /local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)(?:\s*=\s*([^\n]+))?/g;
  while ((match = local_pattern.exec(plain)) !== null) {
    const names = match[1].split(",").map((part) => part.trim()).filter(Boolean);
    const raw_rhs = match[2] || "";
    const values = [];
    let buf = "";
    let depth = 0;

    for (let i = 0; i < raw_rhs.length; i += 1) {
      const ch = raw_rhs[i];
      if (ch === "(" || ch === "{" || ch === "[") {
        depth += 1;
      } else if (ch === ")" || ch === "}" || ch === "]") {
        depth = Math.max(0, depth - 1);
      }

      if (ch === "," && depth === 0) {
        values.push(buf.trim());
        buf = "";
        continue;
      }
      buf += ch;
    }
    if (buf.trim()) {
      values.push(buf.trim());
    }

    names.forEach((name, index) => {
      if (IsLuaKeywordName(name)) {
        return;
      }

      const rhs = values[index] || "";
      if (/^function\s*\(/.test(rhs)) {
        const params = SplitLuaParams((rhs.match(/^function\s*\(([^)]*)\)/) || [])[1] || "");
        TakeFn(name, params.join(", "));
        return;
      }

      const value_type = GuessLuaType(rhs);
      PutBufferSymbol(by_name, {
        prefix: name,
        name,
        kind: "variable",
        value_type,
        body: name,
        description: rhs ? `local ${name} = ${rhs}` : `local ${name}`,
        documentation: rhs
          ? `${name}: ${value_type}\nlocal ${name} = ${rhs}`
          : `${name}: ${value_type}\nLocal in the current file.`,
      });
    });
  }

  const numeric_for = /for\s+([A-Za-z_][A-Za-z0-9_]*)\s*=/g;
  while ((match = numeric_for.exec(plain)) !== null) {
    const name = match[1];
    PutBufferSymbol(by_name, {
      prefix: name,
      name,
      kind: "variable",
      value_type: "number",
      body: name,
      description: `for ${name}`,
      documentation: `${name}: number\nLoop counter.`,
    });
  }

  const generic_for = /for\s+([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\s+in\b/g;
  while ((match = generic_for.exec(plain)) !== null) {
    PutBufferSymbol(by_name, {
      prefix: match[1],
      name: match[1],
      kind: "variable",
      value_type: "any",
      body: match[1],
      description: `for ${match[1]}`,
      documentation: `${match[1]}\nIterator key / index.`,
    });
    PutBufferSymbol(by_name, {
      prefix: match[2],
      name: match[2],
      kind: "variable",
      value_type: "any",
      body: match[2],
      description: `for ${match[2]}`,
      documentation: `${match[2]}\nIterator value.`,
    });
  }

  return [...by_name.values()];
}

const BUFFER_SYMBOL_COLLECT_INTERVAL_MS = 60;
const BUFFER_SYMBOL_MAX_SOURCE_LENGTH = 400000;
let buffer_symbol_collect_at = 0;

function GetBufferSymbols(source) {
  if (BUFFER_SYMBOL_STATE.key === source) {
    return BUFFER_SYMBOL_STATE.symbols;
  }

  const prev_key = BUFFER_SYMBOL_STATE.key || "";
  const is_incremental = source.startsWith(prev_key) || prev_key.startsWith(source);
  const now = Date.now();

  if (is_incremental && now - buffer_symbol_collect_at < BUFFER_SYMBOL_COLLECT_INTERVAL_MS) {
    return BUFFER_SYMBOL_STATE.symbols;
  }

  buffer_symbol_collect_at = now;
  const symbols = source.length > BUFFER_SYMBOL_MAX_SOURCE_LENGTH ? [] : CollectBufferSymbols(source);
  BUFFER_SYMBOL_STATE.key = source;
  BUFFER_SYMBOL_STATE.symbols = symbols;
  return symbols;
}

const SNIPPET_SUGGEST_LIMIT = 18;

const BROWSE_CACHE = {
  source: null,
  sorted: [],
  reset() {
    this.source = null;
    this.sorted = [];
  },
};

function GetBrowseSnippets() {
  if (BROWSE_CACHE.source !== SNIPPETS_STATE.all) {
    const browse = SNIPPETS_STATE.loaded ? [...SNIPPETS_STATE.all] : [];
    browse.sort((a, b) => a.prefix.localeCompare(b.prefix));
    BROWSE_CACHE.source = SNIPPETS_STATE.all;
    BROWSE_CACHE.sorted = browse;
  }

  return BROWSE_CACHE.sorted;
}

function GetSnippetSuggestions(query, source) {
  const lower_query = String(query || "").trim().toLowerCase();

  if (!lower_query) {
    const browse = GetBrowseSnippets();
    const items = browse
      .slice(0, SNIPPET_SUGGEST_LIMIT)
      .map((snippet) => ({ snippet, match: { score: 0, field: "prefix" }, origin: "library" }));
    return { items, total: browse.length };
  }

  const scored = [];
  const seen = new Set();

  const Consider = (snippet, origin) => {
    const match = ScoreSnippetQuery(lower_query, snippet);

    if (!match) {
      return;
    }

    const dedupe_key = `${snippet.prefix}\u0000${snippet.body}`;

    if (seen.has(dedupe_key)) {
      return;
    }

    seen.add(dedupe_key);
    scored.push({ snippet, match, origin, length: snippet.prefix.length });
  };

  for (const snippet of GetBufferSymbols(source || "")) {
    Consider(snippet, "buffer");
  }

  if (SNIPPETS_STATE.loaded) {
    for (const snippet of SNIPPETS_STATE.all) {
      Consider(snippet, "library");
    }
  }

  scored.sort((a, b) =>
    a.match.score - b.match.score
      || a.match.field_rank - b.match.field_rank
      || OriginRank(a.origin) - OriginRank(b.origin)
      || a.length - b.length
      || a.snippet.prefix.localeCompare(b.snippet.prefix)
  );

  return {
    items: scored.slice(0, SNIPPET_SUGGEST_LIMIT),
    total: scored.length,
  };
}

function OriginRank(origin) {
  return origin === "buffer" ? 0 : 1;
}

function EndSnippetSession() {
  SNIPPET_SESSION.active = false;
  SNIPPET_SESSION.base = 0;
  SNIPPET_SESSION.text = "";
  SNIPPET_SESSION.stops = [];
  SNIPPET_SESSION.index = 0;
  SNIPPET_SESSION.end = 0;
}

function IsSnippetSessionLive(textarea) {
  if (!SNIPPET_SESSION.active) {
    return false;
  }

  const value = textarea.value;
  const start = SNIPPET_SESSION.base;
  const end = SNIPPET_SESSION.end;

  if (value.slice(start, end) !== SNIPPET_SESSION.text) {
    EndSnippetSession();
    return false;
  }

  return true;
}

function IsSnippetSessionActive(textarea) {
  return IsSnippetSessionLive(textarea);
}

function MoveSnippetSessionTo(textarea, index) {
  const stops = SNIPPET_SESSION.stops;
  const wrapped = ((index % stops.length) + stops.length) % stops.length;
  const stop = stops[wrapped];

  SNIPPET_SESSION.index = wrapped;
  textarea.focus();
  textarea.selectionStart = SNIPPET_SESSION.base + stop.start;
  textarea.selectionEnd = SNIPPET_SESSION.base + stop.start + stop.length;
}

function PlaceCaretAfterSnippet(textarea) {
  const end = SNIPPET_SESSION.end;

  EndSnippetSession();
  textarea.focus();
  textarea.selectionStart = end;
  textarea.selectionEnd = end;
}

function StepSnippetSession(textarea, direction) {
  if (!IsSnippetSessionLive(textarea)) {
    return false;
  }

  if (SNIPPET_SESSION.stops.length === 1) {
    if (direction > 0) {
      PlaceCaretAfterSnippet(textarea);
    } else {
      MoveSnippetSessionTo(textarea, 0);
    }
    return true;
  }

  MoveSnippetSessionTo(textarea, SNIPPET_SESSION.index + direction);
  return true;
}

function ExpandSnippetInTextarea(textarea, snippet, word_start, caret) {
  const { final_text, tab_stops, cursor_stop } = ParseSnippetBody(snippet.body);

  textarea.focus();
  textarea.selectionStart = word_start;
  textarea.selectionEnd = caret;

  const supported = typeof document.execCommand === "function"
    && document.queryCommandSupported
    && document.queryCommandSupported("insertText");

  if (supported) {
    document.execCommand("insertText", false, final_text);
  } else {
    const value = textarea.value;
    textarea.value = value.slice(0, word_start) + final_text + value.slice(caret);
  }

  EndSnippetSession();

  if (tab_stops.length > 0) {
    SNIPPET_SESSION.active = true;
    SNIPPET_SESSION.base = word_start;
    SNIPPET_SESSION.text = final_text;
    SNIPPET_SESSION.end = word_start + final_text.length;
    SNIPPET_SESSION.stops = tab_stops;
    SNIPPET_SESSION.index = 0;
    MoveSnippetSessionTo(textarea, 0);
    return;
  }

  const caret_pos = cursor_stop ? word_start + cursor_stop.start : word_start + final_text.length;
  textarea.selectionStart = caret_pos;
  textarea.selectionEnd = caret_pos;
}

function FindSnippetForPrefix(prefix) {
  const exact = SNIPPETS_STATE.by_prefix.get(prefix);

  if (exact) {
    return exact;
  }

  const lower = prefix.toLowerCase();
  const candidates = SNIPPETS_STATE.all.filter((snippet) => {
    const snippet_prefix = String(snippet.prefix || "").toLowerCase();
    return snippet_prefix.startsWith(lower) && snippet_prefix !== lower;
  });

  return candidates.length === 1 ? candidates[0] : null;
}

function TryExpandSnippetAtCaret(textarea) {
  if (UI_STATE.disable_snippets || !SNIPPETS_STATE.loaded || textarea.selectionStart !== textarea.selectionEnd) {
    return false;
  }

  const caret = textarea.selectionStart;
  const prefix = ReadSuggestWordAt(textarea.value, caret);

  if (!prefix) {
    return false;
  }

  const snippet = FindSnippetForPrefix(prefix);

  if (!snippet) {
    return false;
  }

  const word_start = caret - prefix.length;
  ExpandSnippetInTextarea(textarea, snippet, word_start, caret);
  return true;
}
